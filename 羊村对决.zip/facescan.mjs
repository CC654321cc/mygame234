/* 开发用：扫描角色脸部区域，统计"暗色像素"占比，判断脸是否被大面积覆盖。
 * 用法: node facescan.mjs [缩放]
 */
import { createSoftwareCanvas } from './softcanvas.mjs';
import { ROSTER } from './fighters.mjs';
import { drawFighter } from './fightersprite.mjs';

const scale = Number(process.argv[2] || 130);
const W = 240, H = 320, feetY = 296, cx = 120;
const R = 0.44;
const headY = 0.64 + 0.42;

console.log('角色      脸区域内 暗色像素占比   最亮像素RGB        判定');
let bad = 0;
for (const def of ROSTER) {
  const ctx = createSoftwareCanvas(W, H);
  ctx.fillStyle = '#101820';
  ctx.fillRect(0, 0, W, H);
  drawFighter(ctx, def, cx, feetY, 'idle', { facing: 1, scale, time: 0 });
  const b = ctx._buf;

  // 脸区域：以头心为中心、半径 0.72R 的圆（避开头顶羊毛和头饰）
  let total = 0, dark = 0, brightest = 0;
  const rr = R * 0.72;
  for (let ly = headY - rr; ly <= headY + rr; ly += 0.004) {
    for (let lx = 0.02 - rr; lx <= 0.02 + rr; lx += 0.004) {
      if (Math.hypot(lx - 0.02, ly - headY) > rr) continue;
      const x = Math.round(cx + lx * scale), y = Math.round(feetY - ly * scale);
      if (x < 0 || x >= W || y < 0 || y >= H) continue;
      const i = (y * W + x) * 4;
      const lum = (b[i] * 0.299 + b[i + 1] * 0.587 + b[i + 2] * 0.114) * 255;
      total++;
      brightest = Math.max(brightest, lum);
      if (lum < 110) dark++;
    }
  }
  const pct = total ? (dark / total * 100) : 0;
  // 正常情况：脸大部分是浅色，暗色只占眼睛/鼻子/嘴的一小块（< 35%）
  const ok = pct < 35;
  if (!ok) bad++;
  console.log(`${def.name.padEnd(6)}  ${pct.toFixed(1).padStart(6)}%             ${brightest.toFixed(0).padStart(4)}            ${ok ? 'OK' : '★ 脸被大面积覆盖'}`);
}
console.log(`\n${bad === 0 ? '全部正常' : `有 ${bad} 个角色异常`}`);
