/* 对打游戏 —— 战斗引擎（纯逻辑，不依赖 DOM / Canvas，可在 Node 中测试）
 *
 * 坐标系：x 向右，y 向下（和 Canvas 一致）。地面在 GROUND_Y，玩家站在地面上。
 * 所有判定都用“帧”为单位的时间（秒），招式有起手 / 命中 / 收招三段。
 */

export const WORLD = {
  w: 900,                 // 场地宽度
  groundY: 420,           // 地面高度（y 向下，所以越大越靠下）
  gravity: 2100,
  // 站台左右边界：站台之外是深坑，掉下去直接判负（不只靠血条赢）
  stageLeft: 150,
  stageRight: 750,
  pitY: 570,              // 掉到这个深度算落台
  wallLeft: 40,
  wallRight: 860
};

/* 某个 x 位置是否有地面（站台范围内才算） */
export function hasFloor(x) {
  return x >= WORLD.stageLeft && x <= WORLD.stageRight;
}

export const CFG = {
  walkSpeed: 235,
  runSpeed: 360,
  jumpSpeed: 720,
  airControl: 0.42,
  // 位移技：后跃（远离）与 前冲（突进），两者都带无敌帧
  dodgeSpeed: 420,
  dodgeInvuln: 0.22,
  dashSpeed: 520,
  dashInvuln: 0.18,
  maxHp: 100,
  roundsToWin: 2,               // 三局两胜
  roundTime: 60,                // 单局 60 秒
  hitStop: 0.055,               // 命中停顿
  blockReduce: 0.22,            // 防御时只吃到 22% 伤害
  chipDamage: 0.06,             // 防御也会掉一点点血，避免无限龟
  parryWindow: 0.14,            // 招架窗口
  parryStun: 0.55,              // 招架成功给对手的硬直
  grabRange: 64,
  rageMax: 100,
  rageOnDeal: 6,
  rageOnTake: 11,
  pushback: 120,                // 击退初速
  friction: 1500,
  // 受击框：跟着 Q 版造型校准（大头占身高 60%，所以框更宽更矮）
  bodyRadius: 26,
  bodyHeight: 96,
  startGap: 220                 // 双方开局间距
};

/* 招式表：每个招式定义 起手 / 生效 / 收招 时长与判定框、伤害、硬直
 * box 相对角色（x 向右为正向，之后按朝向镜像）
 */
export const MOVES = {
  light: {
    name: '轻击', startup: 0.07, active: 0.06, recovery: 0.13,
    damage: 5, hitStun: 0.20, knock: 90, box: { x: 22, y: -81, w: 56, h: 42 },
    rageGain: 5, cancelable: true, parry: true
  },
  heavy: {
    name: '重击', startup: 0.19, active: 0.09, recovery: 0.32,
    damage: 13, hitStun: 0.34, knock: 250, box: { x: 19, y: -97, w: 78, h: 61 },
    rageGain: 9, parry: true
  },
  kick: {
    name: '腿踢', startup: 0.13, active: 0.08, recovery: 0.24,
    damage: 10, hitStun: 0.30, knock: 170, box: { x: 17, y: -64, w: 86, h: 47 },
    rageGain: 8, parry: true
  },
  airKick: {
    name: '飞踢', startup: 0.06, active: 0.26, recovery: 0.10,
    damage: 12, hitStun: 0.32, knock: 210, box: { x: 11, y: -42, w: 78, h: 56 },
    rageGain: 8, air: true, parry: true
  },
  grab: {
    name: '抓投', startup: 0.11, active: 0.07, recovery: 0.34,
    damage: 20, hitStun: 0.52, knock: 430, box: { x: 17, y: -100, w: 61, h: 86 },
    rageGain: 6, throw: true, ignoresBlock: true, breakableByLight: true
  },
  special: {
    name: '必杀抓投', startup: 0.16, active: 0.12, recovery: 0.42,
    damage: 32, hitStun: 0.7, knock: 560, box: { x: 14, y: -109, w: 78, h: 103 },
    rageGain: 0, throw: true, ignoresBlock: true, needsRage: true, unbreakable: true
  }
};

/* ===== 角色属性接口 =====
 * 引擎本身不认识 characters 数据，由外部（或 main/test）显式套用这些倍率。
 */
export function applyFighterStats(f, st = {}) {
  f.hpMax = st.hpMax != null ? st.hpMax : CFG.maxHp;
  f.hp = f.hpMax;
  f.speedMul = st.speedMul != null ? st.speedMul : 1;
  f.damageMul = st.damageMul != null ? st.damageMul : 1;
  f.defenseMul = st.defenseMul != null ? st.defenseMul : 1;
  f.knockMul = st.knockMul != null ? st.knockMul : 1;
  f.grabMul = st.grabMul != null ? st.grabMul : 1;
  f.weightMul = st.weightMul != null ? st.weightMul : 1;
  return f;
}

// 伤害 = 招式伤害 × 攻击方加成 × 受击方减伤
// 抓投类招式额外吃角色的 grabMul（抓投专精），必杀不再叠加
// 平底锅生效期间，攻击方所有攻击额外增伤（这是红太狼打灰太狼的专属手段）
export function computeDamage(m, attacker, defender) {
  if (!m) return 0;
  let dmg = m.damage * (attacker.damageMul || 1) * (defender.defenseMul || 1);
  if (m.throw && !m.needsRage) dmg *= (attacker.grabMul || 1);
  if (panActive(attacker)) dmg *= (1 + PAN.damageBonus);
  return Math.round(dmg * 10) / 10;
}

// 击退 = 招式击退 × 攻击方击退加成 ÷ 受击方体重
export function computeKnock(m, attacker, defender) {
  if (!m) return 0;
  return m.knock * (attacker.knockMul || 1) / (defender.weightMul || 1);
}

/* ===== 角色状态 ===== */

export function createFighter(def, side, x) {
  return {
    def,
    side,                       // 'p1' | 'p2'
    x, y: WORLD.groundY,
    vx: 0, vy: 0,
    facing: side === 'p1' ? 1 : -1,
    onGround: true,
    hp: CFG.maxHp,
    rage: 0,
    // 动作状态机
    action: 'idle',             // idle | walk | jump | light | heavy | kick | airKick | grab | special | block | parry | dodge | hit | down | win
    actionT: 0,
    phase: '',                  // startup | active | recovery
    hasHit: false,              // 本次攻击是否已经命中过
    blockHold: false,
    parryT: 0,
    invuln: 0,
    hitStun: 0,
    combo: 0,
    comboT: 0,
    wins: 0,
    lastHitBy: null,
    hurtFlash: 0,
    landingLag: 0,
    // 属性倍率默认 1；用 applyFighterStats 套用角色数据
    hpMax: CFG.maxHp,
    speedMul: 1, damageMul: 1, defenseMul: 1, knockMul: 1, grabMul: 1, weightMul: 1,
    // 平底锅技能（红太狼专属，且只在对手是灰太狼时能用）
    panReady: 0,        // >0 表示正在生效，剩余秒数
    panCd: 0            // >0 表示冷却中，剩余秒数
  };
}

export function createMatch(p1def, p2def, opts = {}) {
  const mid = WORLD.w / 2;
  const s = {
    phase: 'intro',             // intro | fight | roundEnd | matchEnd
    phaseT: 1.2,
    round: 1,
    timer: CFG.roundTime,
    hitStop: 0,
    shake: 0,
    p1: createFighter(p1def, 'p1', mid - CFG.startGap / 2),
    p2: createFighter(p2def, 'p2', mid + CFG.startGap / 2),
    events: [],
    winner: null,
    roundWinner: null,
    floats: [],
    particles: []
  };
  s.p1.other = s.p2;
  s.p2.other = s.p1;
  return s;
}

/* ===== 工具 ===== */

export function activeMove(f) {
  return MOVES[f.action] || null;
}

// 取招式当前所处阶段
export function movePhase(f) {
  const m = activeMove(f);
  if (!m) return null;
  const t = f.actionT;
  if (t < m.startup) return 'startup';
  if (t < m.startup + m.active) return 'active';
  if (t < m.startup + m.active + m.recovery) return 'recovery';
  return 'done';
}

// 招式的世界判定框（按朝向镜像）
export function moveBox(f) {
  const m = activeMove(f);
  if (!m) return null;
  const b = m.box;
  const x = f.facing > 0 ? f.x + b.x : f.x - b.x - b.w;
  return { x, y: f.y + b.y, w: b.w, h: b.h };
}

export function bodyBox(f) {
  const r = CFG.bodyRadius;
  const h = CFG.bodyHeight || 100;
  return { x: f.x - r, y: f.y - h, w: r * 2, h };
}

export function overlaps(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

/* ===== 输入到动作 ===== */

export function canAct(f) {
  if (f.hitStun > 0 || f.landingLag > 0 || f.action === 'hit' || f.action === 'down' || f.action === 'win') return false;
  const m = activeMove(f);
  if (m && f.actionT < m.startup + m.active + m.recovery) {
    // 轻击可以在收招阶段取消成长击/腿踢，做出连段手感
    if (m.cancelable && f.actionT >= m.startup + m.active) return true;
    if (f.hasHit && f.actionT >= m.startup + m.active) return true;
    return false;
  }
  return true;
}

export function tryMove(f, moveKey) {
  const m = MOVES[moveKey];
  if (!m) return false;
  if (m.needsRage && f.rage < CFG.rageMax) return false;
  if (m.air && f.onGround) return false;
  if (!m.air && !f.onGround && moveKey !== 'airKick') {
    // 空中只能出飞踢
    return false;
  }
  if (!canAct(f)) return false;
  f.action = moveKey;
  f.actionT = 0;
  f.hasHit = false;
  f.phase = 'startup';
  if (m.needsRage) f.rage = 0;
  return true;
}

export function tryJump(f) {
  if (!f.onGround || !canAct(f)) return false;
  f.vy = -CFG.jumpSpeed * (1 - ((f.weightMul || 1) - 1) * 0.12);
  f.onGround = false;
  f.action = 'jump';
  f.actionT = 0;
  return true;
}

/* 闪避 / 前冲（同一个键，按方向区分）
 *   dir =  0 或未给  → 后跃（远离对手，用来躲招）
 *   dir =  1        → 前冲（朝对手突进，用来贴脸起手）
 * 两者都带无敌帧，所以前冲也能用来穿过对手的攻击。
 */
export function tryDodge(f, dir = 0) {
  if (!canAct(f) || !f.onGround) return false;
  const forward = dir > 0;
  f.action = forward ? 'dash' : 'dodge';
  f.actionT = 0;
  f.invuln = forward ? CFG.dashInvuln : CFG.dodgeInvuln;
  f.vx = (forward ? f.facing : -f.facing) * (forward ? CFG.dashSpeed : CFG.dodgeSpeed);
  return true;
}

/* ===== 命中结算 =====
 * 伤害与击退都经过 computeDamage / computeKnock，
 * 所以角色的 damageMul / defenseMul / knockMul / weightMul / grabMul 都生效。
 */

export function resolveHit(attacker, defender) {
  const m = activeMove(attacker);
  if (!m) return null;
  if (movePhase(attacker) !== 'active' || attacker.hasHit) return null;
  const hb = moveBox(attacker);
  const bb = bodyBox(defender);
  if (!overlaps(hb, bb)) return null;

  attacker.hasHit = true;

  // 无敌帧（后跃闪避）
  if (defender.invuln > 0) {
    return { type: 'whiff', move: attacker.action, reason: 'invuln' };
  }

  // 防御 / 招架：抓投无视防御
  const blocked = defender.blockHold && !m.ignoresBlock;
  const parried = defender.action === 'parry' && defender.parryT > 0 && !m.ignoresBlock;

  if (parried) {
    // 招架成功：攻击方进入长硬直，自己一点伤害都不吃
    attacker.hitStun = CFG.parryStun;
    attacker.action = 'hit';
    attacker.actionT = 0;
    attacker.vx = -attacker.facing * 120;
    defender.rage = Math.min(CFG.rageMax, defender.rage + 12);
    return { type: 'parry', move: m.name };
  }

  let dmg = computeDamage(m, attacker, defender);
  if (blocked) dmg = Math.max(1, dmg * CFG.blockReduce);
  dmg = Math.round(dmg * 10) / 10;

  // 血量按 100 为基准，但角色血量上限不同，所以用比例扣血
  const hpLoss = dmg * (CFG.maxHp / (defender.hpMax || CFG.maxHp));
  defender.hp = Math.max(0, defender.hp - hpLoss);
  defender.hurtFlash = 0.16;

  const knock = computeKnock(m, attacker, defender);

  if (!blocked) {
    // 平底锅生效期间，命中给对手更长硬直（更容易接上后续攻击）
    defender.hitStun = m.hitStun + (panActive(attacker) ? PAN.hitStunBonus : 0);
    defender.action = 'hit';
    defender.actionT = 0;
    defender.vx = attacker.facing * knock;
    if (m.throw) defender.vy = -260 * (m.needsRage ? 1.4 : 1);      // 被抓投会小抛一下
    // 连击计数
    attacker.combo++;
    attacker.comboT = 1.1;
  } else {
    defender.vx = attacker.facing * knock * 0.35;
  }

  // 怒气（平底锅生效期间攻击方攒得更快）
  defender.rage = Math.min(CFG.rageMax, defender.rage + CFG.rageOnTake);
  if (!blocked) {
    const gain = (m.rageGain || 4) + (panActive(attacker) ? PAN.rageBonus : 0);
    attacker.rage = Math.min(CFG.rageMax, attacker.rage + gain);
  }

  return {
    type: blocked ? 'block' : 'hit',
    move: m.name,
    damage: dmg,
    knock: blocked ? knock * 0.35 : knock,
    x: (hb.x + hb.w / 2 + bb.x + bb.w / 2) / 2,
    y: (hb.y + hb.h / 2 + bb.y + bb.h / 2) / 2,
    combo: attacker.combo
  };
}

/* ===== 平底锅（红太狼专属特殊技能）=====
 * 规则：只有 attacker 是红太狼、且 defender 是灰太狼时才可用。
 * 按下后进入 5 秒生效期：所有攻击附带额外伤害、额外怒气，命中给对手更长硬直。
 * 然后是 9 秒冷却。冷却期间按了没用。
 *
 * 注意：这里按角色 id 判断，而不是 import 角色表——
 * game.mjs 是纯逻辑模块，不该依赖 fighters.mjs（架构测试会拦住）。
 */
export const PAN = {
  ownerId: 'hongtailang',     // 谁持有这个技能
  targetId: 'huitailang',     // 只对谁生效
  name: '平底锅',
  cooldown: 9,                // 冷却（秒）
  duration: 5,                // 生效时长（秒）
  damageBonus: 0.55,          // 生效期间额外伤害倍率
  rageBonus: 4,               // 生效期间每次命中额外怒气
  hitStunBonus: 0.12          // 生效期间命中给对手更长硬直
};

export function panAvailable(attacker, defender) {
  return !!attacker && !!defender
    && attacker.def && attacker.def.id === PAN.ownerId
    && defender.def && defender.def.id === PAN.targetId;
}

export function tryUsePan(attacker, defender) {
  if (!panAvailable(attacker, defender)) return false;
  if (attacker.panCd > 0 || attacker.panReady > 0) return false;
  if (attacker.hitStun > 0 || attacker.action === 'hit' || attacker.action === 'down') return false;
  attacker.panReady = PAN.duration;
  attacker.panCd = PAN.cooldown + PAN.duration;   // 生效结束后才开始算冷却
  return true;
}

/* 平底锅是否正在生效 */
export function panActive(f) {
  return !!f && f.panReady > 0;
}

/* 给界面用：一句话描述当前状态 */
export function panStatus(f, defender) {
  if (!panAvailable(f, defender)) return { ok: false, text: '对手不是灰太狼', usable: false };
  if (panActive(f)) return { ok: true, text: '生效中', usable: false, active: true, remain: f.panReady };
  if (f.panCd > 0) return { ok: true, text: '冷却中', usable: false, cd: f.panCd };
  return { ok: true, text: '就绪', usable: true };
}

/* ===== 每帧推进 ===== */

export function update(s, inputs, dt) {
  dt = Math.min(dt, 0.05);
  if (s.hitStop > 0) {                    // 命中停顿：全场冻结，只消耗停顿时间
    s.hitStop = Math.max(0, s.hitStop - dt);
    stepVisuals(s, dt);
    return s;
  }
  s.shake = Math.max(0, s.shake - dt * 3);
  stepVisuals(s, dt);

  if (s.phase === 'intro') {
    s.phaseT -= dt;
    if (s.phaseT <= 0) { s.phase = 'fight'; s.events.push({ type: 'fight' }); }
    return s;
  }
  if (s.phase === 'roundEnd') {
    s.phaseT -= dt;
    updateWinnerPose(s, dt);
    if (s.phaseT <= 0) nextRound(s);
    return s;
  }
  if (s.phase === 'matchEnd') { updateWinnerPose(s, dt); return s; }

  // 计时
  s.timer -= dt;
  if (s.timer <= 0) {
    s.timer = 0;
    // 时间到：血多者胜，一样多算平局（双方都不加分，直接下一局）
    if (s.p1.hp === s.p2.hp) endRound(s, null, 'time');
    else endRound(s, s.p1.hp > s.p2.hp ? s.p1 : s.p2, 'time');
    return s;
  }

  for (const f of [s.p1, s.p2]) {
    updateFighter(s, f, inputs[f.side] || {}, dt);
  }
  // 双向命中判定（同一帧内两边都可能打中，先算先手）
  const a = resolveHit(s.p1, s.p2);
  if (a) applyHit(s, s.p1, s.p2, a);
  const b = resolveHit(s.p2, s.p1);
  if (b) applyHit(s, s.p2, s.p1, b);

  checkRoundEnd(s);
  return s;
}

function applyHit(s, attacker, defender, res) {
  s.events.push(res);
  if (res.type === 'hit' || res.type === 'block' || res.type === 'parry') {
    s.hitStop = CFG.hitStop * (res.type === 'hit' ? 1 : 0.5);
    s.shake = Math.min(1.2, s.shake + (res.type === 'hit' ? 0.5 : 0.25));
    s.floats.push({
      x: res.x, y: res.y, life: 1,
      text: res.type === 'parry' ? '招架!' : (res.type === 'block' ? '防御' : String(Math.round(res.damage))),
      color: res.type === 'parry' ? '#7ef0c8' : (res.type === 'block' ? '#9fb3d0' : '#ffce40')
    });
    for (let i = 0; i < (res.type === 'hit' ? 10 : 5); i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = 60 + Math.random() * 180;
      s.particles.push({
        x: res.x, y: res.y, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp - 80,
        life: 0.5, color: res.type === 'parry' ? '#7ef0c8' : '#ffd27a', size: 2 + Math.random() * 3
      });
    }
  }
}

export function updateFighter(s, f, input, dt) {
  f.actionT += dt;
  f.hurtFlash = Math.max(0, f.hurtFlash - dt);
  f.invuln = Math.max(0, f.invuln - dt);
  f.rage = Math.max(0, Math.min(CFG.rageMax, f.rage));   // 怒气必须钳在范围内
  if (f.landingLag > 0) f.landingLag = Math.max(0, f.landingLag - dt);
  // 平底锅：先扣生效时间，再走冷却
  if (f.panReady > 0) f.panReady = Math.max(0, f.panReady - dt);
  if (f.panCd > 0) f.panCd = Math.max(0, f.panCd - dt);
  f.comboT = Math.max(0, f.comboT - dt);
  if (f.comboT <= 0) f.combo = 0;
  if (f.parryT > 0) f.parryT = Math.max(0, f.parryT - dt);

  // 硬直
  if (f.hitStun > 0) {
    f.hitStun = Math.max(0, f.hitStun - dt);
    if (f.hitStun === 0 && f.action === 'hit') f.action = f.onGround ? 'idle' : 'jump';
  }

  // 朝向：面对对手（前冲/后跃过程中锁定朝向，否则会被自己冲过头带偏）
  if (f.onGround && f.action !== 'dodge' && f.action !== 'dash') {
    f.facing = f.other.x >= f.x ? 1 : -1;
  }

  // 动作推进
  const m = activeMove(f);
  if (m) {
    const total = m.startup + m.active + m.recovery;
    if (f.actionT >= total) f.action = f.onGround ? 'idle' : 'jump';
  }

  const acting = !canAct(f);

  // 防御：按住且在地面且没有出招
  const wantBlock = !!input.block && f.onGround && !acting;
  f.blockHold = wantBlock;
  f.parryT = wantBlock && input.blockPressed ? CFG.parryWindow : f.parryT;
  if (wantBlock) { f.action = 'block'; f.vx *= 0.6; }

  if (!acting) {
    // 水平移动
    const dir = (input.right ? 1 : 0) - (input.left ? 1 : 0);
    if (!wantBlock && dir !== 0) {
      const sp = (input.run ? CFG.runSpeed : CFG.walkSpeed) * (f.speedMul || 1) * (f.onGround ? 1 : CFG.airControl);
      f.vx = dir * sp;
      if (f.onGround) f.action = 'walk';
    } else if (f.onGround && f.action === 'walk') {
      f.action = 'idle';
    } else if (!f.onGround) {
      f.action = f.action === 'idle' ? 'jump' : f.action;
    }

    // 动作输入：优先级 必杀 > 抓投 > 重击 > 腿踢 > 轻击
    if (input.special && f.rage >= CFG.rageMax) tryMove(f, 'special');
    else if (input.grab) tryMove(f, 'grab');
    else if (input.heavy) tryMove(f, 'heavy');
    else if (input.kick) tryMove(f, 'kick');
    else if (input.light) tryMove(f, 'light');

    if (input.jump) {
      if (f.onGround) tryJump(f);
      else if (input.airKick) tryMove(f, 'airKick');
    }
    if (input.dodge) {
      // 按住方向（或 AI 明确指定）就是前冲，否则后跃
      tryDodge(f, input.dodgeForward || dir !== 0 ? 1 : 0);
    }
    // 空中飞踢也可以用腿踢键触发
    if (!f.onGround && input.kick) tryMove(f, 'airKick');
    // 平底锅：只有红太狼对灰太狼时才有意义，其它情况按了也无效
    if (input.pan && f.other) tryUsePan(f, f.other);
  }

  // 物理
  f.x += f.vx * dt;
  if (!f.onGround) {
    f.vy += WORLD.gravity * dt;
    f.y += f.vy * dt;
    // 只有在站台上方才能落地；站台之外是深坑，会一直掉下去
    if (f.y >= WORLD.groundY && hasFloor(f.x) && f.vy >= 0) {
      f.y = WORLD.groundY;
      f.vy = 0;
      f.onGround = true;
      if (f.action === 'jump' || f.action === 'airKick') f.action = 'idle';
      // 落地硬直（飞踢落地稍长）
      f.landingLag = f.action === 'airKick' ? 0.12 : 0.04;
    }
  } else {
    // 站在台下沿之后会失去支撑（走出去就掉）
    if (!hasFloor(f.x) && f.y >= WORLD.groundY - 1) {
      f.onGround = false;
    }
    // 地面摩擦
    if (!input.left && !input.right) {
      const dec = CFG.friction * dt;
      if (Math.abs(f.vx) <= dec) f.vx = 0;
      else f.vx -= Math.sign(f.vx) * dec;
    } else if (f.action !== 'idle' && f.action !== 'walk' && f.action !== 'block') {
      const dec = CFG.friction * 0.7 * dt;
      if (Math.abs(f.vx) <= dec) f.vx = 0;
      else f.vx -= Math.sign(f.vx) * dec;
    }
  }

  // 场地边界（撞墙，但不会被推出界）
  const half = CFG.bodyRadius;
  if (f.x < WORLD.wallLeft + half) { f.x = WORLD.wallLeft + half; f.vx = 0; }
  if (f.x > WORLD.wallRight - half) { f.x = WORLD.wallRight - half; f.vx = 0; }

  // 落台：掉到站台以下的深坑即判负
  if (f.y > WORLD.pitY) {
    s.events.push({ type: 'ringout', side: f.side });
    endRound(s, f.other, 'ringout');
  }
}

function updateWinnerPose(s, dt) {
  for (const f of [s.p1, s.p2]) {
    f.vx *= 0.9;
    f.x += f.vx * dt;
    if (!f.onGround) {
      f.vy += WORLD.gravity * dt;
      f.y = Math.min(WORLD.groundY, f.y + f.vy * dt);
      if (f.y >= WORLD.groundY) { f.y = WORLD.groundY; f.onGround = true; f.vy = 0; }
    }
  }
}

function stepVisuals(s, dt) {
  for (let i = s.floats.length - 1; i >= 0; i--) {
    const f = s.floats[i];
    f.y -= dt * 44; f.life -= dt * 1.2;
    if (f.life <= 0) s.floats.splice(i, 1);
  }
  for (let i = s.particles.length - 1; i >= 0; i--) {
    const p = s.particles[i];
    p.x += p.vx * dt; p.y += p.vy * dt;
    p.vy += 900 * dt;
    p.vx *= 0.94;
    p.life -= dt * 2;
    if (p.life <= 0) s.particles.splice(i, 1);
  }
}

/* ===== 回合流程 ===== */

export function checkRoundEnd(s) {
  if (s.phase !== 'fight') return;
  if (s.p1.hp <= 0 && s.p2.hp <= 0) return endRound(s, null, 'double');
  if (s.p1.hp <= 0) return endRound(s, s.p2, 'ko');
  if (s.p2.hp <= 0) return endRound(s, s.p1, 'ko');
  return null;
}

export function endRound(s, winner, reason) {
  if (s.phase !== 'fight') return;
  s.phase = 'roundEnd';
  s.phaseT = 1.9;
  s.roundWinner = winner ? winner.side : null;
  if (winner) {
    winner.wins++;
    winner.action = 'win';
    winner.actionT = 0;
    s.events.push({ type: 'roundWin', side: winner.side, reason, wins: winner.wins });
  } else {
    s.events.push({ type: 'roundDraw', reason });
  }
  if (winner && winner.wins >= CFG.roundsToWin) {
    s.phase = 'matchEnd';
    s.phaseT = 99;
    s.winner = winner.side;
    s.events.push({ type: 'matchWin', side: winner.side });
  }
}

export function nextRound(s) {
  s.round++;
  s.timer = CFG.roundTime;
  s.phase = 'intro';
  s.phaseT = 1.0;
  s.hitStop = 0; s.shake = 0;
  s.floats.length = 0; s.particles.length = 0;
  const mid = WORLD.w / 2;
  // 关键：这里必须“造一个全新的 fighter 对象”，不能用 Object.assign 覆盖旧对象。
  // Object.assign 不会删除旧对象上多出来的属性，上一局的技能冷却/生效状态
  // （panCd / panReady 这些后加的字段）会被带进新一局。这个坑我踩过一次。
  const carry = {};
  for (const f of [s.p1, s.p2]) carry[f.side] = { wins: f.wins, def: f.def };
  const mk = side => createFighter(
    carry[side].def, side,
    side === 'p1' ? mid - CFG.startGap / 2 : mid + CFG.startGap / 2
  );
  s.p1 = mk('p1');
  s.p2 = mk('p2');
  s.p1.wins = carry.p1.wins;
  s.p2.wins = carry.p2.wins;
  s.p1.other = s.p2;
  s.p2.other = s.p1;
  s.roundWinner = null;
  return s;
}

export function matchOver(s) {
  return s.phase === 'matchEnd';
}

/* ===== 简易 AI（给“练习模式”用）===== */

export function aiInput(s, f, level = 1) {
  const o = f.other;
  const dx = o.x - f.x;
  const dist = Math.abs(dx);
  const toward = dx > 0 ? 1 : -1;
  const inp = { left: false, right: false, jump: false, light: false, heavy: false, kick: false, grab: false, block: false, dodge: false, run: false, special: false };

  if (s.phase !== 'fight' || f.hitStun > 0) return inp;

  // 对手正在出招 → 有概率防御或招架
  const om = activeMove(o);
  const oAttacking = om && movePhase(o) === 'startup';
  if (oAttacking && dist < 110) {
    const r = Math.random();
    if (r < 0.30 + level * 0.12) { inp.block = true; inp.blockPressed = true; return inp; }
    if (r < 0.42 + level * 0.1) { inp.dodge = true; return inp; }
    // 中距离有概率前冲穿过对手的攻击，顺势贴脸
    if (r < 0.52 + level * 0.08 && dist > 60 && dist < 170) {
      inp.dodge = true;
      inp.dodgeForward = true;
      return inp;
    }
  }

  // 抓投来了就跳开或抢轻击
  if (om && om.name === '抓投' && movePhase(o) === 'startup' && dist < 90) {
    if (Math.random() < 0.5) inp.jump = true; else inp.light = true;
    return inp;
  }

  // 怒气满了就接近放必杀
  if (f.rage >= CFG.rageMax && dist < 90 && Math.random() < 0.5) { inp.special = true; return inp; }

  if (dist > 90) {
    if (toward > 0) inp.right = true; else inp.left = true;
    inp.run = dist > 220;
    if (dist > 260 && Math.random() < 0.02 * level) inp.jump = true;
    return inp;
  }

  // 近距离：随机攻击组合
  const r = Math.random();
  const rate = 0.06 + level * 0.05;
  if (r < rate) inp.light = true;
  else if (r < rate * 1.6) inp.heavy = true;
  else if (r < rate * 2.2) inp.kick = true;
  else if (r < rate * 2.7) inp.grab = true;
  else if (r < rate * 3.0) inp.block = true;
  else if (r < rate * 3.3) inp.dodge = true;
  else if (dist > 70) { if (toward > 0) inp.right = true; else inp.left = true; }
  return inp;
}

/* ===== 结算信息 ===== */

export function matchSummary(s) {
  return {
    winner: s.winner,
    round: s.round,
    p1: { name: s.p1.def.name, wins: s.p1.wins, hp: Math.round(s.p1.hp) },
    p2: { name: s.p2.def.name, wins: s.p2.wins, hp: Math.round(s.p2.hp) }
  };
}

export function drainEvents(s) {
  const out = s.events.slice();
  s.events.length = 0;
  return out;
}
