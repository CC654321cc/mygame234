/* 交付核查（纯静态：不 import 任何被测文件）
 *
 * 为什么不 import：如果某个模块语法坏了，Node 的模块加载器会先崩，
 * 核查脚本自己都跑不起来、也就给不出有用的信息。这里只读文件、解析文本，
 * 所以能第一时间告诉你「是哪个文件坏了」。
 * 运行时行为交给 game.test.mjs（130 项）与 smoke-single.mjs。
 */
import fs from 'node:fs';

let bad = 0;
const ok = m => console.log('  [OK]   ' + m);
const no = m => { bad++; console.log('  [问题] ' + m); };
const need = (c, m) => c ? ok(m) : no(m);
const read = f => fs.readFileSync(new URL(f, import.meta.url), 'utf8');
const exists = f => fs.existsSync(new URL(f, import.meta.url));

console.log('\n=== 羊村对决 交付核查（静态） ===\n');

/* ---------- 0. 语法自检（第一步） ---------- */
console.log('语法自检：');
const JS_FILES = ['main.mjs', 'game.mjs', 'fighters.mjs', 'fightersprite.mjs',
  'game.test.mjs', 'align.test.mjs', 'verify.mjs', 'build-single.mjs', 'smoke-single.mjs'];
const asPlain = src => src
  .replace(/^\s*import\s+[^;]*;?/gm, m => ' '.repeat(m.length))
  .replace(/^\s*export\s+/gm, m => ' '.repeat(m.length))
  .replace(/^\s*export\s*\{[^}]*\}\s*;?/gm, m => ' '.repeat(m.length))
  .replace(/import\.meta\.url|import\.meta/g, m => ' '.repeat(m.length));
for (const f of JS_FILES) {
  if (!exists(f)) { no(`缺少文件 ${f}`); continue; }
  let err = null;
  try {
    // eslint-disable-next-line no-new-func
    new Function(asPlain(read(f)));
  } catch (e) { err = e; }
  need(!err, `${f} 语法通过${err ? ' —— ' + err.message : ''}`);
}

/* ---------- 1. 单文件版（index.html） ---------- */
console.log('\n单文件版 index.html：');
const single = read('index.html');

/* 1a. 交付包里只能有一个“游戏入口”HTML —— 之前放了源码版，用户很容易双击错，
 * 结果停在“正在启动”。这条断言就是为了不再犯。
 * （浏览器检测.html 是纯诊断页，不加载游戏代码，不算入口。） */
const htmlFiles = fs.readdirSync(new URL('./', import.meta.url)).filter(f => /\.html?$/i.test(f));
const gameEntry = htmlFiles.filter(f => f !== '浏览器检测.html');
need(gameEntry.length === 1, `游戏入口只有一个 HTML（现在：${gameEntry.join(', ')}）`);
need(gameEntry[0] === 'index.html', '唯一的游戏入口是 index.html');
// 检测页自己不能引用游戏代码，避免又一次“打开错文件却看起来像游戏”
if (htmlFiles.includes('浏览器检测.html')) {
  const probe = read('浏览器检测.html');
  need(!probe.includes('type="module"'), '检测页不含 ES module（它也要能在 file:// 下直接开）');
  need(!probe.includes('function createMatch'), '检测页里没有游戏代码（它只是诊断工具）');
}

need(!single.includes('type="module"'), '不含 type="module"（否则 file:// 下会被 CORS 拦掉）');
need(!/^\s*(import|export)\b/m.test(single), '不含 import/export（已全部内联）');
need(single.includes('function createMatch'), '战斗引擎已内联');
need(single.includes('function drawFighter'), '角色绘制已内联');
need(single.includes('function aiInput'), 'AI（练习模式）已内联');
need(single.includes('id="boot"') && single.includes('id="bootMsg"'), '带启动遮罩（失败时有提示，不白屏）');
need(/#boot\{/.test(single), '启动了遮罩样式');
need(single.includes('yangcun-fight-ready'), '带启动握手');
// 内联脚本里不能出现会提前闭合标签的字面量
const blocks = [...single.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)];
need(blocks.length === 2, `内联脚本段数为 ${blocks.length}（应为 2：守卫 + 主代码）`);
need(!blocks.some(b => /<\/script/i.test(b[1])), '内联脚本里没有 </script 字面量');

/* ---------- 2. 双人键位不冲突 ---------- */
console.log('\n双人键位：');
const fightersSrc = read('fighters.mjs');
function blockOf(name) {
  const i = fightersSrc.indexOf(name);
  const j = fightersSrc.indexOf('}', i);
  return fightersSrc.slice(i, j);
}
const k1 = blockOf("p1: {");
const k2 = blockOf("p2: {");
const grabKeys = s => [...s.matchAll(/(?:left|right|jump|crouch|light|heavy|kick|grab|block|dodge|special|run):\s*'([^']+)'/g)].map(m => m[1]);
const K1 = grabKeys(k1), K2 = grabKeys(k2);
need(K1.length >= 12, `玩家 1 定义了 ${K1.length} 个键位`);
need(K2.length >= 12, `玩家 2 定义了 ${K2.length} 个键位`);
need(K1.filter(k => K2.includes(k)).length === 0, '两名玩家的按键完全不重叠（同一个键盘可同时操作）');
need(fightersSrc.includes('KEYS_ALT'), '提供了备用键位（笔记本没有小键盘时可用）');
need(fightersSrc.includes('KEY_LABEL'), '键位有可读名字（界面提示用）');

/* ---------- 3. 角色与招式 ---------- */
console.log('\n角色与招式：');
// 参考图里数出来是 7 个：红太狼 + 灰太狼 + 懒羊羊/喜羊羊/美羊羊/沸羊羊/暖羊羊。
// 灰太狼在游戏里是最终妖王，其余 7 个都是可选角色（共 8 人含熊大熊二）。
for (const [id, name] of [['xiyangyang', '喜羊羊'], ['lanyangyang', '懒羊羊'], ['meiyangyang', '美羊羊'],
  ['feiyangyang', '沸羊羊'], ['xiongda', '熊大'], ['xionger', '熊二'],
  ['nuanyangyang', '暖羊羊'], ['hongtailang', '红太狼'], ['huitailang', '灰太狼']]) {
  need(new RegExp(`id: '${id}'[\\s\\S]{0,400}?name: '${name}'`).test(fightersSrc), `${name} 已定义`);
}
need(/style: 'wall'/.test(fightersSrc), '暖羊羊定位为超厚血墙');
need(/style: 'queen'/.test(fightersSrc), '红太狼定位为高速高伤');
need(/style: 'boss'/.test(fightersSrc), '灰太狼定位为全能强敌');

/* ---------- 3b. 平底锅技能（红太狼专属，只对灰太狼生效） ---------- */
console.log('\n平底锅技能：');
// 注意：gameSrc0 必须在这里之前声明，否则会撞上暂时性死区（TDZ）报错
const gameSrc0 = read('game.mjs');
need(/export const PAN = \{/.test(gameSrc0), '引擎里定义了平底锅技能配置');
need(/cooldown: \d+/.test(gameSrc0), '技能有冷却时间');
need(/duration: \d+/.test(gameSrc0), '技能有生效时长（不是常驻）');
need(/damageBonus/.test(gameSrc0), '技能提供伤害加成');
need(/export function tryUsePan/.test(gameSrc0), '实现了技能触发');
need(/export function panAvailable/.test(gameSrc0), '有“谁对谁才可用”的判定');
need(/export function panActive/.test(gameSrc0), '有“是否正在生效”的查询');
need(/ownerId: 'hongtailang'/.test(gameSrc0), '技能持有者是红太狼');
need(/targetId: 'huitailang'/.test(gameSrc0), '技能只对灰太狼生效');
need(/panActive\(attacker\)[\s\S]{0,80}PAN\.damageBonus/.test(gameSrc0), '伤害计算里真的用上了技能加成');
need(/panActive\(attacker\) \? PAN\.hitStunBonus/.test(gameSrc0), '生效期间命中给更长硬直');
need(/panActive\(attacker\) \? PAN\.rageBonus/.test(gameSrc0), '生效期间命中攒更多怒气');
// 引擎不能反过来依赖角色表（架构约束）
need(!/from '\.\/fighters/.test(gameSrc0), 'game.mjs 不依赖 fighters.mjs（锅的规则写在引擎里）');
need(/input\.pan/.test(gameSrc0), '技能可以通过输入触发');

const mainSrc0 = read('main.mjs');
need(/pan: 'KeyO'/.test(fightersSrc) && /pan: 'Numpad8'/.test(fightersSrc), '两名玩家都分配了技能键');
need(/k\.pan && pressed\[k\.pan\]/.test(mainSrc0), '输入层读取技能键');
need(/panActive: panActive\(f\)/.test(mainSrc0), '把技能状态传给绘制层');
need(/if \(opts\.panActive\)/.test(read('fightersprite.mjs')), '画出了平底锅');
need(/id="p1skill"/.test(read('page.mjs')) && /id="p2skill"/.test(read('page.mjs')), 'HUD 有技能条');
need(/平底锅冷却/.test(mainSrc0), 'HUD 显示冷却剩余时间');
need(/平底锅生效中/.test(mainSrc0), 'HUD 显示生效剩余时间');
const spriteSrc0 = read('fightersprite.mjs');
need(/bigBody/.test(spriteSrc0), '大体型角色在绘制上真的画得更大（不只是数值）');
need(/function crown/.test(spriteSrc0) && /crown\(ctx/.test(spriteSrc0), '红太狼的皇冠已实现');
need(/function wolfEars/.test(spriteSrc0) && /wolfEars\(ctx/.test(spriteSrc0), '狼耳已实现');
need(/if \(f\.tail\)/.test(spriteSrc0) && /function wolfEars/.test(spriteSrc0), '狼尾与狼耳已实现');
need(/kind === 'wolf'/.test(spriteSrc0), '狼有独立的头部/躯干画法（不是换色羊）');
const gameSrc = read('game.mjs');
for (const m of ['light', 'heavy', 'kick', 'airKick', 'grab', 'special']) {
  need(new RegExp(`\\b${m}: \\{`).test(gameSrc), `招式 ${m} 已定义`);
}
need(/ignoresBlock: true/.test(gameSrc), '抓投无视防御（克制龟缩）');
need(/breakableByLight: true/.test(gameSrc) || /parry: true/.test(gameSrc), '抓投可被轻击干扰');
need(/parryWindow/.test(gameSrc), '有招架窗口');
need(/dodgeSpeed/.test(gameSrc) && /dashSpeed/.test(gameSrc), '有后跃与前冲两种位移');
need(/dashInvuln/.test(gameSrc) && /dodgeInvuln/.test(gameSrc), '前冲与后跃都带无敌帧');
need(/f\.action === 'dash'|'dash'/.test(read('fightersprite.mjs')), '前冲有对应姿态');
need(/rageMax/.test(gameSrc), '有怒气系统');
need(/roundsToWin/.test(gameSrc), '三局两胜');
need(/hasFloor/.test(gameSrc), '站台外是深坑（落台判负）');
need(/pitY/.test(gameSrc), '有落台判定深度');
need(/hitStop/.test(gameSrc), '有命中停顿');
need(/aiInput/.test(gameSrc), '有 AI（单人练习模式）');

/* ---------- 4. 工程文件与脚本 ---------- */
console.log('\n工程文件：');
for (const f of ['index.html', 'page.mjs', 'main.mjs', 'game.mjs', 'fighters.mjs',
  'fightersprite.mjs', 'game.test.mjs', 'align.test.mjs', 'build-single.mjs', 'smoke-single.mjs',
  'package.json', 'README.md']) {
  need(exists(f), `存在 ${f}`);
}
// 页面骨架必须来自 page.mjs，而不是依赖源码版 HTML
need(read('build-single.mjs').includes("from './page.mjs'"), '构建脚本从 page.mjs 取页面骨架（不再依赖源码版 HTML）');
need(!exists('index-dev.html'), '源码版 HTML 不在这套交付里（只保留一个入口，避免双击错文件）');
const pkg = JSON.parse(read('package.json'));
need(!!(pkg.scripts && pkg.scripts.build), 'package.json 里有 npm run build');
need(!!(pkg.scripts && pkg.scripts.test), 'package.json 里有 npm test');
need(!!(pkg.scripts && pkg.scripts.smoke), 'package.json 里有 npm run smoke');

/* ---------- 5. 架构：玩法 / 渲染 / 输入分离 ---------- */
console.log('\n架构：');
need(!/\bdocument\b/.test(gameSrc), 'game.mjs 不引用 document');
need(!/getElementById|createElement|getContext/.test(gameSrc), 'game.mjs 不碰 DOM / canvas API');
need(!/drawImage|fillRect|beginPath/.test(gameSrc), 'game.mjs 里没有任何绘制调用');
need(!/from '\.\/game/.test(read('fightersprite.mjs')), 'fightersprite.mjs 不反向依赖 game.mjs');
need(!/\bimport\b/.test(fightersSrc), 'fighters.mjs 是纯数据（不依赖其它模块）');

/* ---------- 6. 不用外部素材 ---------- */
console.log('\n素材依赖：');
const all = JS_FILES.map(f => exists(f) ? read(f) : '').join('\n') + single;
const imgRefs = (all.match(/['"][^'"]{2,}\.(png|jpg|jpeg|webp|gif|svg)['"]/gi) || []).filter(s => s.length > 6);
need(imgRefs.length === 0, `没有引用任何外部图片${imgRefs.length ? '：' + imgRefs.join(', ') : ''}`);
need(read('fightersprite.mjs').includes('drawFighter'), '角色走程序化绘制（参数化肢体）');
need(!/https?:\/\//i.test(single), '单文件版没有任何外链');

console.log('\n=== 结果 ===');
console.log(bad === 0 ? '全部通过' : `有 ${bad} 项不满足`);
process.exit(bad ? 1 : 0);
