/* 严格检查：模拟浏览器解析 index.html 的过程，找出任何会导致脚本被截断/不执行的问题。
 * 用法: node htmlcheck.mjs [文件]
 *
 * 浏览器经典脚本的转义规则（HTML 规范）：脚本内容里一旦出现
 *   <!--  <script  </script
 * 就会进入"转义状态"，可能提前结束脚本。这是非常经典的坑。
 */
import fs from 'node:fs';

const file = process.argv[2] || 'index.html';
const html = fs.readFileSync(file, 'utf8');
let bad = 0;
const ok = m => console.log('  [OK]   ' + m);
const no = m => { bad++; console.log('  [问题] ' + m); };

console.log(`=== 严格检查 ${file}（${html.length} 字符）===\n`);

/* 1. 按 HTML 规范的状态机找出所有 script 内容块 */
console.log('1. script 标签解析：');
const scriptRe = /<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi;
const blocks = [];
let m;
while ((m = scriptRe.exec(html)) !== null) {
  blocks.push({ attrs: m[1].trim(), code: m[2], at: m.index });
}
console.log(`   找到 ${blocks.length} 个 script 块`);
blocks.forEach((b, i) => {
  console.log(`     第${i + 1}块: 属性="${b.attrs}" 代码长度=${b.code.length}`);
});

/* 2. 检查是否有提前闭合：统计 <script 与 </script> 的数量是否配对 */
const opens = (html.match(/<script\b/gi) || []).length;
const closes = (html.match(/<\/script\s*>/gi) || []).length;
console.log('\n2. 标签配对：');
console.log(`   <script 出现 ${opens} 次，</script> 出现 ${closes} 次`);
if (opens === closes) ok('标签数量配对');
else no(`标签不配对（差 ${opens - closes}）`);

/* 3. 检查脚本内容里有没有会提前闭合的字面量 */
console.log('\n3. 脚本内容里的危险字面量：');
let danger = 0;
blocks.forEach((b, i) => {
  if (/<\/script/i.test(b.code)) { no(`第${i + 1}块里有 </script 字面量`); danger++; }
  // <!-- 或 <script 会触发 HTML 的"转义状态"
  if (/<!--/.test(b.code)) { no(`第${i + 1}块里有 <!-- （会进入转义状态）`); danger++; }
  if (/<script/i.test(b.code)) { no(`第${i + 1}块里有 <script 字面量`); danger++; }
});
if (!danger) ok('没有 </script / <!-- / <script 字面量');

/* 4. 是否是 module（file:// 下会被拦） */
console.log('\n4. 加载方式：');
const hasModule = blocks.some(b => /type\s*=\s*["']?module/i.test(b.attrs));
if (hasModule) no('含 type="module"（file:// 下会被 CORS 拦掉）');
else ok('全部是普通脚本（file:// 下可用）');
const extSrc = blocks.filter(b => /\bsrc\s*=/i.test(b.attrs));
if (extSrc.length) no(`有 ${extSrc.length} 个外链脚本（file:// 下可能被拦）`);
else ok('没有外链脚本');

/* 5. 外部资源引用 */
console.log('\n5. 外部资源：');
const ext = html.match(/(?:src|href)\s*=\s*["'](?!#)([^"']+)["']/gi) || [];
const nonHash = ext.filter(s => !/["']#/.test(s));
if (nonHash.length) no(`有 ${nonHash.length} 处外部引用：${nonHash.slice(0, 5).join(', ')}`);
else ok('没有任何外部资源引用');

/* 6. 关键内容是否都在 */
console.log('\n6. 关键内容：');
const checks = [
  ['游戏引擎', /function createMatch/],
  ['角色绘制', /function drawFighter/],
  ['AI', /function aiInput/],
  ['9 个角色名', /喜羊羊[\s\S]*懒羊羊[\s\S]*美羊羊[\s\S]*沸羊羊[\s\S]*熊大[\s\S]*熊二[\s\S]*暖羊羊[\s\S]*红太狼[\s\S]*灰太狼/],
  ['启动握手', /yangcun-fight-ready/],
  ['启动遮罩', /id="boot"/],
  ['双人键位', /Numpad1[\s\S]*KeyJ/]
];
for (const [name, re] of checks) {
  if (re.test(html)) ok(name); else no(`缺少 ${name}`);
}

/* 7. 编码（BOM / 非法字符） */
console.log('\n7. 编码：');
const buf = fs.readFileSync(file);
if (buf[0] === 0xEF && buf[1] === 0xBB && buf[2] === 0xBF) no('文件带 UTF-8 BOM（可能影响解析）');
else ok('没有 BOM');
if (buf.includes(0)) no('文件里有 NUL 字节');
else ok('没有 NUL 字节');
if (!/<meta[^>]+charset/i.test(html)) no('没有声明 charset');
else ok('声明了 charset');

console.log(`\n=== ${bad === 0 ? '全部通过，这个文件应该是能打开的' : `有 ${bad} 个问题`} ===`);
process.exit(bad ? 1 : 0);
