/* 角色立绘预览：把 9 个角色渲染成一张 PNG，用来肉眼检查造型。
 *
 * 为什么有它：我在浏览器里跑不了游戏，看不到自己画出来的角色。
 * 有了它就能"改代码 → 看图 → 再改"，而不是盲改。
 *
 * 用法:
 *   node preview.mjs [输出路径] [姿态] [缩放]
 *   node preview.mjs art/preview.png idle 46
 */
import fs from 'node:fs';
import path from 'node:path';
import { createSoftwareCanvas } from './softcanvas.mjs';
import { encodePNG } from './png.mjs';

const { ROSTER } = await import('./fighters.mjs');
const { drawFighter, POSES } = await import('./fightersprite.mjs');

const outPath = process.argv[2] || 'art/preview.png';
const pose = process.argv[3] || 'idle';
const SCALE = Number(process.argv[4] || 62);

const CELL_W = 150;
const CELL_H = 200;
const COLS = 5;
const ROWS = Math.ceil(ROSTER.length / COLS);
const W = CELL_W * COLS;
const H = CELL_H * ROWS + 30;

const ctx = createSoftwareCanvas(W, H);

// 背景（深色场地）+ 地面线
ctx.fillStyle = '#132238';
ctx.fillRect(0, 0, W, H);
ctx.fillStyle = 'rgba(255,255,255,0.14)';
ctx.fillRect(0, H - 26, W, 1);

ROSTER.forEach((def, i) => {
  const col = i % COLS;
  const row = Math.floor(i / COLS);
  const cx = col * CELL_W + CELL_W / 2;
  const feetY = row * CELL_H + CELL_H - 34;

  // 影子
  ctx.save();
  ctx.globalAlpha = 0.28;
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.ellipse(cx, feetY, 30, 7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  try {
    drawFighter(ctx, def, cx, feetY, pose, { facing: 1, scale: SCALE, time: 0.3 });
  } catch (e) {
    console.error('绘制 ' + def.name + ' 出错: ' + e.message);
  }
});

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, encodePNG(ctx._buf, W, H));
console.log(`已生成 ${outPath}  ${W}x${H}  姿态=${pose}  缩放=${SCALE}  角色=${ROSTER.length}`);
console.log('可用姿态: ' + Object.keys(POSES).join(', '));
