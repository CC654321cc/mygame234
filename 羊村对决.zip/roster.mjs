/* 开发用：把 9 个角色渲染成一张完整立绘（留足空间，不裁切）。
 * 用法: node roster.mjs [输出] [缩放]
 */
import fs from 'node:fs';
import { createSoftwareCanvas } from './softcanvas.mjs';
import { encodePNG } from './png.mjs';
import { ROSTER } from './fighters.mjs';
import { drawFighter } from './fightersprite.mjs';

const out = process.argv[2] || 'art/roster.png';
const scale = Number(process.argv[3] || 130);

const CELL_W = 170, CELL_H = 300;
const COLS = 5;
const ROWS = Math.ceil(ROSTER.length / COLS);
const W = CELL_W * COLS, H = CELL_H * ROWS + 30;
const ctx = createSoftwareCanvas(W, H);
ctx.fillStyle = '#132238';
ctx.fillRect(0, 0, W, H);
ctx.fillStyle = 'rgba(255,255,255,0.12)';
ctx.fillRect(0, H - 26, W, 1);

ROSTER.forEach((def, i) => {
  const col = i % COLS, row = Math.floor(i / COLS);
  const cx = col * CELL_W + CELL_W / 2;
  const feetY = row * CELL_H + CELL_H - 40;
  drawFighter(ctx, def, cx, feetY, 'idle', { facing: 1, scale, time: 0.3 });
});

fs.mkdirSync('art', { recursive: true });
fs.writeFileSync(out, encodePNG(ctx._buf, W, H));
console.log(`${out}  ${W}x${H}  scale=${scale}  ${ROSTER.length} 个角色`);
console.log('顺序: ' + ROSTER.map(r => r.name).join(' | '));
