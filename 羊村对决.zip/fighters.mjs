/* 角色数据：9 个 Q 版角色，外观参数供程序化绘制使用，属性决定了打法定位
 * 纯数据，不依赖 DOM / Canvas。
 *
 * 配色说明：下面所有颜色都是从用户提供的参考图上**实测取样**得到的
 * （见 art/_sampled_colors.json 与 analyze_ref.py 的输出），不是随手定的：
 *   狼毛 #707070/#808080 · 羊毛 #f5f0e6~#fffdf8 · 羊脸/吻部 #f0d0b0 · 腮红 #e0b0b0
 *
 * 属性说明：
 *   hp        血量倍率（1 = 标准 100 血）
 *   speed     走/跑速度倍率
 *   damage    伤害倍率
 *   defense   受伤倍率（越小越抗打）
 *   knock     攻击击退倍率（越大越容易把对手推下台）
 *   grabPower 抓投伤害倍率
 *   weight    体重（越大越不容易被击退，也越难跳高）
 */

export const ROSTER = [
  {
    id: 'xiyangyang',
    name: '喜羊羊',
    title: '轻捷剑客',
    desc: '速度最快，出手短促、连段流畅。适合贴脸打连击',
    style: 'rush',
    stats: { hp: 1.0, speed: 1.12, damage: 0.95, defense: 1.0, knock: 0.95, grabPower: 1.0, weight: 1.0 },
    colors: {
      kind: 'sheep', bodyColor: '#fffdf8', woolColor: '#fffdf8', faceColor: '#f7ead6',
      eyeColor: '#2b2118', blush: '#f0b8b8', hornColor: '#e0a060', hoofColor: '#c08850',
      scarf: '#5fc8f0', band: '#5fc8f0', bell: '#f5c84a'
    },
    features: { hornStyle: 'small', scarf: true, bell: true, bigEyes: true }
  },
  {
    id: 'lanyangyang',
    name: '懒羊羊',
    title: '惰性坦克',
    desc: '血厚、抗打，但移动慢。靠站桩硬吃换血',
    style: 'tank',
    stats: { hp: 1.22, speed: 0.88, damage: 1.05, defense: 0.86, knock: 1.1, grabPower: 1.15, weight: 1.25 },
    colors: {
      kind: 'sheep', bodyColor: '#fffdf8', woolColor: '#fffdf8', faceColor: '#f5d8b8',
      eyeColor: '#3a2a1c', blush: '#eeb0a8', hornColor: '#e0a060', hoofColor: '#c08850',
      sleepCap: '#8fa9ff', band: '#8fa9ff'
    },
    features: { hornStyle: 'small', sleepyEyes: true, drool: true, chubby: true }
  },
  {
    id: 'meiyangyang',
    name: '美羊羊',
    title: '长手快攻',
    desc: '腿最长、攻击距离最远，靠距离差压制对手',
    style: 'zoner',
    stats: { hp: 0.95, speed: 1.02, damage: 1.0, defense: 0.98, knock: 1.0, grabPower: 0.95, weight: 0.95 },
    colors: {
      kind: 'sheep', bodyColor: '#fffdf8', woolColor: '#fffdf8', faceColor: '#f7e2d0',
      eyeColor: '#3a2a1c', blush: '#f0b0b8', hornColor: '#e0a060', hoofColor: '#c08850',
      bow: '#e87ab0', scarf: '#f5c8dc', band: '#e87ab0'
    },
    features: { hornStyle: 'small', bow: true, blush: true, lashes: true, bigEyes: true }
  },
  {
    id: 'feiyangyang',
    name: '沸羊羊',
    title: '重拳力士',
    desc: '伤害最高、防御最硬，但出手慢。一拳定生死',
    style: 'power',
    stats: { hp: 1.14, speed: 0.95, damage: 1.22, defense: 0.9, knock: 1.3, grabPower: 1.25, weight: 1.25 },
    colors: {
      kind: 'sheep', bodyColor: '#fffdf8', woolColor: '#fffdf8', faceColor: '#f5d8b8',
      eyeColor: '#2b2118', blush: '#eeb0a8', hornColor: '#e0a060', hoofColor: '#c08850',
      headband: '#e8564a', shirt: '#f5d86a', band: '#e8564a'
    },
    features: { hornStyle: 'small', headband: true, brows: true, muscle: true, shirt: true }
  },
  {
    id: 'xiongda',
    name: '熊大',
    title: '均衡守卫',
    desc: '没有短板，攻守都能打。新手最好上手',
    style: 'balanced',
    stats: { hp: 1.18, speed: 0.97, damage: 1.08, defense: 0.94, knock: 1.15, grabPower: 1.1, weight: 1.2 },
    colors: {
      kind: 'bear', bodyColor: '#b9752f', bellyColor: '#f0d9b5', fur: '#b9752f',
      eyeColor: '#2b2118', noseColor: '#3a2a1c', blush: '#e8a0a0', band: '#d8a05b'
    },
    features: { ears: 'round', muzzle: true, brows: true, bigEyes: true }
  },
  {
    id: 'xionger',
    name: '熊二',
    title: '憨厚摔跤手',
    desc: '抓投伤害与击退最高，专门把对手扔下台',
    style: 'grappler',
    stats: { hp: 1.1, speed: 1.0, damage: 1.0, defense: 0.96, knock: 1.35, grabPower: 1.45, weight: 1.15 },
    colors: {
      kind: 'bear', bodyColor: '#d9a05b', bellyColor: '#f5e3c4', fur: '#d9a05b',
      eyeColor: '#2b2118', noseColor: '#3a2a1c', blush: '#e8a0a0', band: '#c98a4b'
    },
    features: { ears: 'round', muzzle: true, tongue: true, bigEyes: true }
  }
];

/* 暖羊羊：参考图右下角那只——**褐色脸 + 白羊毛**，体型最大 */
export const NUANYANGYANG = {
  id: 'nuanyangyang',
  name: '暖羊羊',
  title: '温柔巨壁',
  desc: '体型最大、血最厚、最抗打。伤害一般但站得住，适合硬顶着往前推',
  style: 'wall',
  stats: { hp: 1.38, speed: 0.82, damage: 0.98, defense: 0.78, knock: 1.05, grabPower: 1.2, weight: 1.5 },
  colors: {
    kind: 'sheep', bodyColor: '#fffdf8', woolColor: '#fffdf8', faceColor: '#a87050',
    eyeColor: '#2b1c12', blush: '#d89a90', hornColor: '#e0a060', hoofColor: '#8a5838',
    band: '#5fb0e0', scarf: '#5fb0e0'
  },
  features: { hornStyle: 'small', bigBody: true, blush: true, brows: true, scarf: true, darkFace: true }
};

/* 红太狼：戴皇冠、红裙、紫眼影。脆皮但速度与伤害都很高 */
export const HONGTAILANG = {
  id: 'hongtailang',
  name: '红太狼',
  title: '暴躁女王',
  desc: '血少但速度与伤害都高，还有最长的攻击距离。压着对手打，一旦被反打就很危险',
  style: 'queen',
  stats: { hp: 0.88, speed: 1.18, damage: 1.16, defense: 1.1, knock: 1.15, grabPower: 1.05, weight: 0.88 },
  colors: {
    kind: 'wolf', bodyColor: '#808080', woolColor: '#808080', faceColor: '#8c8c8c',
    eyeColor: '#2b2118', noseColor: '#2b2118', blush: '#e080a0', hoofColor: '#5a5a5a',
    crown: '#f5c84a', dress: '#c82a38', dressDark: '#96202c', band: '#c82a38',
    lid: '#b06fd0', tail: '#808080', furTrim: '#f0f0ee'
  },
  features: { kindWolf: true, crown: true, dress: true, glaringEyes: true, tail: true, lashes: true }
};

/* 灰太狼：参考图里那只戴帽子的狼。做成可选角色，这样"红太狼打灰太狼"随时能打出来
 * （红太狼的平底锅技能只在这个对局里能用）。 */
export const HUITAILANG = {
  id: 'huitailang',
  name: '灰太狼',
  title: '不死小强',
  desc: '血厚、伤害高、抓投也强，几乎没短板。缺点是出招偏慢，容易被快的角色抢先',
  style: 'boss',
  stats: { hp: 1.3, speed: 0.92, damage: 1.2, defense: 0.88, knock: 1.25, grabPower: 1.3, weight: 1.3 },
  colors: {
    kind: 'wolf', bodyColor: '#707070', woolColor: '#707070', faceColor: '#7a7a7a',
    eyeColor: '#2b2118', noseColor: '#1e1e1e', blush: '#d8828a', hoofColor: '#4e4e4e',
    hat: '#e8a04a', hatBand: '#c8503c', band: '#59a84f',
    bellyColor: '#f0e6c8', shirt: '#f5d86a', tail: '#707070', furTrim: '#f0f0ee'
  },
  features: { kindWolf: true, hat: true, brows: true, tail: true, fangs: true, shirt: true, bigEyes: true }
};

ROSTER.push(NUANYANGYANG, HONGTAILANG, HUITAILANG);

export function getChar(id) {
  return ROSTER.find(c => c.id === id) || ROSTER[0];
}

/* 平底锅技能的实际规则定义在 game.mjs 的 PAN 里
 * （引擎是纯逻辑模块，不依赖本文件，所以规则写在引擎侧；
 *   这里只记录角色是技能持有者/目标这件事，避免两处定义打架）。 */

/* 把角色数据套进战斗引擎的属性倍率里 */
export function applyStats(f, def) {
  const st = def.stats;
  f.hp = f.hpMax = Math.round(100 * st.hp);
  f.hpMax = Math.round(100 * st.hp);
  f.speedMul = st.speed;
  f.damageMul = st.damage;
  f.defenseMul = st.defense;
  f.knockMul = st.knock;
  f.grabMul = st.grabPower;
  f.weightMul = st.weight;
  return f;
}

/* 招式表展示用（选角界面显示各自的特点） */
export const STYLE_LABEL = {
  rush: '轻快连击',
  tank: '厚血站桩',
  zoner: '距离压制',
  power: '一击重创',
  balanced: '攻守均衡',
  grappler: '抓投大师',
  wall: '超厚血墙',
  queen: '高速高伤',
  boss: '全能强敌'
};

/* 双人键位：刻意分开放在键盘两侧，避免同时按冲突。
 * pan 是红太狼的平底锅技能（只有对手是灰太狼时才生效）。 */
export const KEYS = {
  p1: {
    label: '玩家 1（左手区）',
    left: 'KeyA', right: 'KeyD', jump: 'KeyW', crouch: 'KeyS',
    light: 'KeyJ', heavy: 'KeyK', kick: 'KeyL', grab: 'KeyI',
    block: 'KeyU', dodge: 'KeyY', special: 'KeyH', pan: 'KeyO', run: 'ShiftLeft'
  },
  p2: {
    label: '玩家 2（方向键区）',
    left: 'ArrowLeft', right: 'ArrowRight', jump: 'ArrowUp', crouch: 'ArrowDown',
    light: 'Numpad1', heavy: 'Numpad2', kick: 'Numpad3', grab: 'Numpad5',
    block: 'Numpad4', dodge: 'Numpad7', special: 'Numpad6', pan: 'Numpad8', run: 'ShiftRight'
  }
};

/* 键位的可读写法，用于界面提示 */
export const KEY_LABEL = {
  KeyA: 'A', KeyD: 'D', KeyW: 'W', KeyS: 'S',
  KeyJ: 'J', KeyK: 'K', KeyL: 'L', KeyI: 'I', KeyU: 'U', KeyY: 'Y', KeyH: 'H', KeyO: 'O',
  ArrowLeft: '←', ArrowRight: '→', ArrowUp: '↑', ArrowDown: '↓',
  Numpad1: '小键盘 1', Numpad2: '小键盘 2', Numpad3: '小键盘 3',
  Numpad4: '小键盘 4', Numpad5: '小键盘 5', Numpad6: '小键盘 6', Numpad7: '小键盘 7',
  Numpad8: '小键盘 8', Numpad9: '小键盘 9',
  ShiftLeft: '左 Shift', ShiftRight: '右 Shift'
};

/* 没有小键盘的键盘，给一套备用键位（P2 用右侧字母区） */
export const KEYS_ALT = {
  p2: {
    label: '玩家 2（备用键位，适合没有小键盘的笔记本）',
    left: 'ArrowLeft', right: 'ArrowRight', jump: 'ArrowUp', crouch: 'ArrowDown',
    light: 'Comma', heavy: 'Period', kick: 'Slash', grab: 'Semicolon',
    block: 'KeyM', dodge: 'Quote', special: 'BracketRight', pan: 'Backslash', run: 'ShiftRight'
  }
};

Object.assign(KEY_LABEL, {
  Comma: ',', Period: '.', Slash: '/', Semicolon: ';', KeyM: 'M', Quote: "'",
  BracketRight: ']', Backslash: '\\'
});
