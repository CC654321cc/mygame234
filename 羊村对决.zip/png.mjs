/* 开发用：把内存里的 RGBA 缓冲写成 PNG（只用 Node 自带的 zlib，无外部依赖）。
 * 用途：配合 softcanvas.mjs 在 Node 里把角色渲染成图片，方便亲眼检查造型。
 */
import zlib from 'node:zlib';

function crc32(buf) {
  let c, crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = (crc ^ buf[i]) & 0xff;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    crc = (crc >>> 8) ^ c;
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** rgba: Float32Array 或 Uint8Array，长度 w*h*4，0..255 或 0..1 */
export function encodePNG(rgba, w, h, { premultiplied = false } = {}) {
  const isFloat = rgba instanceof Float32Array;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  let o = 0;
  for (let y = 0; y < h; y++) {
    raw[o++] = 0;                              // filter: none
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      if (isFloat) {
        let r = rgba[i], g = rgba[i + 1], b = rgba[i + 2], a = rgba[i + 3];
        if (premultiplied && a > 0) { r /= a; g /= a; b /= a; }
        raw[o++] = Math.max(0, Math.min(255, Math.round(r * 255)));
        raw[o++] = Math.max(0, Math.min(255, Math.round(g * 255)));
        raw[o++] = Math.max(0, Math.min(255, Math.round(b * 255)));
        raw[o++] = Math.max(0, Math.min(255, Math.round(a * 255)));
      } else {
        raw[o++] = rgba[i]; raw[o++] = rgba[i + 1]; raw[o++] = rgba[i + 2]; raw[o++] = rgba[i + 3];
      }
    }
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8;      // bit depth
  ihdr[9] = 6;      // color type: RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 6 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}
