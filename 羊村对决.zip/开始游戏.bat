@echo off
chcp 65001 >nul
title 羊村对决
cd /d "%~dp0"

set GAME=%CD%\index.html
if not exist "%GAME%" (
  echo [错误] 同目录下找不到 index.html
  echo 请确保这个 bat 文件和 index.html 放在同一个文件夹里。
  echo.
  pause
  exit /b 1
)

echo ============================================
echo   羊村对决 · 双人对打
echo ============================================
echo.
echo 正在用浏览器打开游戏...
echo.

rem 优先用 Chrome / Edge：兼容性最好，也避免了某些预装浏览器缺 canvas 方法
set CHROME1=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe
set CHROME2=%ProgramFiles%\Google\Chrome\Application\chrome.exe
set CHROME3=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
set EDGE1=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe
set EDGE2=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe

if exist "%CHROME1%" (
  start "" "%CHROME1%" "%GAME%"
  goto opened
)
if exist "%CHROME2%" (
  start "" "%CHROME2%" "%GAME%"
  goto opened
)
if exist "%CHROME3%" (
  start "" "%CHROME3%" "%GAME%"
  goto opened
)
if exist "%EDGE1%" (
  start "" "%EDGE1%" "%GAME%"
  goto opened
)
if exist "%EDGE2%" (
  start "" "%EDGE2%" "%GAME%"
  goto opened
)

echo [提示] 没找到 Chrome 或 Edge，改用系统默认浏览器。
echo 如果游戏打不开，请先双击"浏览器检测.html"看看是哪一项不支持。
echo.
start "" "%GAME%"

:opened
echo 已打开。这个窗口可以关掉了。
timeout /t 3 >nul
