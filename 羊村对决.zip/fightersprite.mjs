/* 程序化绘制：可爱 Q 版萌系角色
 *
 * 设计要点（"萌"其实就是这几条的乘积）：
 *   - 大头：头径约占整个身高的 60%（约 2.5 头身），这是 Q 版的核心
 *   - 大眼：眼睛直径接近头宽的 1/4，带两颗高光（一颗大一颗小）
 *   - 圆润：所有部件都是圆角/圆形，四肢粗短、关节有圆头
 *   - 软：腮红、圆鼻子、w 形嘴、下垂/上挑的眉毛
 *   - 小：躯干短小，站在大头下面显得更可爱
 *
 * 坐标：脚底为原点，y 向上，整体约 1.5 个单位高（乘外部 scale 得到像素）。
 * 姿态角度沿用 POSES：0 = 竖直向下，正角 = 向角色正面（右）转。
 * 绘制时对外层做一次 x 取负，让"正角 = 向前伸手"成立。
 */

const TAU = Math.PI * 2;

/* ===== 身体比例（全部相对"脚底原点、y 向上"） =====
 * 用户反馈：照着参考图改的"小头+云朵羊毛"版本不好看，已回退到这个
 * **大头大眼萌系**版本（头径约占身高 60%），这是用户认可的造型。
 */
const P = {
  footY: 0.02,
  legLen: 0.30,          // 腿长（粗短）
  legR: 0.115,           // 腿半径（粗）
  hipY: 0.30,
  torsoTop: 0.64,        // 肩膀高度
  headR: 0.44,           // 头半径（很大）
  headY: 0.64 + 0.42,    // 头心高度
  armR: 0.10,
  eyeR: 0.125,           // 眼睛半径
  eyeYOff: -0.06,        // 眼睛在头心偏下
  eyeXOff: 0.175
};

/* ===== 基础图元 ===== */

function circle(ctx, x, y, r, fill) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fillStyle = fill;
  ctx.fill();
}

function ellipse(ctx, x, y, rx, ry, fill, rot = 0) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, rot, 0, TAU);
  ctx.fillStyle = fill;
  ctx.fill();
}

function roundRect(ctx, x, y, w, h, r, fill) {
  const rr = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

// 圆形描边（用来给眼睛/腮红加轮廓，让造型更"贴纸感"）
function ring(ctx, x, y, r, lw, color) {
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.strokeStyle = color;
  ctx.lineWidth = lw;
  ctx.stroke();
}

/* ===== 零件：眼睛 ===== */
/* 萌系眼睛 = 深色轮廓 + 白眼球 + 彩色虹膜 + 深瞳 + 大高光 + 小高光 */
function eye(ctx, x, y, r, c, mode, opt = {}) {
  const outline = c.eyeLine || '#3a2b22';
  if (mode === 'closed') {
    ctx.beginPath();
    ctx.strokeStyle = outline;
    ctx.lineWidth = r * 0.42;
    ctx.lineCap = 'round';
    ctx.moveTo(x - r * 0.85, y + r * 0.1);
    ctx.quadraticCurveTo(x, y + r * 0.55, x + r * 0.85, y + r * 0.1);
    ctx.stroke();
    return;
  }
  if (mode === 'happy') {          // ^ ^ 笑眼
    ctx.beginPath();
    ctx.strokeStyle = outline;
    ctx.lineWidth = r * 0.45;
    ctx.lineCap = 'round';
    ctx.moveTo(x - r * 0.9, y + r * 0.25);
    ctx.quadraticCurveTo(x, y - r * 0.75, x + r * 0.9, y + r * 0.25);
    ctx.stroke();
    return;
  }
  if (mode === 'sleepy') {         // 半闭的醉眼
    ctx.beginPath();
    ctx.strokeStyle = outline;
    ctx.lineWidth = r * 0.4;
    ctx.lineCap = 'round';
    ctx.moveTo(x - r * 0.95, y - r * 0.1);
    ctx.quadraticCurveTo(x, y + r * 0.7, x + r * 0.95, y - r * 0.1);
    ctx.stroke();
    return;
  }
  if (mode === 'angry') {          // 上挑的凶眼（保留大眼球，只是压低上眼睑）
    circle(ctx, x, y, r, '#ffffff');
    circle(ctx, x, y + r * 0.06, r * 0.74, c.iris || '#2b2118');
    circle(ctx, x, y + r * 0.12, r * 0.42, '#241b16');
    circle(ctx, x - r * 0.3, y - r * 0.28, r * 0.24, 'rgba(255,255,255,.95)');
    circle(ctx, x + r * 0.28, y + r * 0.34, r * 0.13, 'rgba(255,255,255,.8)');
    // 压低的上眼睑：一个比眼球更大的深色圆，往下压出凶相
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y + r * 1.62, r * 1.15, 0, TAU);
    ctx.fillStyle = outline;
    ctx.fill();
    ctx.restore();
    return;
  }
  // 默认：圆滚滚的大眼（只用实心填充，干净贴纸风）
  circle(ctx, x, y, r, '#ffffff');
  circle(ctx, x, y + r * 0.05, r * 0.78, c.iris || '#3b2a1f');
  circle(ctx, x, y + r * 0.1, r * 0.5, '#1e1712');
  circle(ctx, x - r * 0.32, y - r * 0.3, r * 0.28, 'rgba(255,255,255,.97)');
  circle(ctx, x + r * 0.3, y + r * 0.34, r * 0.15, 'rgba(255,255,255,.85)');
  if (opt.lashes) {                // 睫毛
    ctx.strokeStyle = outline;
    ctx.lineWidth = r * 0.16;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(x + r * 0.55, y - r * 0.85);
    ctx.lineTo(x + r * 1.15, y - r * 1.2);
    ctx.stroke();
  }
}

/* ===== 零件：耳朵 ===== */

/* 羊角：圆润的弯角（回退版：细长上翘，作为头顶装饰） */
function horns(ctx, hx, hy, r, style, color) {
  ctx.save();
  ctx.strokeStyle = color;
  ctx.lineCap = 'round';
  const w = style === 'thick' ? r * 0.2 : style === 'big' ? r * 0.19 : r * 0.15;
  ctx.lineWidth = w;
  const place = (s, len, curl) => {
    ctx.beginPath();
    ctx.moveTo(hx + s * r * 0.52, hy + r * 0.6);
    ctx.quadraticCurveTo(hx + s * r * (0.95 + curl), hy + r * (0.95 + len),
                         hx + s * r * (0.72 - curl), hy + r * (1.15 + len * 0.4));
    ctx.stroke();
  };
  if (style === 'curl') { place(-1, 0.16, 0.22); place(1, 0.16, 0.22); }
  else if (style === 'thick') { place(-1, 0.10, -0.12); place(1, 0.10, -0.12); }
  else if (style === 'big') { place(-1, 0.30, 0.1); place(1, 0.30, 0.1); }
  else { place(-1, 0.02, 0.02); place(1, 0.02, 0.02); }
  ctx.restore();
}

/* 熊耳：两个圆饼 */
function bearEars(ctx, hx, hy, r, color, inner) {
  for (const s of [-1, 1]) {
    circle(ctx, hx + s * r * 0.72, hy + r * 0.66, r * 0.34, color);
    circle(ctx, hx + s * r * 0.72, hy + r * 0.66, r * 0.18, inner);
  }
}

// 狼耳：尖三角
function wolfEars(ctx, hx, hy, r, color, inner) {
  for (const s of [-1, 1]) {
    const bx = hx + s * r * 0.5, by = hy + r * 0.52;
    ctx.beginPath();
    ctx.moveTo(bx - s * r * 0.2, by);
    ctx.lineTo(bx + s * r * 0.5, by + r * 0.82);
    ctx.lineTo(bx + s * r * 0.44, by - r * 0.02);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(bx - s * r * 0.02, by + r * 0.1);
    ctx.lineTo(bx + s * r * 0.32, by + r * 0.6);
    ctx.lineTo(bx + s * r * 0.3, by + r * 0.08);
    ctx.closePath();
    ctx.fillStyle = inner;
    ctx.fill();
  }
}

/* ===== 零件：头饰 ===== */

function crown(ctx, x, y, w, color) {
  const h = w * 0.42;
  ctx.beginPath();
  ctx.moveTo(x - w / 2, y);
  ctx.lineTo(x - w / 2, y + h * 0.5);
  ctx.lineTo(x - w * 0.26, y + h * 0.95);
  ctx.lineTo(x - w * 0.13, y + h * 0.15);
  ctx.lineTo(x, y + h * 0.8);
  ctx.lineTo(x + w * 0.13, y + h * 0.15);
  ctx.lineTo(x + w * 0.26, y + h * 0.95);
  ctx.lineTo(x + w / 2, y + h * 0.5);
  ctx.lineTo(x + w / 2, y);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  circle(ctx, x, y + h * 0.62, w * 0.055, '#ff6b81');
}

function bow(ctx, x, y, s, color) {
  ellipse(ctx, x - s * 0.62, y, s * 0.62, s * 0.4, color, -0.35);
  ellipse(ctx, x + s * 0.62, y, s * 0.62, s * 0.4, color, 0.35);
  circle(ctx, x, y, s * 0.26, color);
  // 蝴蝶结上的白点
  circle(ctx, x - s * 0.72, y - s * 0.1, s * 0.13, 'rgba(255,255,255,.85)');
  circle(ctx, x + s * 0.72, y - s * 0.1, s * 0.13, 'rgba(255,255,255,.85)');
}

/* ===== 主绘制 ===== */

export function drawFighter(ctx, def, x, y, pose, opts = {}) {
  const p = POSES[pose] || POSES.idle;
  const c = def.colors;
  const f = def.features || {};
  const s = opts.scale || 1;
  const facing = opts.facing || 1;
  const t = opts.time || 0;
  const bulk = f.bigBody ? 1.12 : 1;

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s * facing * bulk, -s * bulk);   // y 向上
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';

  const bob = p.bob ? Math.sin(t * 3.4) * 0.018 : 0;
  const cycle = p.cycle ? Math.sin(t * p.cycle) : 0;

  const limbColor = c.bodyColor;
  const dark = shade(limbColor, -0.16);
  const footColor = f.dress ? shade(c.dress, -0.18) : (c.hoofColor || dark);

  // 皮肤/毛色：羊是浅色脸，熊是口鼻色，狼是灰
  const headColor = c.kind === 'bear' ? limbColor : (c.kind === 'wolf' ? limbColor : (c.faceColor || '#fdf1e3'));

  const armAngle = a => -a;                  // POSES 约定 -> 绘制约定
  const limb = (x0, y0, a1, a2, l1, l2, r, fill) => {
    const A1 = armAngle(a1), A2 = armAngle(a1 + a2);
    const x1 = x0 + Math.cos(A1) * l1, y1 = y0 + Math.sin(A1) * l1;
    const x2 = x1 + Math.cos(A2) * l2, y2 = y1 + Math.sin(A2) * l2;
    ctx.save();
    ctx.strokeStyle = fill;
    ctx.lineWidth = r * 2;
    ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    ctx.lineWidth = r * 1.85;
    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.restore();
    circle(ctx, x1, y1, r * 0.98, fill);
    circle(ctx, x2, y2, r, fill);
    return { x: x2, y: y2 };
  };

  const hipY = P.hipY + bob;
  const chestY = P.torsoTop + bob;
  const headY = P.headY + bob;
  const R = P.headR;

  /* ---------- 后侧肢体 ---------- */
  limb(-0.08, hipY, p.legB[0] + cycle * 0.6, p.legB[1], P.legLen, P.legLen * 0.92, P.legR, shade(footColor, 0.08));
  limb(-0.10, chestY - 0.04, p.armB[0] - cycle * 0.45, p.armB[1], R * 0.72, R * 0.66, P.armR * 0.95, dark);

  // 尾巴（狼）
  if (f.tail) {
    ctx.save();
    ctx.strokeStyle = c.tail || limbColor;
    ctx.lineWidth = R * 0.26;
    ctx.beginPath();
    ctx.moveTo(-R * 0.62, hipY + 0.06);
    ctx.quadraticCurveTo(-R * 1.25, hipY + 0.3, -R * 1.3, hipY + 0.78);
    ctx.stroke();
    ctx.restore();
  }

  /* ---------- 躯干（短小圆润） ---------- */
  ctx.save();
  ctx.translate(0, hipY);
  ctx.rotate(-p.lean);
  ctx.translate(0, -hipY);
  const torsoH = chestY - hipY + R * 0.5;
  if (f.dress) {
    // 红太狼的红裙 + 白色毛领
    ellipse(ctx, 0, hipY + R * 0.1, R * 0.86, R * 0.44, c.dress);
    ellipse(ctx, 0, hipY + R * 0.62, R * 0.6, R * 0.36, shade(c.dress, -0.14));
    if (c.furTrim) {
      for (const [dx, dy, rr] of [[-0.5, 0.42, 0.2], [0.5, 0.42, 0.2], [0, 0.52, 0.22]]) {
        circle(ctx, dx * R, hipY + dy * R, rr * R * 0.8, c.furTrim);
      }
    }
  }
  roundRect(ctx, -R * 0.56, hipY - R * 0.16, R * 1.12, torsoH, R * 0.52, limbColor);
  if (c.kind === 'bear' || f.dress) {
    ellipse(ctx, 0, hipY + R * 0.34, R * 0.4, R * 0.4, c.bellyColor || shade(limbColor, 0.24));
  }
  if (f.shirt) {
    // 参考图里喜羊羊/沸羊羊/灰太狼都有上衣
    roundRect(ctx, -R * 0.54, hipY + R * 0.12, R * 1.08, torsoH * 0.78, R * 0.36, c.shirt);
  }
  if (c.kind === 'sheep') {
    // 羊的毛领：一圈可见轮廓的小圆瓣
    for (const [dx, dy, rr] of [[-0.44, 0.52, 0.21], [0.44, 0.52, 0.21], [0, 0.64, 0.23],
                                [-0.3, 0.18, 0.2], [0.3, 0.18, 0.2]]) {
      circle(ctx, dx * R, hipY + dy * R, rr * R * 0.62, c.woolColor || limbColor);
    }
  }
  if (c.scarf) roundRect(ctx, -R * 0.5, chestY - R * 0.2, R * 1.0, R * 0.26, R * 0.12, c.scarf);
  // 金铃铛（喜羊羊的标志）
  if (f.bell) {
    circle(ctx, 0, chestY - R * 0.34, R * 0.13, c.bell || '#f5c84a');
    circle(ctx, 0, chestY - R * 0.3, R * 0.05, shade(c.bell || '#f5c84a', -0.3));
  }
  ctx.restore();

  /* ---------- 前侧腿 + 前侧手臂 ----------
   * 顺序很关键：必须在"头"之前画，否则手臂会盖到脸上（大头 Q 版尤其明显）。 */
  const legColor = f.dress ? shade(c.dress, -0.12) : footColor;
  limb(0.07, hipY, p.legF[0] - cycle * 0.6, p.legF[1], P.legLen, P.legLen * 0.92, P.legR, legColor);
  const hand = limb(0.10, chestY - 0.10, p.armF[0] + cycle * 0.45, p.armF[1], R * 0.72, R * 0.66, P.armR, limbColor);
  if (f.muscle) circle(ctx, hand.x, hand.y, P.armR * 1.25, shade(limbColor, -0.08));

  /* ---------- 头（大） ---------- */
  ctx.save();
  ctx.translate(0, hipY);
  ctx.rotate(-p.lean);
  ctx.translate(0, -hipY);

  const hx = 0.02;

  // 熊耳/狼耳先画（在头后面，只露出耳廓）
  if (c.kind === 'bear') bearEars(ctx, hx, headY, R, limbColor, c.bellyColor || shade(limbColor, 0.3));
  if (c.kind === 'wolf') wolfEars(ctx, hx, headY, R, limbColor, shade(limbColor, 0.3));
  // 羊角先画（在头后面，从头顶两侧伸出）
  if (c.kind === 'sheep') horns(ctx, hx, headY, R, f.hornStyle || 'small', c.hornColor || '#e0a060');

  // 头（圆）
  circle(ctx, hx, headY, R, headColor);
  // 羊的额前卷毛（回退版：三团卷毛压在头顶，不做成云朵）
  if (c.kind === 'sheep') {
    for (const [dx, dy, rr] of [[-0.2, 0.62, 0.26], [0.2, 0.62, 0.26], [0, 0.74, 0.28]]) {
      circle(ctx, hx + dx * R, headY + dy * R, rr * R, c.woolColor || limbColor);
    }
  }

  // 五官布局：眼睛是重点，放在面部下半、尽量大
  const faceY = headY - R * 0.06;               // 面部中心（比头心略低）
  const eyeR2 = R * (f.bigEyes ? 0.30 : 0.26);
  const eyeDX = R * 0.36;
  const eyeY = faceY + R * 0.02;
  const eyeMode = p.eyes || 'open';
  const sleepy = f.sleepyEyes;
  const mode = (eyeMode === 'open' && sleepy) ? 'sleepy' : eyeMode;
  const lineColor = c.eyeLine || shade(headColor, -0.62);

  // 口鼻：小熊小狼的"小吻部"，放在面部下半（不能太大，否则糊住整张脸）
  const snoutY = faceY - R * 0.34;
  let snoutX = hx;
  if (c.kind === 'bear' || c.kind === 'wolf') {
    snoutX = hx + (c.kind === 'wolf' ? R * 0.14 : R * 0.02);
    const sr = R * (c.kind === 'wolf' ? 0.3 : 0.27);
    ellipse(ctx, snoutX, snoutY, sr, sr * 0.72,
            c.kind === 'bear' ? (c.bellyColor || shade(limbColor, 0.34)) : shade(limbColor, 0.28));
  }

  // 眼睛（画在最上层，保证清晰）
  eye(ctx, hx - eyeDX, eyeY, eyeR2, c, mode, { lashes: f.lashes });
  eye(ctx, hx + eyeDX, eyeY, eyeR2, c, mode, { lashes: f.lashes });

  // 红太狼的紫色眼影
  if (c.lid) {
    ellipse(ctx, hx - eyeDX, eyeY + eyeR2 * 0.95, eyeR2 * 1.05, eyeR2 * 0.28, c.lid);
    ellipse(ctx, hx + eyeDX, eyeY + eyeR2 * 0.95, eyeR2 * 1.05, eyeR2 * 0.28, c.lid);
  }

  // 眉毛（用填充的小色块，不用描边——描边路径在软件 canvas 里容易糊掉整张脸）
  if (f.brows || eyeMode === 'angry') {
    const by = eyeY + eyeR2 * 1.42;
    for (const s2 of [-1, 1]) {
      const bx = hx + s2 * eyeDX;
      const tilt = eyeMode === 'angry' ? s2 * R * 0.055 : 0;
      ctx.save();
      ctx.translate(bx, by + tilt);
      ctx.rotate(s2 * (eyeMode === 'angry' ? 0.32 : 0.12));
      ellipse(ctx, 0, 0, eyeR2 * 0.8, R * 0.035, lineColor);
      ctx.restore();
    }
  }

  // 鼻子 + 嘴
  if (c.kind === 'bear' || c.kind === 'wolf') {
    const nx = snoutX - R * 0.06;
    const ny = snoutY + R * 0.16;
    ellipse(ctx, nx, ny, R * 0.085, R * 0.065, c.noseColor || '#3a2a1c');
    if (f.fangs) {
      // 灰太狼的坏笑：深色嘴 + 白色尖牙（全部用填充）
      ellipse(ctx, snoutX + R * 0.02, ny - R * 0.2, R * 0.24, R * 0.13, '#4a2b2b');
      for (const k of [-0.13, 0.09]) {
        ctx.beginPath();
        ctx.moveTo(snoutX + k * R, ny - R * 0.16);
        ctx.lineTo(snoutX + (k + 0.085) * R, ny - R * 0.16);
        ctx.lineTo(snoutX + (k + 0.042) * R, ny - R * 0.33);
        ctx.closePath();
        ctx.fillStyle = '#ffffff';
        ctx.fill();
      }
    } else {
      // 小嘴：一个小色块 + 中间一小段竖线（都用填充）
      ellipse(ctx, snoutX + R * 0.01, ny - R * 0.13, R * 0.075, R * 0.035, lineColor);
      ellipse(ctx, nx, ny - R * 0.06, R * 0.018, R * 0.05, lineColor);
    }
  } else {
    // 羊：小圆鼻 + 用两段小填充当嘴（不用描边，避免描边路径把脸糊掉）
    const ny = snoutY + R * 0.1;
    ellipse(ctx, hx + R * 0.04, ny, R * 0.095, R * 0.075, c.noseColor || '#4a3a2c');
    // 嘴：两个小色块拼成 w 形（实心，稳）
    if (eyeMode === 'angry' || f.brows) {
      ellipse(ctx, hx + R * 0.04, ny - R * 0.16, R * 0.16, R * 0.035, lineColor);
    } else {
      ellipse(ctx, hx - R * 0.03, ny - R * 0.13, R * 0.055, R * 0.032, lineColor);
      ellipse(ctx, hx + R * 0.11, ny - R * 0.13, R * 0.055, R * 0.032, lineColor);
    }
  }

  // 腮红（萌系必备）：放在眼睛外侧偏下，别压到眼睛
  if (c.blush) {
    ctx.save();
    ctx.globalAlpha = 0.6;
    ellipse(ctx, hx - R * 0.7, eyeY - R * 0.06, R * 0.17, R * 0.1, c.blush);
    ellipse(ctx, hx + R * 0.7, eyeY - R * 0.06, R * 0.17, R * 0.1, c.blush);
    ctx.restore();
  }

  // 头饰
  if (f.headband) roundRect(ctx, hx - R * 0.92, headY + R * 0.5, R * 1.84, R * 0.22, R * 0.1, c.headband);
  if (f.crown) crown(ctx, hx + R * 0.02, headY + R * 0.72, R * 1.3, c.crown || '#ffd24a');
  if (f.hat) {
    // 灰太狼的帽子
    ellipse(ctx, hx + R * 0.06, headY + R * 0.78, R * 0.86, R * 0.3, c.hat || '#e2a33c');
    ellipse(ctx, hx + R * 0.06, headY + R * 0.9, R * 0.6, R * 0.24, c.hatBand || '#b8762a');
  }
  if (f.sleepCap) {
    ctx.beginPath();
    ctx.moveTo(hx - R * 0.9, headY + R * 0.5);
    ctx.quadraticCurveTo(hx, headY + R * 1.75, hx + R * 0.95, headY + R * 0.5);
    ctx.closePath();
    ctx.fillStyle = c.sleepCap || '#8fa9ff';
    ctx.fill();
    circle(ctx, hx + R * 0.16, headY + R * 1.62, R * 0.17, '#ffffff');
  }
  if (f.bow) bow(ctx, hx + R * 0.62, headY + R * 0.74, R * 0.3, c.bow || '#ff8fc8');
  if (f.drool) {
    ctx.save();
    ctx.globalAlpha = 0.8;
    ellipse(ctx, hx + R * 0.42, headY - R * 0.52, R * 0.06, R * 0.1, 'rgba(150,220,255,.9)');
    ctx.restore();
  }
  ctx.restore();

  /* ---------- 附着特效 ---------- */
  if (p.guard) {
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = '#8ec8ff';
    ctx.lineWidth = R * 0.1;
    ctx.beginPath();
    ctx.arc(0.16, chestY, R * 0.95, -1.1, 1.1);
    ctx.stroke();
    ctx.restore();
  }
  if (p.sparkle) {
    ctx.save();
    ctx.strokeStyle = 'rgba(126,240,200,.9)';
    ctx.lineWidth = R * 0.09;
    for (let i = 0; i < 3; i++) {
      const a = i * 2.1 + t * 3;
      ctx.beginPath();
      ctx.moveTo(hand.x, hand.y);
      ctx.lineTo(hand.x + Math.cos(a) * R * 0.6, hand.y + Math.sin(a) * R * 0.6);
      ctx.stroke();
    }
    ctx.restore();
  }
  if (p.glow) {
    ctx.save();
    ctx.globalAlpha = 0.4;
    circle(ctx, 0.1, chestY - 0.06, R * 1.5, 'rgba(255,120,60,.5)');
    ctx.restore();
  }
  // 平底锅（红太狼技能）
  if (opts.panActive) {
    const swing = (p.armF && p.armF[1] > 1.0) ? -0.5 : -1.1;
    ctx.save();
    ctx.globalAlpha = 0.32;
    circle(ctx, hand.x + R * 0.9, hand.y + R * 0.1, R * 0.9, 'rgba(255,170,70,.5)');
    ctx.restore();
    ctx.save();
    ctx.translate(hand.x, hand.y);
    ctx.rotate(swing);
    ctx.strokeStyle = '#5a4636';
    ctx.lineWidth = R * 0.16;
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(R * 0.95, 0); ctx.stroke();
    const px = R * 1.24;
    ctx.fillStyle = '#4b4f57';
    ctx.beginPath(); ctx.ellipse(px, 0, R * 0.46, R * 0.32, 0, 0, TAU); ctx.fill();
    ctx.fillStyle = '#6e737d';
    ctx.beginPath(); ctx.ellipse(px, 0, R * 0.33, R * 0.22, 0, 0, TAU); ctx.fill();
    ctx.restore();
  }

  ctx.restore();
}

/* ===== 姿态表 =====
 * 角度：0 = 竖直向下，正角 = 向角色正面（右）转。
 * 关键：主动作的"有效帧"要把肢体伸到判定框的位置。
 */
export const POSES = {
  idle: {
    bob: true,
    armF: [0.35, 0.55], armB: [-0.25, 0.4],
    legF: [0.12, 0.06], legB: [-0.14, 0.05],
    lean: 0.02, eyes: 'open'
  },
  walk: {
    cycle: 9,
    armF: [0.5, 0.8], armB: [-0.4, 0.75],
    legF: [0.5, 0.12], legB: [-0.42, 0.14],
    lean: 0.06, eyes: 'open'
  },
  jump: {
    armF: [0.9, 0.7], armB: [-0.8, 0.7],
    legF: [0.7, 0.5], legB: [-0.5, 0.6],
    lean: 0.05, eyes: 'open'
  },
  lightStartup: { armF: [0.3, 1.1], armB: [-0.5, 0.9], legF: [0.1, 0.1], legB: [-0.15, 0.1], lean: -0.06, eyes: 'open' },
  lightActive: { armF: [0, 1.62], armB: [-0.7, 0.7], legF: [0.18, 0.08], legB: [-0.22, 0.08], lean: 0.1, eyes: 'angry' },
  heavyStartup: { armF: [-0.9, 1.3], armB: [-0.9, 0.5], legF: [0.2, 0.15], legB: [-0.3, 0.15], lean: -0.18, eyes: 'angry' },
  heavyActive: { armF: [0.25, 1.85], armB: [-0.9, 0.5], legF: [0.45, 0.1], legB: [-0.5, 0.1], lean: 0.24, eyes: 'angry' },
  kickStartup: { armF: [0.6, 0.5], armB: [-0.6, 0.5], legF: [0.5, 0.2], legB: [-0.2, 0.1], lean: -0.12, eyes: 'angry' },
  kickActive: { armF: [0.9, 0.6], armB: [-0.9, 0.6], legF: [1.5, 0.12], legB: [-0.25, 0.2], lean: -0.26, eyes: 'angry' },
  airKickActive: {
    armF: [1.1, 0.5], armB: [-1.1, 0.5],
    legF: [1.2, 0.2], legB: [0.95, 0.25],
    lean: -0.2, eyes: 'angry', airborne: true
  },
  grabStartup: { armF: [0.2, 1.35], armB: [0.35, 1.3], legF: [0.15, 0.1], legB: [-0.2, 0.1], lean: 0.12, eyes: 'angry' },
  grabActive: { armF: [0, 1.7], armB: [0.05, 1.66], legF: [0.3, 0.1], legB: [-0.35, 0.1], lean: 0.2, eyes: 'angry' },
  specialActive: {
    armF: [-0.5, 2.1], armB: [-0.4, 2.05],
    legF: [0.5, 0.15], legB: [-0.5, 0.15],
    lean: -0.1, eyes: 'angry', glow: true
  },
  block: {
    armF: [0.1, 1.5], armB: [-0.1, 1.4],
    legF: [0.2, 0.1], legB: [-0.25, 0.1],
    lean: -0.1, eyes: 'open', guard: true
  },
  parry: {
    armF: [-0.3, 1.45], armB: [-0.5, 1.0],
    legF: [0.15, 0.1], legB: [-0.2, 0.1],
    lean: -0.14, eyes: 'angry', sparkle: true
  },
  dodge: {
    armF: [1.2, 0.4], armB: [-1.2, 0.4],
    legF: [0.9, 0.3], legB: [-0.6, 0.5],
    lean: -0.3, eyes: 'closed', airborne: true
  },
  dash: {
    armF: [1.5, 0.35], armB: [-1.0, 0.6],
    legF: [0.75, 0.35], legB: [-0.95, 0.2],
    lean: 0.42, eyes: 'angry', airborne: true
  },
  hit: {
    armF: [1.4, 0.3], armB: [1.2, 0.3],
    legF: [-0.4, 0.1], legB: [0.3, 0.1],
    lean: -0.5, eyes: 'closed'
  },
  down: {
    armF: [1.6, 0.2], armB: [1.5, 0.2],
    legF: [-0.8, 0.1], legB: [0.7, 0.1],
    lean: -1.1, eyes: 'closed', airborne: true
  },
  win: {
    armF: [2.6, 0.2], armB: [2.4, 0.2],
    legF: [0.1, 0.08], legB: [-0.1, 0.08],
    lean: 0.02, eyes: 'happy', bob: true
  }
};

/* 根据战斗状态挑姿态 */
export function pickPose(f, now = 0) {
  if (f.action === 'win') return 'win';
  if (f.action === 'down') return 'down';
  if (f.action === 'hit') return 'hit';
  if (f.action === 'dodge') return 'dodge';
  if (f.action === 'dash') return 'dash';
  if (f.action === 'block') return 'block';
  if (f.action === 'parry') return 'parry';

  const move = f.action;
  const ph = f.phase;
  if (move === 'light') return ph === 'active' ? 'lightActive' : (ph === 'startup' ? 'lightStartup' : 'idle');
  if (move === 'heavy') return ph === 'active' ? 'heavyActive' : (ph === 'startup' ? 'heavyStartup' : 'idle');
  if (move === 'kick') return ph === 'active' ? 'kickActive' : (ph === 'startup' ? 'kickStartup' : 'idle');
  if (move === 'airKick') return 'airKickActive';
  if (move === 'grab') return ph === 'active' ? 'grabActive' : (ph === 'startup' ? 'grabStartup' : 'idle');
  if (move === 'special') return ph === 'active' ? 'specialActive' : 'grabStartup';

  if (!f.onGround) return 'jump';
  if (f.action === 'walk') return 'walk';
  return 'idle';
}

/* 命中闪白 */
export function drawFighterFlash(ctx, def, x, y, pose, opts = {}) {
  ctx.save();
  ctx.globalAlpha = Math.min(0.85, opts.flash || 0);
  drawFighter(ctx, def, x, y, pose, opts);
  ctx.restore();
}

/* ===== 颜色工具 ===== */

const hexCache = new Map();
function parseHex(hex) {
  if (hexCache.has(hex)) return hexCache.get(hex);
  let h = String(hex).replace('#', '');
  if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
  const n = parseInt(h, 16);
  const out = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  hexCache.set(hex, out);
  return out;
}

export function shade(hex, amount) {
  const [r, g, b] = parseHex(hex);
  const f = v => Math.max(0, Math.min(255, Math.round(v + (amount > 0 ? (255 - v) * amount : v * amount))));
  const to2 = v => v.toString(16).padStart(2, '0');
  return '#' + to2(f(r)) + to2(f(g)) + to2(f(b));
}

/* 地面影子 */
export function drawShadow(ctx, x, groundY, y, scale) {
  const h = Math.max(0, groundY - y);
  const k = Math.max(0.35, 1 - h / 320);
  ctx.save();
  ctx.globalAlpha = 0.28 * k;
  ctx.beginPath();
  ctx.ellipse(x, groundY, 26 * scale * k, 8 * scale * k, 0, 0, TAU);
  ctx.fillStyle = '#000';
  ctx.fill();
  ctx.restore();
}
