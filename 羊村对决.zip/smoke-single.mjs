/* 单文件版冒烟测试
 *
 * 目的：在没有浏览器的前提下，尽可能确认 index.html 里的代码“真的能跑起来”：
 *   桩化 DOM / Canvas / 音频，把内联脚本在 Node 里真实执行，再跑主循环、模拟按键，
 *   检查有没有抛异常、有没有访问到页面里不存在的元素。
 *
 * 它不能替代真机试玩（手感、画面好不好看仍需你亲自看），但能挡住“白屏 / 报错”。
 */
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('./index.html', import.meta.url), 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
if (!scripts.length) { console.error('index.html 里没有内联脚本'); process.exit(1); }

const htmlIds = new Set([...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
const requestedIds = new Set();

// 启动握手事件名从产物里读出来，避免写死
const readyEvent = (html.match(/addEventListener\('([\w-]*ready)'/) || [])[1] || 'ready';
// 这个游戏是双人对打：要模拟两套键位
const P1_KEYS = ['KeyA', 'KeyD', 'KeyW', 'KeyJ', 'KeyK', 'KeyL', 'KeyI', 'KeyU', 'KeyY', 'KeyH', 'ShiftLeft'];
const P2_KEYS = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'Numpad1', 'Numpad2', 'Numpad3', 'Numpad5', 'Numpad4', 'Numpad7', 'Numpad6'];
const UI_KEYS = ['Escape', 'KeyR', 'F1'];

/* ---------- Canvas 2D 桩 ---------- */
function makeCtx() {
  const grad = { addColorStop() {} };
  const target = {
    canvas: { width: 0, height: 0, clientWidth: 1280, clientHeight: 720 },
    save() {}, restore() {}, translate() {}, scale() {}, rotate() {},
    beginPath() {}, closePath() {}, moveTo() {}, lineTo() {}, arc() {}, arcTo() {},
    ellipse() {}, rect() {}, fill() {}, stroke() {}, clip() {},
    fillRect() {}, strokeRect() {}, clearRect() {}, fillText() {}, strokeText() {},
    setLineDash() {}, getLineDash: () => [], drawImage() {}, measureText: () => ({ width: 0 }),
    createLinearGradient: () => grad, createRadialGradient: () => grad,
    createPattern: () => null, setTransform() {}, resetTransform() {},
    getImageData: () => ({ data: new Uint8ClampedArray(4) }), putImageData() {}
  };
  return new Proxy(target, {
    get(t, k) { return (k in t) ? t[k] : () => {}; },
    set(t, k, v) { t[k] = v; return true; }
  });
}

/* ---------- DOM 桩 ---------- */
function makeEl(id, tag = 'div') {
  const set = new Set();
  const el = {
    id, tagName: (tag || 'div').toUpperCase(), dataset: {}, style: {},
    textContent: '', innerHTML: '', width: 300, height: 150,
    clientWidth: 1280, clientHeight: 720, naturalWidth: 0, naturalHeight: 0,
    className: '', children: [], parentNode: null, onclick: null,
    classList: {
      add: c => set.add(c), remove: c => set.delete(c),
      toggle: (c, on) => { if (on === undefined) set.has(c) ? set.delete(c) : set.add(c); else on ? set.add(c) : set.delete(c); },
      contains: c => set.has(c)
    },
    getContext: () => makeCtx(),
    addEventListener() {}, removeEventListener() {}, dispatchEvent() { return true; },
    appendChild(c) { c.parentNode = this; this.children.push(c); return c; },
    removeChild(c) { this.children = this.children.filter(x => x !== c); return c; },
    querySelectorAll: () => [], querySelector: () => null,
    setPointerCapture() {}, releasePointerCapture() {},
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 1280, height: 720 }),
    focus() {}, blur() {}, remove() {}, insertAdjacentHTML() {}
  };
  return el;
}

const els = new Map();
const doc = {
  getElementById(id) {
    requestedIds.add(id);
    if (!htmlIds.has(id)) return null;              // 页面没有就返回 null，和浏览器一致
    if (!els.has(id)) els.set(id, makeEl(id));
    return els.get(id);
  },
  createElement: tag => makeEl('', tag),
  querySelector: () => null,
  querySelectorAll: () => [],
  addEventListener() {}, removeEventListener() {},
  body: makeEl('body', 'body'),
  documentElement: makeEl('html', 'html'),
  hidden: false, visibilityState: 'visible',
  pointerLockElement: null, exitPointerLock() {}
};

/* ---------- window 桩 ---------- */
const listeners = Object.create(null);
let rafCb = null, rafCount = 0;
function addEventListener(t, fn) { (listeners[t] ||= []).push(fn); }
const win = {
  innerWidth: 1280, innerHeight: 720, devicePixelRatio: 1,
  addEventListener, removeEventListener() {},
  dispatchEvent(e) { for (const fn of listeners[e && e.type] || []) fn(e); return true; },
  requestAnimationFrame(fn) { rafCb = fn; rafCount++; return rafCount; },
  cancelAnimationFrame() {},
  matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }),
  getComputedStyle: () => ({ getPropertyValue: () => '' }),
  location: { protocol: 'file:', href: 'file:///index.html' },
  AudioContext: function () {
    return {
      state: 'running', currentTime: 0, sampleRate: 44100, destination: {},
      resume() {},
      createOscillator: () => ({ type: '', frequency: { value: 0, setValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {}, start() {}, stop() {} }),
      createGain: () => ({ gain: { value: 0, setValueAtTime() {}, linearRampToValueAtTime() {}, exponentialRampToValueAtTime() {} }, connect() {} }),
      createBuffer: (ch, len) => ({ getChannelData: () => new Float32Array(len) }),
      createBufferSource: () => ({ buffer: null, connect() {}, start() {} }),
      createBiquadFilter: () => ({ type: '', frequency: { value: 0 }, connect() {} })
    };
  },
  CustomEvent: class { constructor(type, init) { this.type = type; this.detail = init && init.detail; } }
};

const sandbox = {
  window: win, document: doc,
  location: win.location,
  navigator: { userAgent: 'node', maxTouchPoints: 0 },
  matchMedia: win.matchMedia,
  // 浏览器里这些既是 window.X 也是全局变量，都要给
  devicePixelRatio: win.devicePixelRatio,
  innerWidth: win.innerWidth,
  innerHeight: win.innerHeight,
  addEventListener, removeEventListener: win.removeEventListener,
  dispatchEvent: win.dispatchEvent,
  requestAnimationFrame: win.requestAnimationFrame,
  cancelAnimationFrame: win.cancelAnimationFrame,
  AudioContext: win.AudioContext,
  CustomEvent: win.CustomEvent,
  performance, console,
  Math, Date, JSON, Object, Array, String, Number, Boolean, Set, Map, WeakMap,
  Uint8Array, Uint8ClampedArray, Float32Array, Int32Array, Error, TypeError, RangeError,
  parseInt, parseFloat, isNaN, isFinite,
  setTimeout, clearTimeout, setInterval, clearInterval
};
sandbox.globalThis = sandbox;
sandbox.self = sandbox;

/* ---------- 执行 ---------- */
const ctxObj = vm.createContext(sandbox);
let loadError = null;
const t0 = Date.now();
try {
  scripts.forEach((js, i) => vm.runInContext(js, ctxObj, { filename: `inline-${i + 1}.js` }));
} catch (e) { loadError = e; }
const loadMs = Date.now() - t0;

let frames = 0, frameError = null;
function pump(n, startT = null) {
  // 必须从“当前真实时间”开始往后推：如果时间戳比主循环记录的 last 还小，
  // dt 会变成负数，计时器就会反着走（这个坑我踩过，表现为入场动画永不结束）。
  let t = startT === null ? performance.now() : startT;
  for (let i = 0; i < n; i++) {
    const cb = rafCb;
    if (!cb) break;
    rafCb = null;
    t += 16;
    cb(t);
    frames++;
  }
}
if (!loadError) { try { pump(120); } catch (e) { frameError = e; } }

/* ---------- 交互冒烟：先测“最坏情况” ----------
 * 关键教训：我之前的桩太宽容（所有 API 都返回可用对象），
 * 只测到了顺利路径，所以“浏览器里一直停在正在启动”这种问题它抓不到。
 * 这里先模拟 getContext 返回 null，确认界面会把原因显示出来，而不是傻等。*/
function runOnce(htmlText, mutateSandbox) {
  const list = Object.create(null);
  const ids = new Set([...htmlText.matchAll(/id="([^"]+)"/g)].map(m => m[1]));
  const store = new Map();
  const mk = id => {
    const s = new Set();
    return {
      id, style: {}, dataset: {}, textContent: '', innerHTML: '', width: 300, height: 150,
      clientWidth: 800, clientHeight: 600, children: [], className: '',
      parentNode: { appendChild() {} },
      classList: { add: c => s.add(c), remove: c => s.delete(c), toggle: () => {}, contains: c => s.has(c) },
      getContext: () => makeCtx(),
      addEventListener() {}, removeEventListener() {}, dispatchEvent() { return true; },
      appendChild(c) { return c; }, querySelectorAll: () => [], querySelector: () => null,
      setPointerCapture() {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 600 })
    };
  };
  const document = {
    getElementById(id) {
      if (!ids.has(id)) return null;
      if (!store.has(id)) store.set(id, mk(id));
      return store.get(id);
    },
    createElement: () => mk(''), querySelector: () => null, querySelectorAll: () => [],
    addEventListener() {}, body: mk('body'), documentElement: mk('html'), hidden: false
  };
  let raf = null;
  const sb = {
    document, console, Math, Date, JSON, Object, Array, String, Number, Boolean, Set, Map, WeakMap,
    Uint8Array, Uint8ClampedArray, Float32Array, Int32Array, Error, TypeError, RangeError,
    parseInt, parseFloat, isNaN, isFinite, performance, setTimeout, clearTimeout, setInterval, clearInterval,
    devicePixelRatio: 1, innerWidth: 800, innerHeight: 600,
    navigator: { userAgent: 'node' },
    matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }),
    addEventListener: (t, fn) => { (list[t] ||= []).push(fn); },
    removeEventListener() {},
    dispatchEvent: e => { for (const fn of list[e && e.type] || []) fn(e); return true; },
    requestAnimationFrame: fn => { raf = fn; return 1; },
    cancelAnimationFrame() {},
    location: { protocol: 'file:', href: 'file:///index.html' },
    CustomEvent: class { constructor(t, i) { this.type = t; this.detail = i && i.detail; } }
  };
  sb.window = sb; sb.self = sb; sb.globalThis = sb;
  if (mutateSandbox) mutateSandbox(sb, document);
  const ctxObj = vm.createContext(sb);
  for (const js of [...htmlText.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1])) {
    vm.runInContext(js, ctxObj, { filename: 'inline.js' });
  }
  return { store, list, ctxObj, doc: document };
}

let failCaseOk = null, failCaseMsg = '';
try {
  // 让 canvas 拿不到 2D 上下文（真实浏览器里可能是显卡/驱动问题）
  const r = runOnce(html, (sb, doc) => {
    const orig = doc.getElementById.bind(doc);
    doc.getElementById = id => {
      const el = orig(id);
      if (el && id === 'cv') el.getContext = () => null;
      return el;
    };
  });
  const boot = r.store.get('boot');
  const msgEl = r.store.get('bootMsg');
  const hidden = boot && boot.classList.contains('hide');
  failCaseMsg = (msgEl && (msgEl.textContent || '')) || '';
  // 期望：要么给出错误提示，要么至少没假装成功
  failCaseOk = !hidden && failCaseMsg.length > 0;
} catch (e) { failCaseOk = false; failCaseMsg = '抛异常: ' + e.message; }

/* ---------- 交互冒烟 ---------- */
let interactError = null;
let actionsDone = [];
let fight = null;
if (!loadError && !frameError) {
  try {
    const fire = (code, type = 'keydown') => win.dispatchEvent({ type, code, key: code, preventDefault() {} });

    // 1) 先真正开一局（选角界面靠点击，桩里点不了，所以走自检入口）
    const canStart = vm.runInContext('typeof window.__startFight === "function"', ctxObj);
    if (canStart) {
      vm.runInContext('window.__startFight("pvp", "xiyangyang", "feiyangyang")', ctxObj);
      pump(90);                                   // 跑过入场动画进入战斗
    }
    actionsDone.push('开一局');

    // 2) 双人按键全按一遍（含每个招式键）
    for (const k of [...P1_KEYS, ...P2_KEYS, ...UI_KEYS]) {
      fire(k, 'keydown');
      pump(6);
      fire(k, 'keyup');
      pump(2);
      actionsDone.push(k);
    }

    // 3) 让双方持续互相攻击，逼出命中/受击/硬直这些分支
    for (let round = 0; round < 40; round++) {
      fire('KeyJ'); fire('Numpad1'); fire('KeyK'); fire('Numpad2');
      pump(4);
      fire('KeyJ', 'keyup'); fire('Numpad1', 'keyup');
      fire('KeyK', 'keyup'); fire('Numpad2', 'keyup');
      pump(8);
    }
    pump(120);

    fight = vm.runInContext('window.__fight()', ctxObj);
  } catch (e) { interactError = e; }
}

/* 重开一局，确认真能重置（按 R 只在比赛结束后生效，这里直接再开一局） */
let restartOk = null;
if (!loadError && !frameError && !interactError) {
  try {
    vm.runInContext('window.__startFight("pvp", "xionger", "meiyangyang")', ctxObj);
    pump(90);
    const f2 = vm.runInContext('window.__fight()', ctxObj);
    restartOk = f2 && f2.hasState && f2.p1.name === '熊二' && f2.p2.name === '美羊羊';
  } catch (e) { restartOk = false; }
}

/* ---------- 结果 ---------- */
let bad = 0;
const ok = m => console.log('  [OK]   ' + m);
const no = m => { bad++; console.log('  [问题] ' + m); };

console.log('\n=== 对打游戏 单文件版冒烟测试 ===\n');
console.log(`内联脚本 ${scripts.length} 段，加载耗时 ${loadMs}ms，握手事件 "${readyEvent}"\n`);

console.log('加载阶段：');
if (loadError) no('执行时抛异常：' + loadError.message + '\n        ' + (loadError.stack || '').split('\n')[1]);
else ok('内联脚本全部执行成功，没有抛异常');

console.log('\n主循环：');
if (frameError) no('跑帧时抛异常：' + frameError.message + '\n        ' + (frameError.stack || '').split('\n')[1]);
else ok(`连续执行 ${frames} 帧，没有抛异常`);

console.log('\n关键元素：');
const phantom = [...requestedIds].filter(id => !htmlIds.has(id));
if (phantom.length) no('代码请求了页面里不存在的 id：' + phantom.join(', '));
else ok(`代码请求的 ${requestedIds.size} 个 id 在页面里都存在`);
const EXPECT = ['cv', 'p1hp', 'p2hp', 'p1rage', 'p2rage', 'p1name', 'p2name', 'timer', 'sheet', 'toast', 'pauseBtn', 'boot'];
const untouched = EXPECT.filter(id => !requestedIds.has(id));
if (untouched.length) no('这些关键元素代码根本没去找：' + untouched.join(', '));
else ok('血条 / 怒气 / 面板 / 提示等关键元素都被触碰到了');

console.log('\n启动握手：');
if (listeners[readyEvent] && listeners[readyEvent].length) ok(`守卫注册了 ${readyEvent} 监听`);
else no(`守卫没有注册 ${readyEvent} 监听`);
const boot = els.get('boot');
if (boot && boot.classList.contains('hide')) ok('主代码派发了 ready，启动遮罩已隐藏');
else no('启动遮罩没有隐藏（ready 没派发或守卫没收到）');

console.log('\n交互冒烟：');
if (interactError) no('模拟按键时抛异常：' + interactError.message + '\n        ' + (interactError.stack || '').split('\n')[1]);
else ok(`模拟了 ${actionsDone.length} 个动作（含双人全部招式键与 Esc/R/F1），主循环依然正常`);

console.log('\n战斗真的在跑：');
if (!fight || !fight.hasState) {
  no('没有进入对局状态（state 为空）');
} else {
  ok(`已开局：${fight.p1.name} ${fight.p1.hp}/${fight.p1.hpMax} vs ${fight.p2.name} ${fight.p2.hp}/${fight.p2.hpMax}`);
  const dmg1 = fight.p1.hpMax - fight.p1.hp;
  const dmg2 = fight.p2.hpMax - fight.p2.hp;
  if (dmg1 > 0 || dmg2 > 0) ok(`互相攻击造成了伤害（掉血 ${dmg1.toFixed(0)} / ${dmg2.toFixed(0)}）`);
  else no('双方都毫发无损——攻击可能没生效');
  if (fight.phase === 'fight' || fight.phase === 'roundEnd' || fight.phase === 'intro') ok(`对局阶段正常：${fight.phase}`);
  else no('对局阶段异常：' + fight.phase);
  if (fight.round >= 1) ok(`局数正常：第 ${fight.round} 局`);
}
if (restartOk === true) ok('换角色重开一局成功（熊二 vs 美羊羊）');
else if (restartOk === false) no('换角色重开一局失败');

console.log('\n最坏情况（canvas 拿不到 2D 上下文）：');
if (failCaseOk) ok(`界面给出了提示而不是干等：「${failCaseMsg.slice(0, 48)}」`);
else no('界面没有给出任何提示（用户会一直看到"正在启动"）——' + failCaseMsg);

console.log('\n=== 结果 ===');
console.log(bad === 0 ? '全部通过：单文件版能加载、能跑帧、能握手、能响应双人按键' : `有 ${bad} 项不通过`);
process.exit(bad ? 1 : 0);
