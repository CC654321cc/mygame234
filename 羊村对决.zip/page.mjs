/* 页面骨架（由 index-dev.html 抽取而来）
 * 单独放一个文件，这样构建脚本不再依赖源码版 HTML——
 * 交付包里就能只留一个 index.html，避免用户双击错文件。
 * 改页面结构/样式请改这里，然后重新执行 node build-single.mjs。
 */
export const HEAD = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<title>羊村对决 · 双人对打</title>
<style>
  :root{
    --ink:#eaf4ff; --dim:#9fb3d0; --line:rgba(150,210,255,.22);
    --p1:#4de3ff; --p2:#ff8fc8; --gold:#ffce40; --green:#7ef0c8;
    --panel:rgba(10,16,28,.86);
  }
  *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
  html,body{height:100%;margin:0;overflow:hidden;background:#08111a}
  body{color:var(--ink);font-family:"Segoe UI","PingFang SC","Microsoft YaHei",system-ui,sans-serif;user-select:none}
  #stage{position:fixed;inset:0}
  canvas{display:block;width:100%;height:100%}

  .hud{position:fixed;pointer-events:none}

  /* 顶部：双方血条镜像相对 */
  #top{top:12px;left:0;right:0;display:flex;align-items:flex-start;gap:14px;padding:0 18px}
  .side{flex:1;display:flex;flex-direction:column;gap:5px}
  .side.p2{align-items:flex-end}
  .nameRow{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:800}
  .side.p2 .nameRow{flex-direction:row-reverse}
  .wins{display:flex;gap:4px}
  .pip{width:11px;height:11px;border-radius:50%;border:1.5px solid var(--line);background:rgba(255,255,255,.05)}
  .pip.on{background:var(--gold);border-color:var(--gold);box-shadow:0 0 8px rgba(255,206,64,.8)}
  .bar{position:relative;height:20px;border-radius:10px;background:rgba(0,0,0,.5);border:1px solid var(--line);overflow:hidden}
  .bar > i{position:absolute;top:0;bottom:0;width:100%;transition:width .12s linear}
  .side.p1 .bar > i{left:0;background:linear-gradient(90deg,#2ec5ff,#7ef0c8)}
  .side.p2 .bar > i{right:0;background:linear-gradient(270deg,#ff5d9e,#ffc2e0)}
  /* 血条残影（掉血时慢慢收） */
  .bar > u{position:absolute;top:0;bottom:0;width:100%;background:rgba(255,255,255,.28);transition:width .5s ease .1s}
  .side.p1 .bar > u{left:0}
  .side.p2 .bar > u{right:0}
  .rage{position:relative;height:7px;border-radius:4px;background:rgba(0,0,0,.5);border:1px solid var(--line);overflow:hidden}
  .rage > i{position:absolute;top:0;bottom:0;width:0;background:linear-gradient(90deg,#ff9d3c,#ffe066)}
  .side.p1 .rage > i{left:0}
  .side.p2 .rage > i{right:0}
  .rage.full > i{box-shadow:0 0 10px rgba(255,206,64,.9)}
  /* 平底锅技能条：就绪=金色常亮，生效中=橙色闪烁，冷却中=进度回填，不可用=灰暗 */
  .skill{position:relative;height:7px;border-radius:4px;background:rgba(0,0,0,.5);
    border:1px solid var(--line);overflow:hidden;margin-top:2px}
  .skill > i{position:absolute;top:0;bottom:0;width:0;background:linear-gradient(90deg,#ffd24a,#ff9d3c)}
  .side.p1 .skill > i{left:0}
  .side.p2 .skill > i{right:0}
  .skill > span{position:absolute;left:0;right:0;top:-1px;font-size:9px;letter-spacing:.08em;
    color:#cbd8ea;text-align:center;line-height:9px;text-shadow:0 1px 2px rgba(0,0,0,.9)}
  .side.p2 .skill > span{text-align:center}
  .skill.ready > i{width:100% !important;box-shadow:0 0 8px rgba(255,210,74,.9)}
  .skill.active > i{background:linear-gradient(90deg,#ff7a3c,#ffd24a);animation:panPulse .5s infinite alternate}
  .skill.off{opacity:.4}
  .skill.off > i{width:0 !important}
  @keyframes panPulse{from{opacity:.55}to{opacity:1}}
  .tag{font-size:10.5px;color:var(--dim);letter-spacing:.1em}

  /* 中央计时 */
  #timer{top:14px;left:50%;transform:translateX(-50%);text-align:center;
    background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:4px 16px;
    font-size:24px;font-weight:900;font-variant-numeric:tabular-nums;color:var(--gold)}
  #roundTag{position:fixed;top:74px;left:50%;transform:translateX(-50%);
    font-size:12px;color:var(--dim);letter-spacing:.2em;pointer-events:none}

  /* 提示与飘字 */
  #toast{position:fixed;left:50%;top:40%;transform:translate(-50%,-50%);z-index:12;
    font-size:clamp(22px,5vw,40px);font-weight:900;letter-spacing:.16em;pointer-events:none;
    opacity:0;transition:opacity .18s;text-shadow:0 4px 20px rgba(0,0,0,.9)}
  #toast.show{opacity:1}

  /* 面板：模式 / 选角 / 结算 */
  #panel{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;z-index:20;
    background:rgba(4,9,14,.9);backdrop-filter:blur(6px);overflow:auto;transition:opacity .18s}
  #panel.hide{opacity:0;pointer-events:none}
  .sheet{width:min(980px,96vw);padding:22px 22px 26px;text-align:center;
    background:rgba(10,16,26,.94);border:1px solid var(--line);border-radius:22px;
    box-shadow:0 26px 70px rgba(0,0,0,.65)}
  .sheet h1{margin:0 0 4px;font-size:clamp(20px,4.6vw,30px);letter-spacing:.12em;
    background:linear-gradient(92deg,#8ef0b0,var(--gold));-webkit-background-clip:text;background-clip:text;color:transparent}
  .sheet .sub{font-size:11.5px;color:var(--dim);letter-spacing:.24em;margin-bottom:14px}
  .sheet p{margin:0 0 12px;font-size:13px;line-height:1.8;color:#c3d4ee}
  .sheet b{color:var(--gold)}

  .modes{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-bottom:16px}
  .mode{padding:10px 20px;border-radius:14px;cursor:pointer;border:1px solid var(--line);
    background:rgba(255,255,255,.03);font-size:13px;font-weight:700}
  .mode:hover{background:rgba(126,240,200,.1)}
  .mode.sel{border-color:var(--green);background:rgba(126,240,200,.14);box-shadow:0 0 0 1px var(--green) inset}

  .pickwrap{display:grid;grid-template-columns:1fr auto 1fr;gap:14px;align-items:start}
  .pcol{display:flex;flex-direction:column;gap:8px}
  .pcol .head{font-size:13px;font-weight:800;letter-spacing:.1em}
  .pcol.p1c .head{color:var(--p1)}
  .pcol.p2c .head{color:var(--p2)}
  /* 9 个角色 → 5 列（5 + 4），比 3 列更省高度 */
  .roster{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}
  .face{padding:6px 4px;border-radius:12px;cursor:pointer;border:1px solid var(--line);
    background:rgba(255,255,255,.03);transition:transform .1s}
  .face:hover{transform:translateY(-2px);background:rgba(255,255,255,.07)}
  .face.sel{border-color:var(--gold);background:rgba(255,206,64,.12)}
  .face canvas{display:block;margin:0 auto;border-radius:8px;background:rgba(0,0,0,.2)}
  .face .fn{font-size:11px;font-weight:700;margin-top:3px}
  .vs{display:flex;flex-direction:column;align-items:center;justify-content:center;
    padding-top:40px;font-size:26px;font-weight:900;color:var(--dim);letter-spacing:.1em}
  .detail{min-height:56px;font-size:11.5px;color:#a9bdd8;line-height:1.6;text-align:left;
    background:rgba(0,0,0,.25);border:1px solid var(--line);border-radius:12px;padding:8px 10px}
  .detail b{color:var(--gold)}
  .keysBox{font-size:11px;color:#9fb3d0;line-height:1.9;text-align:left;
    background:rgba(0,0,0,.25);border:1px solid var(--line);border-radius:12px;padding:8px 10px}
  .keysBox kbd{background:rgba(255,255,255,.08);border:1px solid var(--line);border-bottom-width:2px;
    border-radius:5px;padding:1px 6px;font-family:inherit;font-size:10.5px;color:#dbe9ff}

  .btnrow{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:16px}
  .btn{appearance:none;border:0;cursor:pointer;font:inherit;font-weight:800;letter-spacing:.1em;
    color:#06120e;background:linear-gradient(96deg,var(--green),#8ee9ff);
    padding:12px 30px;border-radius:999px;box-shadow:0 0 26px rgba(126,240,200,.35)}
  .btn:hover{transform:translateY(-1px);box-shadow:0 0 36px rgba(126,240,200,.55)}
  .btn.ghost{background:transparent;color:var(--ink);border:1px solid var(--line);box-shadow:none;
    padding:10px 20px;font-size:13px}
  .btn.ghost:hover{border-color:var(--green);color:var(--green)}
  .hint{margin-top:12px;font-size:11px;color:#8ba0bb}

  #pauseBtn{position:fixed;right:14px;bottom:14px;z-index:11;
    background:var(--panel);border:1px solid var(--line);color:var(--ink);
    border-radius:999px;padding:8px 16px;font:inherit;font-size:12.5px;cursor:pointer}
  #pauseBtn:hover{border-color:var(--green);color:var(--green)}

  /* 启动遮罩 */
  #boot{position:fixed;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;
    background:#08111a;color:#cfe2ff;font-size:13px;text-align:center;line-height:2}
  #boot.hide{display:none}
  #boot .box{max-width:470px;padding:24px 26px;border:1px solid var(--line);border-radius:18px;background:rgba(10,16,26,.92)}
  #boot b{font-size:15px;color:var(--green)}
  #boot .err{color:#ff9b9b}
  @media (max-width:720px){
    .pickwrap{grid-template-columns:1fr;gap:10px}
    .vs{padding:0;flex-direction:row}
    /* 9 个角色在窄屏排成 3 列 3 行 */
    .roster{grid-template-columns:repeat(3,1fr)}
  }
</style>
</head>
`;
export const BODY = `<div id="stage"><canvas id="cv"></canvas></div>

<div class="hud" id="top">
  <div class="side p1">
    <div class="nameRow"><span id="p1name">玩家 1</span><span class="wins" id="p1wins"></span></div>
    <div class="bar"><u id="p1ghost"></u><i id="p1hp"></i></div>
    <div class="rage" id="p1rageWrap"><i id="p1rage"></i></div>
    <div class="skill" id="p1skillWrap"><i id="p1skill"></i><span id="p1skillTxt">平底锅</span></div>
    <div class="tag" id="p1tag">生命 / 怒气</div>
  </div>
  <div class="side p2">
    <div class="nameRow"><span id="p2name">玩家 2</span><span class="wins" id="p2wins"></span></div>
    <div class="bar"><u id="p2ghost"></u><i id="p2hp"></i></div>
    <div class="rage" id="p2rageWrap"><i id="p2rage"></i></div>
    <div class="skill" id="p2skillWrap"><i id="p2skill"></i><span id="p2skillTxt">平底锅</span></div>
    <div class="tag" id="p2tag">生命 / 怒气</div>
  </div>
</div>

<div class="hud" id="timer">60</div>
<div id="roundTag">第 1 局</div>
<div id="toast"></div>
<button id="pauseBtn">暂停 (Esc)</button>

<div id="panel"><div class="sheet" id="sheet"></div></div>

`;
