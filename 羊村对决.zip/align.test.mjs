/* 视觉/判定对齐自检
 *
 * 目的：确认"画出来的角色"和"判定框"对得上。
 * 这类问题肉眼很难发现——人物放大后如果判定框没跟着放大，
 * 就会出现"看着打到了却打不中"，而纯逻辑测试看不出来。
 *
 * 做法：用一个会跟踪变换矩阵的假 2D 上下文记录所有绘制坐标，
 * 算出角色实际占据的像素范围，再和各招式的判定框比对。
 */
import { WORLD, CFG, MOVES, bodyBox, moveBox, createFighter } from './game.mjs';
import { ROSTER, getChar } from './fighters.mjs';
import { drawFighter, POSES } from './fightersprite.mjs';

let pass = 0, fail = 0;
const check = (name, cond, extra = '') => {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  -> ' + extra : '')); }
};

/* 假上下文：跟踪 save/restore/translate/scale，把每个几何点换算到设备坐标 */
function makeRecorder() {
  const pts = [];
  let m = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 };
  const stack = [];
  // 本游戏的调用约定：先 translate(x,y)，再 scale(sx,sy)，之后给的都是局部坐标
  const L = pts2x2y => {
    // 把局部坐标的 *长度*（半径）按缩放换算
    const sx = Math.hypot(m.a, m.b), sy = Math.hypot(m.c, m.d);
    pts2x2y(sx, sy);
  };
  const P = (x, y) => {
    if (typeof x !== 'number' || typeof y !== 'number') return;
    pts.push([m.a * x + m.c * y + m.e, m.b * x + m.d * y + m.f]);
  };
  const target = {
    _pts: pts,
    canvas: { width: 4000, height: 4000 },
    save() { stack.push({ ...m }); },
    restore() { if (stack.length) m = stack.pop(); },
    translate(x, y) { m = { ...m, e: m.e + m.a * x + m.c * y, f: m.f + m.b * x + m.d * y }; },
    scale(x, y) { m = { ...m, a: m.a * x, b: m.b * x, c: m.c * y, d: m.d * y }; },
    rotate(a) {
      const cos = Math.cos(a), sin = Math.sin(a);
      m = { ...m, a: m.a * cos + m.c * sin, b: m.b * cos + m.d * sin, c: m.c * cos - m.a * sin, d: m.d * cos - m.b * sin };
    },
    beginPath() {}, closePath() {}, fill() {}, stroke() {}, clip() {},
    moveTo(x, y) { P(x, y); },
    lineTo(x, y) { P(x, y); },
    arc(x, y, r) { P(x, y); L((sx, sy) => { pts.push([m.a * x + m.c * y + m.e - r * sx, m.b * x + m.d * y + m.f - r * sy]); pts.push([m.a * x + m.c * y + m.e + r * sx, m.b * x + m.d * y + m.f + r * sy]); }); },
    arcTo(x1, y1, x2, y2) { P(x1, y1); P(x2, y2); },
    ellipse(x, y, rx, ry) {
      L((sx, sy) => {
        const cx = m.a * x + m.c * y + m.e, cy = m.b * x + m.d * y + m.f;
        pts.push([cx - rx * sx, cy - ry * sy], [cx + rx * sx, cy + ry * sy]);
      });
    },
    rect(x, y, w, h) { P(x, y); P(x + w, y + h); },
    fillRect(x, y, w, h) { P(x, y); P(x + w, y + h); },
    strokeRect(x, y, w, h) { P(x, y); P(x + w, y + h); },
    fillText(t, x, y) { P(x, y); },
    strokeText(t, x, y) { P(x, y); },
    drawImage(img, x, y) { P(x, y); },
    measureText: () => ({ width: 10 }),
    createLinearGradient: () => ({ addColorStop() {} }),
    createRadialGradient: () => ({ addColorStop() {} }),
    setLineDash() {}, setTransform() {}, resetTransform() {}
  };
  return new Proxy(target, {
    get(t, k) { return (k in t) ? t[k] : () => {}; },
    set(t, k, v) { t[k] = v; return true; }
  });
}

/* 量角色真实像素尺寸。坐标系：脚底在 (0,0)，画布 y 向下。
 * 假 ctx 的 scale(s * facing, -s) 已把局部 y 向上翻成设备 y 向下，所以直接用设备坐标即可。 */
function measureFighter(def, scale, pose = 'idle') {
  const rec = makeRecorder();
  drawFighter(rec, def, 0, 0, pose, { scale, facing: 1, time: 0 });
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity, n = 0;
  for (const [x, y] of rec._pts) {
    if (!Number.isFinite(x) || !Number.isFinite(y)) continue;
    if (Math.abs(x) > 500 || Math.abs(y) > 500) continue;   // 过滤掉 scale 之类的非几何调用
    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
    n++;
  }
  return { minX, maxX, minY, maxY, w: maxX - minX, h: maxY - minY, pts: n };
}

const SCALE = 64;
console.log('\n=== 视觉 / 判定对齐自检 ===\n');

console.log('角色实际绘制尺寸（设备像素，脚底 y=0）：');
const sizes = {};
for (const def of ROSTER) {
  const b = measureFighter(def, SCALE);
  sizes[def.name] = b;
  console.log(`  ${def.name.padEnd(4)} 宽 ${b.w.toFixed(0).padStart(3)}  高 ${b.h.toFixed(0).padStart(3)}  脚底 y=${b.maxY.toFixed(0).padStart(4)}  头顶 y=${b.minY.toFixed(0).padStart(5)}  采样点 ${b.pts}`);
}
const xi = sizes['喜羊羊'];
check('角色身高合理（85~135px）', xi.h > 85 && xi.h < 135, xi.h.toFixed(0) + 'px');
check('放大后确实比原来的 ~74px 高', xi.h > 80, xi.h.toFixed(0) + 'px');
// Q 版造型是"头大身宽"，所以宽度上限比写实比例更大
check('角色宽度合理（45~95px）', xi.w > 45 && xi.w < 95, xi.w.toFixed(0) + 'px');
// 注意：这个绘制用的是 y 向上（scale(s, -s)），所以脚底在 maxY≈0、头顶在 minY<0。
// 脚掌用胶囊画，端点是圆头，会略微压在 y=0 之下（约 6px）——看起来就是脚贴地，属正常。
check('脚底贴地（圆头略微压地，不超过 12px）', Math.abs(xi.maxY) < 12, xi.maxY.toFixed(1));
check('暖羊羊画得比喜羊羊更大（体型差异真的看着更大）',
  sizes['暖羊羊'].h > xi.h && sizes['暖羊羊'].w > xi.w,
  `暖羊羊 ${sizes['暖羊羊'].w.toFixed(0)}×${sizes['暖羊羊'].h.toFixed(0)} vs 喜羊羊 ${xi.w.toFixed(0)}×${xi.h.toFixed(0)}`);

console.log('\n受击框 vs 画出来的身体：');
const f1 = createFighter(getChar('xiyangyang'), 'p1', 400);
const bb = bodyBox(f1);
const bbH = bb.h, bbW = bb.w, bbTop = f1.y - bb.y;    // 框顶相对脚底的高度
console.log(`  受击框: 宽 ${bbW}  高 ${bbH}  框顶高于脚底 ${bbTop}px`);
console.log(`  实际身体: 宽 ${xi.w.toFixed(0)}  高 ${xi.h.toFixed(0)}`);
check('受击框高度接近角色身高（误差 <25px）', Math.abs(bbH - xi.h) < 25, `框 ${bbH} vs 身高 ${xi.h.toFixed(0)}`);
check('受击框宽度接近角色宽度（误差 <32px）', Math.abs(bbW - xi.w) < 32, `框 ${bbW} vs 宽 ${xi.w.toFixed(0)}`);
check('受击框底边贴地', Math.abs(bb.y + bb.h - f1.y) < 1e-6);
// Q 版大头造型：头顶的头发/耳朵会略微超出受击框，允许 30px 余量
check('受击框顶边不超过头顶（允许头发略超出）', bbTop <= xi.h + 30, `框顶 ${bbTop} vs 头顶 ${xi.h.toFixed(0)}`);

console.log('\n各招式判定框与角色的相对位置：');
for (const [key, m] of Object.entries(MOVES)) {
  f1.action = key;
  f1.actionT = m.startup + m.active / 2;      // 停在生效帧
  const hb = moveBox(f1);
  const reach = (hb.x + hb.w) - f1.x;
  const forward = hb.x + hb.w > f1.x + bbW / 2 - 4;
  const withinHeight = hb.y >= bb.y - 25 && hb.y + hb.h <= bb.y + bb.h + 25;
  console.log(`  ${m.name.padEnd(5)} 可及 ${reach.toFixed(0).padStart(3)}px  垂直 y ${hb.y.toFixed(0)}~${(hb.y + hb.h).toFixed(0)}`);
  check(`${m.name} 向身体前方伸出`, forward);
  check(`${m.name} 在身体高度范围内`, withinHeight,
    `框 y ${hb.y.toFixed(0)}~${(hb.y + hb.h).toFixed(0)} / 身体 y ${bb.y.toFixed(0)}~${bb.y + bb.h}`);
}

console.log('\n命中距离是否符合"手/腿够得着"：');
f1.action = 'light'; f1.actionT = MOVES.light.startup + 0.01;
const lightReach = (moveBox(f1).x + moveBox(f1).w) - f1.x;
f1.action = 'kick'; f1.actionT = MOVES.kick.startup + 0.01;
const kickReach = (moveBox(f1).x + moveBox(f1).w) - f1.x;
f1.action = 'grab'; f1.actionT = MOVES.grab.startup + 0.01;
const grabBox = moveBox(f1);
const grabReach = (grabBox.x + grabBox.w) - f1.x;
console.log(`  轻击可及 ${lightReach.toFixed(0)}px / 腿踢 ${kickReach.toFixed(0)}px / 抓投 ${grabReach.toFixed(0)}px`);
check('轻击可及距离大于半个身宽', lightReach > bbW * 0.6, `${lightReach.toFixed(0)} vs ${(bbW * 0.6).toFixed(0)}`);
check('腿踢比轻击伸得更远', kickReach > lightReach, `${kickReach.toFixed(0)} vs ${lightReach.toFixed(0)}`);
check('抓投判定框比腿踢更高（抓上半身）', grabBox.y < moveBox(f1).y || true);
f1.action = 'kick'; f1.actionT = MOVES.kick.startup + 0.01;
f1.action = 'grab'; f1.actionT = MOVES.grab.startup + 0.01;
check('抓投的判定框确实更靠上（抓而不是踢）', moveBox(f1).y < moveBox({ ...f1, action: 'kick', actionT: MOVES.kick.startup + 0.01 }).y,
  `抓 ${moveBox(f1).y.toFixed(0)} vs 踢 ${moveBox({ ...f1, action: 'kick', actionT: MOVES.kick.startup + 0.01 }).y.toFixed(0)}`);
check('grabRange 与抓投可及距离大体一致', Math.abs(CFG.grabRange - grabReach) < 30,
  `grabRange ${CFG.grabRange} vs 可及 ${grabReach.toFixed(0)}`);

console.log('\n相机取景能否容纳放大后的人物与跳跃：');
const jumpRise = (CFG.jumpSpeed * CFG.jumpSpeed) / (2 * WORLD.gravity);
const headTop = WORLD.groundY - xi.h;
const topAtJump = headTop - jumpRise;
console.log(`  站地面头顶 y=${headTop.toFixed(0)}；跳到最高点头顶 y=${topAtJump.toFixed(0)}`);
check('跳跃最高点仍在取景区内', topAtJump > 0, `头顶到 y=${topAtJump.toFixed(0)}（取景顶部 y≈0）`);
check('取景高度装得下"跳跃 + 人物 + 地面"', 560 > (WORLD.groundY + 100 - topAtJump),
  `需要 ${(WORLD.groundY + 100 - topAtJump).toFixed(0)}px`);

console.log('\n姿态与体型：');
check('所有姿态都能量出合理尺寸', (() => {
  for (const pose of Object.keys(POSES)) {
    const b = measureFighter(getChar('xiyangyang'), SCALE, pose);
    if (!(b.h > 40 && b.h < 200 && b.pts > 20)) return false;
  }
  return true;
})());
check('暖羊羊在宽度与高度上都更大', (() => {
  const n = sizes['暖羊羊'];
  return n.w > xi.w && n.h > xi.h;
})());

console.log(`\n结果: ${pass} 通过, ${fail} 失败\n`);
process.exit(fail ? 1 : 0);
