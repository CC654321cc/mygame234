/* 渲染层 + 输入层 + 主循环
 * 玩法全在 game.mjs，这里只负责画、收键盘、切面板。
 */
import {
  WORLD, CFG, MOVES, createMatch, update, drainEvents, matchOver, matchSummary,
  applyFighterStats, activeMove, movePhase, aiInput, bodyBox, moveBox,
  PAN, panActive, panStatus, tryUsePan
} from './game.mjs';
import { ROSTER, getChar, STYLE_LABEL, KEYS, KEYS_ALT, KEY_LABEL } from './fighters.mjs';
import { drawFighter, drawShadow, pickPose } from './fightersprite.mjs';

/* ===== 画布 ===== */
const canvas = document.getElementById('cv');
const ctx = canvas.getContext('2d');
let DPR = 1, VW = 0, VH = 0, viewScale = 1, viewOx = 0, viewOy = 0;

/* 角色绘制缩放：本地坐标里角色约 1.6 高，乘这个数就是像素身高。
 * 46 → 约 74px（偏小），现在 64 → 约 103px，看起来更像在"对打"而不是"两个小点"。 */
const FIGHTER_SCALE = 64;

function resize() {
  DPR = Math.min(devicePixelRatio || 1, 2);
  VW = canvas.clientWidth || innerWidth;
  VH = canvas.clientHeight || innerHeight;
  canvas.width = Math.round(VW * DPR);
  canvas.height = Math.round(VH * DPR);
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  // 取景框：人物放大后要稍微多留出上方空间，否则跳起来会顶到画面外
  viewScale = Math.min(VW / 900, VH / 560);
  viewOx = (VW - 900 * viewScale) / 2;
  viewOy = (VH - 560 * viewScale) / 2 + 30;
}

/* ===== 状态 ===== */
let state = null;
let mode = 'pvp';                 // pvp | ai
let pick = { p1: 'xiyangyang', p2: 'feiyangyang' };
let keymap = { p1: KEYS.p1, p2: KEYS.p2 };
let useAlt = false;
let paused = false;
let aiLevel = 1;
let toastT = 0;
let showBoxes = false;

const $ = id => document.getElementById(id);
const panel = $('panel'), sheet = $('sheet'), toast = $('toast');

/* ===== 输入 ===== */
const down = Object.create(null);
const pressed = Object.create(null);     // 边沿触发，消费后清空

addEventListener('keydown', e => {
  if (!down[e.code]) pressed[e.code] = true;
  down[e.code] = true;
  if (e.code === 'Escape') { togglePause(); return; }
  if (e.code === 'KeyR' && state && matchOver(state)) { startMatch(); return; }
  if (e.code === 'Tab') { e.preventDefault(); useAlt = !useAlt; keymap.p2 = useAlt ? KEYS_ALT.p2 : KEYS.p2; showToast(useAlt ? '玩家 2 已切到备用键位' : '玩家 2 已切回小键盘', '#7ef0c8', 1.4); return; }
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(e.code)) e.preventDefault();
});
addEventListener('keyup', e => { down[e.code] = false; });
addEventListener('blur', () => { for (const k in down) down[k] = false; });

function readInput(side) {
  const k = keymap[side];
  const inp = {
    left: !!down[k.left], right: !!down[k.right], jump: false,
    run: !!down[k.run], block: !!down[k.block], dodge: false,
    light: false, heavy: false, kick: false, grab: false, special: false, pan: false
  };
  // 跳跃 / 攻击 / 闪避 / 技能用边沿触发，避免按住就连续出招
  if (pressed[k.jump]) inp.jump = true;
  if (pressed[k.light]) inp.light = true;
  if (pressed[k.heavy]) inp.heavy = true;
  if (pressed[k.kick]) inp.kick = true;
  if (pressed[k.grab]) inp.grab = true;
  if (pressed[k.special]) inp.special = true;
  if (pressed[k.dodge]) inp.dodge = true;
  if (k.pan && pressed[k.pan]) inp.pan = true;
  if (pressed[k.block]) inp.blockPressed = true;      // 招架要看“刚按下”这一帧
  return inp;
}

function clearPressed() { for (const k in pressed) delete pressed[k]; }

/* ===== 特效提示 ===== */
function showToast(text, color = '#ffce40', secs = 1.3) {
  toast.textContent = text;
  toast.style.color = color;
  toast.classList.add('show');
  toastT = secs;
}

/* ===== 开局 ===== */
function startMatch() {
  const p1 = getChar(pick.p1), p2 = getChar(pick.p2);
  state = createMatch(p1, p2);
  applyCharStats(state.p1, p1);
  applyCharStats(state.p2, p2);
  // 血量按比例换算到角色血量上限
  state.p1.hp = state.p1.hpMax;
  state.p2.hp = state.p2.hpMax;
  paused = false;
  panel.classList.add('hide');
  buildHud();
  showToast('第 1 局 · 开始', '#7ef0c8', 1.0);
}

function applyCharStats(f, def) {
  const st = def.stats;
  applyFighterStats(f, {
    hpMax: Math.round(CFG.maxHp * st.hp),
    speedMul: st.speed, damageMul: st.damage, defenseMul: st.defense,
    knockMul: st.knock, grabMul: st.grabPower, weightMul: st.weight
  });
}

/* ===== HUD ===== */
const hudEl = {
  p1name: $('p1name'), p2name: $('p2name'),
  p1hp: $('p1hp'), p2hp: $('p2hp'),
  p1ghost: $('p1ghost'), p2ghost: $('p2ghost'),
  p1rage: $('p1rage'), p2rage: $('p2rage'),
  p1rageWrap: $('p1rageWrap'), p2rageWrap: $('p2rageWrap'),
  p1wins: $('p1wins'), p2wins: $('p2wins'),
  p1skill: $('p1skill'), p2skill: $('p2skill'),
  p1skillWrap: $('p1skillWrap'), p2skillWrap: $('p2skillWrap'),
  p1skillTxt: $('p1skillTxt'), p2skillTxt: $('p2skillTxt'),
  timer: $('timer'), roundTag: $('roundTag'),
  p1tag: $('p1tag'), p2tag: $('p2tag')
};

function buildHud() {
  hudEl.p1name.textContent = state.p1.def.name + '（' + STYLE_LABEL[state.p1.def.style] + '）';
  hudEl.p2name.textContent = (mode === 'ai' ? '电脑 · ' : '') + state.p2.def.name + '（' + STYLE_LABEL[state.p2.def.style] + '）';
  for (const [side, el] of [['p1', hudEl.p1wins], ['p2', hudEl.p2wins]]) {
    el.innerHTML = '';
    for (let i = 0; i < CFG.roundsToWin; i++) {
      const d = document.createElement('span');
      d.className = 'pip' + (state[side].wins > i ? ' on' : '');
      el.appendChild(d);
    }
  }
  hudEl.p1tag.textContent = 'A/D 移动 · W 跳 · J 轻 · K 重 · L 踢 · I 抓 · U 防御 · Y 后跃 · H 必杀 · O 平底锅';
  hudEl.p2tag.textContent = useAlt
    ? '←/→ 移动 · ↑ 跳 · , 轻 · . 重 · / 踢 · ; 抓 · M 防御 · \' 后跃 · ] 必杀 · \\ 平底锅'
    : '←/→ 移动 · ↑ 跳 · 小键盘 1 轻 · 2 重 · 3 踢 · 5 抓 · 4 防御 · 7 后跃 · 6 必杀 · 8 平底锅';
}

function updateHud() {
  const s = state;
  for (const [side, f] of [['p1', s.p1], ['p2', s.p2]]) {
    const pct = Math.max(0, f.hp / f.hpMax * 100);
    hudEl[side + 'hp'].style.width = pct + '%';
    // 残影慢慢跟上
    const ghost = parseFloat(hudEl[side + 'ghost'].style.width || '100');
    if (pct < ghost) hudEl[side + 'ghost'].style.width = pct + '%';
    else if (pct > ghost) hudEl[side + 'ghost'].style.width = pct + '%';
    const ragePct = f.rage / CFG.rageMax * 100;
    hudEl[side + 'rage'].style.width = ragePct + '%';
    hudEl[side + 'rageWrap'].classList.toggle('full', f.rage >= CFG.rageMax);

    // 平底锅技能条
    const st = panStatus(f, f.other);
    const wrap = hudEl[side + 'skillWrap'];
    const txt = hudEl[side + 'skillTxt'];
    wrap.classList.toggle('off', !st.ok);
    wrap.classList.toggle('ready', !!st.usable);
    wrap.classList.toggle('active', !!st.active);
    if (!st.ok) {
      hudEl[side + 'skill'].style.width = '0%';
      txt.textContent = '平底锅（对手得是灰太狼）';
    } else if (st.active) {
      hudEl[side + 'skill'].style.width = (st.remain / PAN.duration * 100) + '%';
      txt.textContent = '平底锅生效中 ' + st.remain.toFixed(1) + 's';
    } else if (st.cd > 0) {
      // 冷却：从 0 回填到满
      const total = PAN.cooldown + PAN.duration;
      hudEl[side + 'skill'].style.width = Math.max(0, (1 - st.cd / total)) * 100 + '%';
      txt.textContent = '平底锅冷却 ' + st.cd.toFixed(1) + 's';
    } else {
      hudEl[side + 'skill'].style.width = '100%';
      txt.textContent = '平底锅就绪（按技能键）';
    }
  }
  hudEl.timer.textContent = Math.ceil(s.timer);
  hudEl.roundTag.textContent = '第 ' + s.round + ' 局';
}

/* ===== 场地绘制 ===== */
const THEME = {
  sky: ['#132238', '#0d1726'],
  ground: '#2b3a2e', groundDark: '#22301f', dirt: '#3a3126',
  platform: '#4a4032', platformTop: '#6b5c45',
  crowd: ['#3b4a63', '#4b3b53', '#3b5348'],
  moon: 'rgba(255,240,200,.14)'
};

function drawArena(t) {
  const g = ctx.createLinearGradient(0, 0, 0, 520);
  g.addColorStop(0, THEME.sky[0]);
  g.addColorStop(1, THEME.sky[1]);

  ctx.save();
  ctx.translate(viewOx, viewOy);
  ctx.scale(viewScale, viewScale);
  ctx.beginPath();
  ctx.rect(-viewOx / viewScale, -viewOy / viewScale, VW / viewScale, VH / viewScale);
  ctx.fillStyle = g;
  ctx.fill();

  // 月亮
  ctx.beginPath();
  ctx.arc(720, 110, 58, 0, Math.PI * 2);
  ctx.fillStyle = THEME.moon;
  ctx.fill();

  // 远景山
  ctx.fillStyle = 'rgba(255,255,255,.05)';
  ctx.beginPath();
  ctx.moveTo(-100, 300);
  ctx.lineTo(140, 190);
  ctx.lineTo(340, 300);
  ctx.lineTo(520, 175);
  ctx.lineTo(760, 300);
  ctx.lineTo(1000, 200);
  ctx.lineTo(1000, 420);
  ctx.lineTo(-100, 420);
  ctx.closePath();
  ctx.fill();

  // 观众席（一排小圆点，缓慢起伏）
  for (let i = 0; i < 40; i++) {
    const x = -40 + i * 25;
    const y = 300 + (i % 3) * 12 + Math.sin(t * 1.6 + i) * 2;
    ctx.beginPath();
    ctx.arc(x, y, 8, 0, Math.PI * 2);
    ctx.fillStyle = THEME.crowd[i % 3];
    ctx.fill();
  }

  // 地面
  ctx.fillStyle = THEME.ground;
  ctx.fillRect(-100, WORLD.groundY, 1100, 220);
  ctx.fillStyle = THEME.groundDark;
  ctx.fillRect(-100, WORLD.groundY, 1100, 10);
  // 地砖纹
  ctx.strokeStyle = 'rgba(0,0,0,.18)';
  ctx.lineWidth = 1;
  for (let x = -100; x < 1000; x += 60) {
    ctx.beginPath();
    ctx.moveTo(x, WORLD.groundY + 10);
    ctx.lineTo(x - 30, WORLD.groundY + 200);
    ctx.stroke();
  }
  // 场边线
  ctx.strokeStyle = 'rgba(255,255,255,.22)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(WORLD.wallLeft - 14, WORLD.groundY - 2);
  ctx.lineTo(WORLD.wallLeft - 14, 200);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(WORLD.wallRight + 14, WORLD.groundY - 2);
  ctx.lineTo(WORLD.wallRight + 14, 200);
  ctx.stroke();

  ctx.restore();
}

/* 判定框调试（按 F1 开关，方便核对判定位置） */
addEventListener('keydown', e => { if (e.code === 'F1') { e.preventDefault(); showBoxes = !showBoxes; } });

function drawBox(b, color) {
  if (!b) return;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.strokeRect(b.x, b.y, b.w, b.h);
}

function drawFighters(t) {
  ctx.save();
  ctx.translate(viewOx, viewOy);
  ctx.scale(viewScale, viewScale);

  const list = [state.p1, state.p2].sort((a, b) => a.y - b.y);

  for (const f of list) {
    const pose = pickPose(f);
    const flash = f.hurtFlash > 0 ? 0.5 : 0;
    drawShadow(ctx, f.x, WORLD.groundY, f.y, 1.4);
    // 人物放大：这个数是以脚底为原点的整体缩放（本地坐标里角色约 1.6 高）
    const opts = { facing: f.facing, scale: FIGHTER_SCALE, time: t, flash, panActive: panActive(f) };

    // 招式拖影：让打击更有速度感
    const m = activeMove(f);
    if (m && movePhase(f) === 'active') {
      ctx.save();
      ctx.globalAlpha = 0.28;
      drawFighter(ctx, f.def, f.x - f.facing * 16, f.y, pose, { ...opts, flash: 0 });
      ctx.restore();
    }
    drawFighter(ctx, f.def, f.x, f.y, pose, opts);

    // 必杀满槽提示（范围跟着人物一起放大）
    if (f.rage >= CFG.rageMax) {
      ctx.save();
      ctx.globalAlpha = 0.5 + Math.sin(t * 8) * 0.3;
      ctx.strokeStyle = '#ffce40';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.ellipse(f.x, f.y - 60, 44, 70, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    // 平底锅生效提示：橙色光环 + 文字
    if (panActive(f)) {
      ctx.save();
      ctx.globalAlpha = 0.35 + Math.sin(t * 10) * 0.2;
      ctx.strokeStyle = '#ff9d3c';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.ellipse(f.x, f.y - 44, 52, 40, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }

    if (showBoxes) {
      drawBox(bodyBox(f), 'rgba(120,220,255,.8)');
      if (m && movePhase(f) === 'active') drawBox(moveBox(f), 'rgba(255,90,90,.95)');
    }
  }

  // 飘字与粒子
  for (const fl of state.floats) {
    ctx.globalAlpha = Math.max(0, Math.min(1, fl.life));
    ctx.font = 'bold 22px "Segoe UI","PingFang SC",sans-serif';
    ctx.textAlign = 'center';
    ctx.fillStyle = fl.color;
    ctx.fillText(fl.text, fl.x, fl.y);
  }
  ctx.globalAlpha = 1;
  for (const p of state.particles) {
    ctx.globalAlpha = Math.max(0, p.life * 2);
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.restore();
}


/* ===== 事件处理 ===== */
function handleEvents() {
  for (const ev of drainEvents(state)) {
    switch (ev.type) {
      case 'hit': showToast('命中 ×' + (ev.combo || 1), '#ffce40', 0.5); break;
      case 'parry': showToast('招架成功！', '#7ef0c8', 0.9); break;
      case 'block': break;
      case 'roundWin': {
        const f = ev.side === 'p1' ? state.p1 : state.p2;
        const why = ev.reason === 'ringout' ? '落台' : (ev.reason === 'time' ? '时间到' : 'K.O.');
        showToast(f.def.name + ' 拿下第 ' + state.round + ' 局（' + why + '）', '#ffce40', 1.6);
        buildHud();
        break;
      }
      case 'roundDraw': showToast('本局平局', '#9fb3d0', 1.4); break;
      case 'matchWin': {
        const f = ev.side === 'p1' ? state.p1 : state.p2;
        showResult(f);
        break;
      }
      default: break;
    }
  }
}

/* ===== 面板 ===== */

function modeLabel(m) {
  return m === 'ai' ? '单人练习（打电脑）' : '双人对打';
}

function showMenu() {
  sheet.innerHTML = `
    <h1>羊村对决</h1>
    <div class="sub">YANGCUN ARENA · 1 v 1</div>
    <p>两个人共用一副键盘对打。<b>三局两胜</b>，把对手打到没血、或者把他打出场地都算赢一局。</p>
    <div class="modes">
      <div class="mode${mode === 'pvp' ? ' sel' : ''}" data-m="pvp">双人对打</div>
      <div class="mode${mode === 'ai' ? ' sel' : ''}" data-m="ai">单人练习（打电脑）</div>
    </div>
    <div class="pickwrap">
      <div class="pcol p1c">
        <div class="head">玩家 1 选角</div>
        <div class="roster" id="r1"></div>
        <div class="detail" id="d1"></div>
        <div class="keysBox" id="k1"></div>
      </div>
      <div class="vs">VS</div>
      <div class="pcol p2c">
        <div class="head" id="h2">玩家 2 选角</div>
        <div class="roster" id="r2"></div>
        <div class="detail" id="d2"></div>
        <div class="keysBox" id="k2"></div>
      </div>
    </div>
    <div class="btnrow">
      <button class="btn" id="startBtn">开始对打</button>
    </div>
    <div class="hint">
      按 <kbd>Tab</kbd> 可切换玩家 2 的键位（小键盘 ↔ 右侧字母键，笔记本没小键盘时用）<br>
      对打中按 <kbd>Esc</kbd> 暂停 · <kbd>F1</kbd> 显示判定框（调试用）
    </div>`;
  renderRosters();
  panel.classList.remove('hide');
}

function renderRosters() {
  for (const side of ['p1', 'p2']) {
    const box = $('r' + side[1]);
    box.innerHTML = ROSTER.map(c => `
      <div class="face${pick[side] === c.id ? ' sel' : ''}" data-id="${c.id}" data-side="${side}">
        <canvas width="58" height="58"></canvas>
        <div class="fn">${c.name}</div>
      </div>`).join('');
    box.querySelectorAll('.face').forEach(el => {
      el.addEventListener('click', () => {
        pick[side] = el.dataset.id;
        renderRosters();
      });
    });
    box.querySelectorAll('canvas').forEach((cv, i) => {
      const def = ROSTER[i];
      const g = cv.getContext('2d');
      g.clearRect(0, 0, cv.width, cv.height);
      g.save();
      g.translate(cv.width / 2, cv.height - 4);
      drawFighter(g, def, 0, 0, 'idle', { scale: cv.height / 1.62, facing: side === 'p1' ? 1 : -1, time: 0 });
      g.restore();
    });
    const d = getChar(pick[side]);
    $('d' + side[1]).innerHTML =
      `<b>${d.name}</b> · ${d.title}（${STYLE_LABEL[d.style]}）<br>${d.desc}`;
    const k = side === 'p1' ? keymap.p1 : keymap.p2;
    const L = c => '<kbd>' + (KEY_LABEL[c] || c) + '</kbd>';
    $('k' + side[1]).innerHTML =
      `移动 ${L(k.left)}${L(k.right)} · 跳 ${L(k.jump)} · 跑 ${L(k.run)}<br>` +
      `轻击 ${L(k.light)} · 重击 ${L(k.heavy)} · 腿踢 ${L(k.kick)} · 抓投 ${L(k.grab)}<br>` +
      `防御 ${L(k.block)} · 后跃 ${L(k.dodge)} · 必杀 ${L(k.special)} · 平底锅 ${L(k.pan)}`;
    // 红太狼 + 对手是灰太狼 时，提示这个专属技能
    const other = getChar(pick[side === 'p1' ? 'p2' : 'p1']);
    if (d.id === PAN.ownerId) {
      const canUse = other.id === PAN.targetId;
      $('d' + side[1]).innerHTML += canUse
        ? `<br><span style="color:#ffd24a">★ 专属技能「平底锅」可用：按 ${KEY_LABEL[k.pan]} 触发，` +
          `${PAN.duration} 秒内所有攻击增伤 ${Math.round(PAN.damageBonus * 100)}%，冷却 ${PAN.cooldown} 秒</span>`
        : `<br><span style="color:#8ba0bb">专属技能「平底锅」：需要对手是灰太狼</span>`;
    }
  }
  $('h2').textContent = mode === 'ai' ? '电脑对手' : '玩家 2 选角';
  sheet.querySelectorAll('.mode').forEach(el => {
    el.classList.toggle('sel', el.dataset.m === mode);
    el.onclick = () => { mode = el.dataset.m; showMenu(); };
  });
  $('startBtn').onclick = startMatch;
}

function showResult(winner) {
  const s = matchSummary(state);
  sheet.innerHTML = `
    <h1>${winner.def.name} 获胜！</h1>
    <div class="sub">${winner.side === 'p1' ? '玩家 1' : (mode === 'ai' ? '电脑' : '玩家 2')} 拿下比赛</div>
    <p>比分 <b>${s.p1.wins} : ${s.p2.wins}</b><br>
       ${s.p1.name} 剩余血量 ${s.p1.hp} · ${s.p2.name} 剩余血量 ${s.p2.hp}</p>
    <div class="btnrow">
      <button class="btn" id="againBtn">再打一场</button>
      <button class="btn ghost" id="menuBtn">换角色 / 换模式</button>
    </div>
    <div class="hint">也可以直接按 <kbd>R</kbd> 再来一场</div>`;
  $('againBtn').onclick = startMatch;
  $('menuBtn').onclick = showMenu;
  panel.classList.remove('hide');
}

function togglePause() {
  if (!state || matchOver(state)) return;
  paused = !paused;
  if (paused) {
    sheet.innerHTML = `
      <h1>已暂停</h1>
      <div class="sub">PAUSED</div>
      <p>第 ${state.round} 局 · 比分 ${state.p1.wins} : ${state.p2.wins}</p>
      <div class="btnrow">
        <button class="btn" id="resumeBtn">继续</button>
        <button class="btn ghost" id="restartBtn">重开这场</button>
        <button class="btn ghost" id="menuBtn2">回到菜单</button>
      </div>`;
    $('resumeBtn').onclick = togglePause;
    $('restartBtn').onclick = () => { startMatch(); };
    $('menuBtn2').onclick = () => { state = null; paused = false; showMenu(); };
    panel.classList.remove('hide');
  } else {
    panel.classList.add('hide');
  }
}
$('pauseBtn').addEventListener('click', togglePause);

/* ===== 主循环 ===== */
let last = performance.now();
let loopFatal = false;          // 出现过无法恢复的错误就不再往下画，避免刷屏
let loopErrors = 0;

// 运行中出错时，把真实原因显示到页面上（而不是让画面静止、用户干等）
function reportRuntimeError(kind, e) {
  loopErrors++;
  const msg = (e && e.message) || String(e);
  const stack = ((e && e.stack) || '').split('\n').slice(0, 4).join('\n');
  console.error('[羊村对决] ' + kind, e);
  if (loopErrors > 3) return;                  // 只报前几次，避免每帧刷屏
  window.dispatchEvent(new CustomEvent('yangcun-fight-bootfail', {
    detail: { message: kind + '：' + msg, stack }
  }));
  // 已经启动过的话，遮罩本来是隐藏的，这里重新显示出来让用户看到原因
  const boot = document.getElementById('boot');
  if (boot) boot.classList.remove('hide');
  // 结束对局并退回面板，至少让界面是活的
  loopFatal = true;
}

function loop(now) {
  // 防止时间戳倒退导致 dt 为负（会让计时器反着走、特效倒放）
  const dt = Math.max(0, Math.min((now - last) / 1000, .1));
  last = now;
  const t = now / 1000;

  if (loopFatal) { return; }                   // 已报错，停止主循环

  try {
    frame(dt, t);
  } catch (e) {
    reportRuntimeError('运行出错', e);
    return;
  }
  requestAnimationFrame(loop);
}

function frame(dt, t) {
  ctx.clearRect(0, 0, VW, VH);

  if (state && !paused) {
    const inputs = { p1: readInput('p1'), p2: readInput('p2') };
    if (mode === 'ai') inputs.p2 = aiInput(state, state.p2, aiLevel);
    update(state, inputs, dt);
    clearPressed();
    handleEvents();
  }

  if (state) {
    // 镜头震动
    const shake = state.shake;
    ctx.save();
    if (shake > 0) ctx.translate((Math.random() - .5) * 14 * shake, (Math.random() - .5) * 10 * shake);
    drawArena(t);
    drawFighters(t);
    // 命中停顿期间给个白闪提示
    if (state.hitStop > 0) {
      ctx.fillStyle = 'rgba(255,255,255,.06)';
      ctx.fillRect(0, 0, VW, VH);
    }
    ctx.restore();
    updateHud();
  } else {
    ctx.fillStyle = '#08111a';
    ctx.fillRect(0, 0, VW, VH);
  }

  if (toastT > 0) {
    toastT -= dt;
    if (toastT <= 0) toast.classList.remove('show');
  }
}

/* ===== 启动 ===== */

resize();
addEventListener('resize', resize);
showMenu();
requestAnimationFrame(loop);

window.dispatchEvent(new CustomEvent('yangcun-fight-ready'));
window.__fight = () => ({
  phase: state && state.phase,
  round: state && state.round,
  p1: state && { name: state.p1.def.name, hp: Math.round(state.p1.hp), hpMax: state.p1.hpMax, wins: state.p1.wins },
  p2: state && { name: state.p2.def.name, hp: Math.round(state.p2.hp), hpMax: state.p2.hpMax, wins: state.p2.wins },
  mode, pick, paused, hasState: !!state
});
// 供自检使用：跳过选角界面直接开一局
window.__startFight = (m, a, b) => {
  if (m) mode = m;
  if (a) pick.p1 = a;
  if (b) pick.p2 = b;
  startMatch();
  return !!state;
};
