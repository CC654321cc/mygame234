/* 开发用：把所有姿态渲染成一张图，检查每个姿态是否正常（不会变形/糊掉）。
 * 用法: node allposes.mjs [角色id] [输出]
 */
import { createSoftwareCanvas } from './softcanvas.mjs';
import { encodePNG } from './png.mjs';
import { getChar } from './fighters.mjs';
import { drawFighter, POSES } from './fightersprite.mjs';
import fs from 'node:fs';

const id = process.argv[2] || 'xiyangyang';
const out = process.argv[3] || 'art/allposes.png';
const poseNames = Object.keys(POSES);

const CELL = 170, COLS = 7;
const ROWS = Math.ceil(poseNames.length / COLS);
const W = CELL * COLS, H = CELL * ROWS + 26;
const ctx = createSoftwareCanvas(W, H);
ctx.fillStyle = '#132238';
ctx.fillRect(0, 0, W, H);
ctx.fillStyle = 'rgba(255,255,255,0.12)';
ctx.fillRect(0, H - 26, W, 1);

const def = getChar(id);
console.log(`角色 ${def.name}  共 ${poseNames.length} 个姿态`);

poseNames.forEach((pose, i) => {
  const col = i % COLS, row = Math.floor(i / COLS);
  const cx = col * CELL + CELL / 2;
  const feetY = row * CELL + CELL - 30;
  try {
    drawFighter(ctx, def, cx, feetY, pose, { facing: 1, scale: 62, time: 0.3 });
  } catch (e) {
    console.error(`  姿态 ${pose} 绘制抛错: ${e.message}`);
  }
});

fs.mkdirSync('art', { recursive: true });
fs.writeFileSync(out, encodePNG(ctx._buf, W, H));
console.log(`${out}  ${W}x${H}`);
console.log('姿态顺序: ' + poseNames.join(', '));
