/* 开发用：极简 Canvas 2D 软件实现（支持路径填充/描边），用于在 Node 里渲染角色预览。
 *
 * 为什么需要它：我在浏览器里跑不了游戏，看不到自己画出来的角色长什么样。
 * 有了它就能把角色渲染成 PNG 直接看，而不是"改代码 → 猜效果"。
 * 只实现 fightersprite.mjs 用到的调用：
 *   save/restore/translate/scale/rotate（含变换栈）
 *   beginPath/moveTo/lineTo/arc/arcTo/ellipse/rect/closePath
 *   fill/stroke/fillRect、fillStyle/strokeStyle/lineWidth/globalAlpha
 * 路径会先按当前变换摊平成多边形，再用解析法算覆盖率（带 1px 抗锯齿）。
 */

const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;

export function parseColor(input) {
  if (Array.isArray(input)) return input;
  const s = String(input || '#000').trim();
  let m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1]; }
  m = /^#([0-9a-f]{3})$/i.exec(s);
  if (m) { const c = m[1]; return [parseInt(c[0] + c[0], 16), parseInt(c[1] + c[1], 16), parseInt(c[2] + c[2], 16), 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const p = m[1].split(',').map(v => parseFloat(v));
    return [p[0] || 0, p[1] || 0, p[2] || 0, p.length > 3 ? p[3] : 1];
  }
  return [0, 0, 0, 1];
}

/* 2x3 仿射矩阵相乘（列向量约定）。
 * 语义：compose(m, n) = 先应用 m，再应用 n；等价于矩阵乘积 n · m。
 *
 * 这个函数我写错过一次，症状很隐蔽：translate 后再 scale(1,-1) 时，
 * 平移量被放到了 y 的另一侧，整个角色画到画面外（看起来"什么都不显示"）。
 * 正确推导：
 *   n·m = [ n.a n.c n.e ]   [ m.a m.c m.e ]
 *         [ n.b n.d n.f ] · [ m.b m.d m.f ]
 * 于是：
 *   a = n.a*m.a + n.c*m.b
 *   b = n.b*m.a + n.d*m.b
 *   c = n.a*m.c + n.c*m.d
 *   d = n.b*m.c + n.d*m.d
 *   e = n.a*m.e + n.c*m.f + n.e      <-- 平移项必须乘"当前矩阵的平移"，不是反过来
 *   f = n.b*m.e + n.d*m.f + n.f
 */
export function mul(m, n) {
  return {
    a: n.a * m.a + n.c * m.b,
    b: n.b * m.a + n.d * m.b,
    c: n.a * m.c + n.c * m.d,
    d: n.b * m.c + n.d * m.d,
    e: n.a * m.e + n.c * m.f + n.e,
    f: n.b * m.e + n.d * m.f + n.f
  };
}
/* 把变换叠加到"用户坐标系"上：先应用当前矩阵，再应用新的变换 */
const compose = (m, n) => mul(n, m);
const IDENT = { a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 };

export function createSoftwareCanvas(W, H) {
  const buf = new Float32Array(W * H * 4);   // 非预乘 RGBA，0..1

  let m = { ...IDENT };
  const stack = [];
  let st = { fill: [0, 0, 0, 1], stroke: [0, 0, 0, 1], lw: 1, alpha: 1 };
  const stStack = [];

  // 路径：一组子路径（摊平后的点列）
  let subs = [];
  let cur = null;

  const apply = (x, y) => ({ x: m.a * x + m.c * y + m.e, y: m.b * x + m.d * y + m.f });

  function moveTo(x, y) { cur = [apply(x, y)]; subs.push(cur); }
  function lineTo(x, y) { if (!cur) moveTo(x, y); else cur.push(apply(x, y)); }
  function closePath() { if (cur && cur.length) cur.closed = true; }

  function arc(cx, cy, r, a0 = 0, a1 = Math.PI * 2, ccw = false) {
    const span = ccw ? (a0 - a1) : (a1 - a0);
    const steps = Math.max(8, Math.ceil(Math.abs(span) / 0.18));
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = a0 + (ccw ? -1 : 1) * span * (i / steps);
      pts.push(apply(cx + Math.cos(t) * r, cy + Math.sin(t) * r));
    }
    if (!cur) { cur = pts; subs.push(cur); } else { for (const p of pts) cur.push(p); }
  }

  function ellipse(cx, cy, rx, ry, rot = 0, a0 = 0, a1 = Math.PI * 2, ccw = false) {
    const span = ccw ? (a0 - a1) : (a1 - a0);
    const steps = Math.max(10, Math.ceil(Math.abs(span) / 0.16));
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = a0 + (ccw ? -1 : 1) * span * (i / steps);
      const ex = Math.cos(t) * rx, ey = Math.sin(t) * ry;
      pts.push(apply(cx + ex * Math.cos(rot) - ey * Math.sin(rot),
                     cy + ex * Math.sin(rot) + ey * Math.cos(rot)));
    }
    if (!cur) { cur = pts; subs.push(cur); } else { for (const p of pts) cur.push(p); }
  }

  /* arcTo：真实语义是"从当前点引一条切线到 (x1,y1)，再画弧到 (x2,y2)"。
   * 这里近似为直线连接。要点：必须并入当前子路径（不能新建），
   * 且当前点不存在时按 Canvas 语义直接 moveTo 到 (x1,y1)。
   * roundRect 用它，如果这里处理不对，后续 stroke 会把整条 roundRect 路径连出来。 */
  function arcTo(x1, y1, x2, y2) {
    if (!cur) { moveTo(x1, y1); return; }
    cur.push(apply(x1, y1));
    cur.push(apply(x2, y2));
  }

  // 二次贝塞尔：摊平成折线（角和尾巴用它）
  function quadraticCurveTo(cpx, cpy, x, y) {
    if (!cur) { moveTo(cpx, cpy); return; }
    const a = cur[cur.length - 1];
    const cp = apply(cpx, cpy), end = apply(x, y);
    const steps = 14;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps, u = 1 - t;
      cur.push({
        x: u * u * a.x + 2 * u * t * cp.x + t * t * end.x,
        y: u * u * a.y + 2 * u * t * cp.y + t * t * end.y
      });
    }
  }

  function bezierCurveTo(c1x, c1y, c2x, c2y, x, y) {
    if (!cur) moveTo(c1x, c1y);
    const a = cur[cur.length - 1];
    const p1 = apply(c1x, c1y), p2 = apply(c2x, c2y), end = apply(x, y);
    const steps = 18;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps, u = 1 - t;
      cur.push({
        x: u * u * u * a.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * end.x,
        y: u * u * u * a.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * end.y
      });
    }
  }
  function rect(x, y, w, h) {
    moveTo(x, y); lineTo(x + w, y); lineTo(x + w, y + h); lineTo(x, y + h); closePath();
  }

  // ---- 覆盖率：多边形（奇偶规则）+ 圆角 ----
  function polyCover(pts) {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const p of pts) {
      if (p.x < minX) minX = p.x; if (p.x > maxX) maxX = p.x;
      if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y;
    }
    return { minX, maxX, minY, maxY };
  }

  function fillPolygon(pts, color) {
    if (!pts || pts.length < 3) return;
    const bb = polyCover(pts);
    const x0 = Math.max(0, Math.floor(bb.minX - 1)), x1 = Math.min(W - 1, Math.ceil(bb.maxX + 1));
    const y0 = Math.max(0, Math.floor(bb.minY - 1)), y1 = Math.min(H - 1, Math.ceil(bb.maxY + 1));
    if (x1 < x0 || y1 < y0) return;
    const n = pts.length;
    for (let py = y0; py <= y1; py++) {
      const sy = py + 0.5;
      // 求该扫描线与多边形的所有交点
      const xs = [];
      for (let i = 0, j = n - 1; i < n; j = i++) {
        const a = pts[j], b = pts[i];
        if ((a.y <= sy && b.y > sy) || (b.y <= sy && a.y > sy)) {
          xs.push(a.x + (sy - a.y) / (b.y - a.y) * (b.x - a.x));
        }
      }
      if (!xs.length) continue;
      xs.sort((p, q) => p - q);
      for (let k = 0; k + 1 < xs.length; k += 2) {
        const sx0 = Math.max(x0, Math.floor(xs[k]));
        const sx1 = Math.min(x1, Math.ceil(xs[k + 1]));
        for (let px = sx0; px <= sx1; px++) {
          const cov = Math.min(xs[k + 1], px + 1) - Math.max(xs[k], px);
          if (cov > 0) blend(px, py, color, clamp01(cov) * color[3] * st.alpha);
        }
      }
    }
  }

  function strokePolyline(pts, color, lw) {
    if (!pts || pts.length < 2) return;
    // 调试开关：打印每条描边路径的首尾点，用来定位"从残留路径连出长线"
    if (globalThis.__strokeLog) {
      const a = pts[0], b = pts[pts.length - 1];
      globalThis.__strokeLog.push(
        `stroke pts=${pts.length} 首(${a.x.toFixed(1)},${a.y.toFixed(1)}) 尾(${b.x.toFixed(1)},${b.y.toFixed(1)}) ` +
        `color=rgb(${color[0] | 0},${color[1] | 0},${color[2] | 0}) lw=${lw.toFixed(4)}`
      );
    }
    // 调试开关：打印每条描边路径的全部点（定位"路径被污染"这类问题）
    if (globalThis.__strokeDump) {
      const a = pts[0], b = pts[pts.length - 1];
      globalThis.__strokeDump.push({
        n: pts.length,
        first: [a.x, a.y],
        last: [b.x, b.y],
        color: [color[0] | 0, color[1] | 0, color[2] | 0],
        pts: pts.map(p => [Math.round(p.x), Math.round(p.y)])
      });
    }
    /* 线宽按"世界单位"给出，只乘一次缩放。
     * 之前写成 Math.max(0.35, lw/2) 再乘 scale —— 把 0.35 当成了最小半径，
     * 在 scale=130 时变成 45px 粗的线，直接把整张脸涂满。 */
    const scale = Math.hypot(m.a, m.b) || 1;      // 线宽跟随变换缩放
    const rr = Math.max(0.5, (lw / 2) * scale);   // 最小 0.5 设备像素，避免细线消失
    for (let i = 0; i + 1 < pts.length; i++) {
      const a = pts[i], b = pts[i + 1];
      strokeSegment(a, b, rr, color);
    }
    // 端点圆头
    for (const p of [pts[0], pts[pts.length - 1]]) fillCircleSoft(p.x, p.y, rr, color);
  }

  function strokeSegment(a, b, r, color) {
    const vx = b.x - a.x, vy = b.y - a.y;
    const L2 = vx * vx + vy * vy;
    /* 关键：线段退化成一点时必须单独处理。
     * 之前写成 `const L2 = vx*vx + vy*vy || 1e-9;`，
     * 于是 vx=vy=0 时 t = 0/1e-9 = 0，投影点恒等于 a，
     * 距离恒为 0、覆盖率恒为 1 —— 整片区域被涂满。
     * 二次贝塞尔摊平后的折线里大量点重合，正好踩中这个 bug（脸被整个涂黑）。
     * 退化线段应该就是一个圆点。 */
    if (L2 < 1e-12) { fillCircleSoft(a.x, a.y, r, color); return; }
    const minX = Math.max(0, Math.floor(Math.min(a.x, b.x) - r - 1));
    const maxX = Math.min(W - 1, Math.ceil(Math.max(a.x, b.x) + r + 1));
    const minY = Math.max(0, Math.floor(Math.min(a.y, b.y) - r - 1));
    const maxY = Math.min(H - 1, Math.ceil(Math.max(a.y, b.y) + r + 1));
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const cx = px + 0.5, cy = py + 0.5;
        let t = ((cx - a.x) * vx + (cy - a.y) * vy) / L2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const dx = cx - (a.x + vx * t), dy = cy - (a.y + vy * t);
        const d = Math.hypot(dx, dy) - r;
        const cov = clamp01(0.5 - d);
        if (cov > 0) blend(px, py, color, cov * color[3] * st.alpha);
      }
    }
  }

  function fillCircleSoft(cx, cy, r, color) {
    const minX = Math.max(0, Math.floor(cx - r - 1)), maxX = Math.min(W - 1, Math.ceil(cx + r + 1));
    const minY = Math.max(0, Math.floor(cy - r - 1)), maxY = Math.min(H - 1, Math.ceil(cy + r + 1));
    for (let py = minY; py <= maxY; py++) {
      for (let px = minX; px <= maxX; px++) {
        const d = Math.hypot(px + 0.5 - cx, py + 0.5 - cy) - r;
        const cov = clamp01(0.5 - d);
        if (cov > 0) blend(px, py, color, cov * color[3] * st.alpha);
      }
    }
  }

  function blend(x, y, c, a) {
    if (a <= 0) return;
    if (a > 1) a = 1;
    const i = (y * W + x) * 4;
    const da = buf[i + 3];
    const na = a + da * (1 - a);
    if (na <= 0) { buf[i] = buf[i + 1] = buf[i + 2] = buf[i + 3] = 0; return; }
    buf[i] = (c[0] / 255 * a + buf[i] * da * (1 - a)) / na;
    buf[i + 1] = (c[1] / 255 * a + buf[i + 1] * da * (1 - a)) / na;
    buf[i + 2] = (c[2] / 255 * a + buf[i + 2] * da * (1 - a)) / na;
    buf[i + 3] = na;
  }

  const ctx = {
    canvas: { width: W, height: H },
    _buf: buf,
    get fillStyle() { return st.fill; },
    set fillStyle(v) { st.fill = parseColor(v); },
    get strokeStyle() { return st.stroke; },
    set strokeStyle(v) { st.stroke = parseColor(v); },
    get lineWidth() { return st.lw; },
    set lineWidth(v) { st.lw = v; },
    get globalAlpha() { return st.alpha; },
    set globalAlpha(v) { st.alpha = v; },
    get globalCompositeOperation() { return 'source-over'; },
    set globalCompositeOperation(v) {},

    save() { stack.push({ ...m }); stStack.push({ ...st }); },
    restore() { if (stack.length) m = stack.pop(); if (stStack.length) st = stStack.pop(); },
    // 用 compose 累加到用户坐标系：newW = currentW · newT
    translate(x, y) { m = compose(m, { a: 1, b: 0, c: 0, d: 1, e: x, f: y }); },
    scale(x, y) { m = compose(m, { a: x, b: 0, c: 0, d: y, e: 0, f: 0 }); },
    rotate(a) { const c = Math.cos(a), s = Math.sin(a); m = compose(m, { a: c, b: s, c: -s, d: c, e: 0, f: 0 }); },
    setTransform(a, b, c, d, e, f) { m = { a, b, c, d, e, f }; },
    resetTransform() { m = { ...IDENT }; },

    // beginPath 必须把 cur 也清空：否则后面的 arc() 会往"上一条已废弃的路径"上追加点，
    // 路径就彻底错乱（我踩过这个坑，表现为角色整体不显示）。
    beginPath() { subs = []; cur = null; },
    closePath,
    moveTo, lineTo, arc, arcTo, ellipse, rect, quadraticCurveTo, bezierCurveTo,
    roundRect(x, y, w, h, r) { rect(x, y, w, h); },

    /* 关键：一次 fill/stroke 画完之后必须清空当前路径。
     * 真实 Canvas 里 stroke() 不清路径，而 fightersprite 的画法是
     * "beginPath(); arc(); fill();" 与 "beginPath(); moveTo(); ...; stroke();" 交替，
     * 如果不清，后面的 arc/moveTo 会把点追加到上一条已经用完的路径上，
     * 于是描边时从"上一段的末尾"拉出一条横跨整个角色的长线。
     * 我踩过这个坑：羊的嘴那条曲线被从上一条路径连过来，把整张脸涂暗了。 */
    fill() {
      for (const pts of subs) if (pts.length >= 3) fillPolygon(pts, st.fill);
      subs = []; cur = null;
    },
    stroke() {
      for (const pts of subs) strokePolyline(pts, st.stroke, st.lw);
      subs = []; cur = null;
    },
    clip() {},

    fillRect(x, y, w, h) {
      const p = [apply(x, y), apply(x + w, y), apply(x + w, y + h), apply(x, y + h)];
      fillPolygon(p, st.fill);
    },
    strokeRect(x, y, w, h) {
      const p = [apply(x, y), apply(x + w, y), apply(x + w, y + h), apply(x, y + h)];
      strokePolyline(p.concat([p[0]]), st.stroke, st.lw);
    },
    clearRect(x, y, w, h) {
      const p = [apply(x, y), apply(x + w, y), apply(x + w, y + h), apply(x, y + h)];
      let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
      for (const q of p) { minX = Math.min(minX, q.x); maxX = Math.max(maxX, q.x); minY = Math.min(minY, q.y); maxY = Math.max(maxY, q.y); }
      for (let py = Math.max(0, Math.floor(minY)); py <= Math.min(H - 1, Math.ceil(maxY)); py++) {
        for (let px = Math.max(0, Math.floor(minX)); px <= Math.min(W - 1, Math.ceil(maxX)); px++) {
          const i = (py * W + px) * 4;
          buf[i] = buf[i + 1] = buf[i + 2] = buf[i + 3] = 0;
        }
      }
    },
    fillText() {}, strokeText() {}, measureText: () => ({ width: 0 }),
    setLineDash() {}, createLinearGradient: () => ({ addColorStop() {} }),
    createRadialGradient: () => ({ addColorStop() {} }),
    drawImage() {}
  };
  return ctx;
}
