/* 开发用：把几个角色放大画在一起，方便近距离检查五官。
 * 用法: node facecheck.mjs [输出路径] [角色id,逗号分隔] [缩放]
 */
import fs from 'node:fs';
import { createSoftwareCanvas } from './softcanvas.mjs';
import { encodePNG } from './png.mjs';
import { getChar } from './fighters.mjs';
import { drawFighter } from './fightersprite.mjs';

const out = process.argv[2] || 'art/facecheck.png';
const ids = (process.argv[3] || 'xiyangyang,hongtailang,xiongda,huitailang').split(',');
const scale = Number(process.argv[4] || 150);

const CELL = 230;
const W = CELL * ids.length;
const H = 300;
const ctx = createSoftwareCanvas(W, H);
ctx.fillStyle = '#132238';
ctx.fillRect(0, 0, W, H);
ctx.fillStyle = 'rgba(255,255,255,0.15)';
ctx.fillRect(0, H - 24, W, 1);

ids.forEach((id, i) => {
  drawFighter(ctx, getChar(id.trim()), CELL * i + CELL / 2, H - 26, 'idle',
    { facing: 1, scale, time: 0.3 });
});

fs.mkdirSync(out.split('/').slice(0, -1).join('/') || '.', { recursive: true });
fs.writeFileSync(out, encodePNG(ctx._buf, W, H));
console.log(`${out}  ${W}x${H}  scale=${scale}  角色: ${ids.join(' | ')}`);
