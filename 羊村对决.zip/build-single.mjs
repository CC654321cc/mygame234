/* 构建单文件版 index.html
 *
 * 为什么需要：浏览器在 file:// 下会以 CORS 拒绝加载 type="module" 脚本，
 * 所以双击 index-dev.html 打不开，必须起服务。这个脚本把各模块按依赖顺序
 * 拼成一段“普通内联脚本”——普通内联脚本不受 file:// 限制，双击就能玩。
 */
import fs from 'node:fs';
import { HEAD, BODY } from './page.mjs';

const dir = new URL('./', import.meta.url);
const read = f => fs.readFileSync(new URL(f, dir), 'utf8');
const OUT = 'index.html';

/* 依赖顺序：被依赖的在前 */
const ORDER = [
  ['fighters.mjs', '角色与键位数据'],
  ['fightersprite.mjs', '程序化绘制'],
  ['game.mjs', '战斗引擎'],
  ['main.mjs', '渲染与输入']
];

function toPlainScript(src, label) {
  let out = src;
  out = out.replace(/^\s*import\s+[\s\S]*?;\s*$/gm, '');                       // 去掉 import
  out = out.replace(/^\s*export\s*\{[^}]*\}\s*from\s*['"][^'"]+['"]\s*;?\s*$/gm, '');
  out = out.replace(/^\s*export\s*\{[^}]*\}\s*;?\s*$/gm, '');
  out = out.replace(/^(\s*)export\s+(const|let|var|function|async function|class)\s/gm, '$1$2 ');
  out = out.replace(/^\s*['"]use strict['"];\s*$/gm, '');
  if (/^\s*(import|export)\b/m.test(out)) {
    const left = out.split('\n').filter(l => /^\s*(import|export)\b/.test(l));
    throw new Error(`${label} 里还有未处理的模块语句：\n    ` + left.join('\n    '));
  }
  return out.trim();
}

/* ---- 跨文件重名检测 ----
 * 把各文件顶层作用域的声明抽出来（剥掉函数体与对象字面量），看有没有撞名。
 * 这次先用它把我预判的冲突找出来，而不是等浏览器报错。 */
function stripFunctions(src) {
  let out = '';
  let i = 0;
  while (i < src.length) {
    const ch = src[i];
    if (ch === '/' && src[i + 1] === '/') { while (i < src.length && src[i] !== '\n') i++; continue; }
    if (ch === '/' && src[i + 1] === '*') { i += 2; while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i++; i += 2; continue; }
    if (ch === '{') {
      let depth = 1; i++;
      while (i < src.length && depth > 0) { if (src[i] === '{') depth++; else if (src[i] === '}') depth--; i++; }
      out += ' {} ';
      continue;
    }
    out += ch; i++;
  }
  return out;
}

const occurrences = new Map();
function note(name, file) {
  if (!occurrences.has(name)) occurrences.set(name, new Map());
  const m = occurrences.get(name);
  m.set(file, (m.get(file) || 0) + 1);
}

for (const [file] of ORDER) {
  const src = stripFunctions(toPlainScript(read(file), file));
  for (const m of src.matchAll(/^[ \t]{0,2}(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=/gm)) note(m[1], file);
  for (const m of src.matchAll(/^[ \t]{0,2}(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/gm)) note(m[1], file);
  for (const m of src.matchAll(/^[ \t]{0,2}class\s+([A-Za-z_$][\w$]*)/gm)) note(m[1], file);
}

const conflicts = [];
for (const [name, files] of occurrences) {
  if (files.size < 2) continue;
  // 同名但在各自文件里只出现一次、且分属不同文件 → 合并后一定是重复声明
  if ([...files.values()].every(c => c === 1)) conflicts.push(`${name}（${[...files.keys()].join(' 与 ')}）`);
}

if (conflicts.length) {
  console.error('发现跨文件重名，合并成一个 IIFE 作用域后会变成重复声明：');
  for (const c of conflicts) console.error('  - ' + c);
  console.error('\n解决办法：把其中一个改名（不要用 var，那样会静默覆盖）。');
  process.exit(1);
}

/* ---- 组装 ---- */
const parts = ORDER.map(([file, desc]) => {
  const code = toPlainScript(read(file), file);
  try {
    // eslint-disable-next-line no-new-func
    new Function(code);
  } catch (e) {
    console.error(`${file}（${desc}）整理后语法不通过：${e.message}`);
    process.exit(1);
  }
  return `/* ==================== ${desc}（${file}） ==================== */\n${code}`;
});

const combined = parts.join('\n\n');
try {
  // eslint-disable-next-line no-new-func
  new Function(combined);
} catch (e) {
  console.error('合并后语法不通过：' + e.message);
  process.exit(1);
}

/* ---- 组装页面 ----
 * 页面骨架来自 page.mjs（不再依赖源码版 HTML），
 * 这样交付包里只需要一个 index.html，用户不可能双击错文件。
 */
const head = HEAD;
const body = '<body>\n' + BODY;

const BOOT_STYLE = `
<style>
  #boot{position:fixed;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;
    background:#08111a;color:#cfe2ff;font-size:13px;text-align:center;line-height:2}
  #boot.hide{display:none}
  #boot .box{max-width:470px;padding:24px 26px;border:1px solid rgba(150,210,255,.22);
    border-radius:18px;background:rgba(10,16,26,.92)}
  #boot .err{color:#ff9b9b}
</style>
`;

const BOOT_OVERLAY = `
<div id="boot">
  <div class="box">
    <b>正在启动…</b>
    <p id="bootMsg">如果没有反应，说明代码没有跑起来。</p>
    <p style="color:#8ba0bb;font-size:11.5px">
      这是<b>单文件版</b>，双击即可玩，不需要联网、不需要 Node、不需要起服务。<br>
      若一直停在这里，请按 <b>F12</b> 打开 Console 并把红字发给我。
    </p>
  </div>
</div>
`;

const GUARD = `
<script>
  // 启动守卫：主代码跑起来后会派发 yangcun-fight-ready
  //
  // 这个守卫刻意用很老的写法（var / function / 不用箭头函数和模板字符串），
  // 因为它的职责就是"在最恶劣的情况下也能把原因显示出来"——
  // 如果它自己用了新语法而在老浏览器里挂掉，用户就只会看到一片空白。
  (function () {
    var boot = document.getElementById('boot');
    var msg = document.getElementById('bootMsg');
    if (!boot || !msg) return;
    var done = false;
    var timer = setTimeout(function () {
      if (done) return;
      fail('启动超时（10 秒）。代码没有跑完，或运行中抛了错。');
    }, 10000);

    function fail(text) {
      done = true;
      clearTimeout(timer);
      msg.className = 'err';
      msg.textContent = text;
      if (document.getElementById('bootMore')) return;
      var more = document.createElement('div');
      more.id = 'bootMore';
      more.style.cssText = 'margin-top:12px;padding-top:12px;border-top:1px solid rgba(150,210,255,.2)';
      more.innerHTML = '按 <b>F12</b> 打开 Console，把红色报错发我，我来修。';
      msg.parentNode.appendChild(more);
    }

    window.addEventListener('yangcun-fight-ready', function () {
      done = true; clearTimeout(timer); boot.classList.add('hide');
    });
    // 主代码启动时抛错 → 把真实错误显示出来（而不是让用户干等）
    window.addEventListener('yangcun-fight-bootfail', function (e) {
      if (done) return;
      var d = (e && e.detail) || {};
      fail('启动出错：' + (d.message || '未知错误'));
      var s = String(d.stack || '').split('\\n').slice(0, 4).join('\\n');
      var more = document.getElementById('bootMore');
      if (more && s) {
        more.innerHTML = '<div style="text-align:left;font-size:11px;color:#8ba0bb;white-space:pre-wrap">' +
          s.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</div>' +
          '<div style="margin-top:8px">把上面这段发我，我来修。</div>';
      }
    });
    window.addEventListener('error', function (e) {
      if (done) return;
      var t = (e && e.target && (e.target.src || e.target.href)) || '';
      fail('加载失败' + (t ? '：' + t : '') + '（' + ((e && e.message) || '资源错误') + '）');
    }, true);
    window.addEventListener('unhandledrejection', function (e) {
      if (done) return;
      fail('启动出错：' + ((e && e.reason && e.reason.message) || e.reason || '未知错误'));
    });
  })();
</script>
`;

const INLINE = `
<script>
/* 单文件版：所有代码内联在这一个页面里（由 build-single.mjs 从四个模块拼接生成）。
 * 用 IIFE 包住，避免污染全局，也避免各模块的同名声明互相冲突。
 *
 * 外面这层 try/catch 是必须的：如果任何一个浏览器 API 抛错
 * （比如旧浏览器缺某个 canvas 方法、或取不到 2D 上下文），
 * 整个脚本会崩掉，用户就只会看到“正在启动”而不知道原因。
 * 这里把真实错误显示到页面上。
 *
 * 要改代码请改源文件（fighters / fightersprite / game / main），然后：node build-single.mjs
 */
(function () {
  'use strict';
  try {

${combined}

  } catch (err) {
    var e = err || {};
    var detail = (e.message || String(e));
    var where = '';
    try {
      var st = (e.stack || '').split('\\n')[1] || '';
      where = st.trim();
    } catch (ignore) {}
    window.dispatchEvent(new CustomEvent('yangcun-fight-bootfail', {
      detail: {
        message: detail + (where ? '  @ ' + where : ''),
        stack: (e.stack || '')
      }
    }));
    // 再兜一层：如果连派发事件都失败，就直接改页面文字
    try {
      var bm = document.getElementById('bootMsg');
      if (bm) { bm.className = 'err'; bm.textContent = '启动出错：' + detail; }
    } catch (ignore2) {}
  }
})();
</script>
`;

const out = head + BOOT_STYLE + body + BOOT_OVERLAY + GUARD + INLINE + '</body>\n</html>\n';
fs.writeFileSync(new URL(OUT, dir), out);

/* ---- 产物自检 ---- */
const problems = [];
if (out.includes('type="module"')) problems.push('产物里仍有 type="module"（file:// 下会被拦）');
if (/^\s*(import|export)\b/m.test(out)) problems.push('产物里仍有 import/export');
if (!out.includes('yangcun-fight-ready')) problems.push('缺少启动握手');
if (!out.includes('function createMatch')) problems.push('缺少战斗引擎');
if (!out.includes('function drawFighter')) problems.push('缺少角色绘制');
if (!out.includes('id="boot"') || !out.includes('id="bootMsg"')) problems.push('缺少启动遮罩（失败时会静默无提示）');
if (!/#boot\{/.test(out)) problems.push('缺少 #boot 样式');
if (!out.includes("getElementById('boot')")) problems.push('守卫没有去找 #boot');
for (const id of ['cv', 'p1hp', 'p2hp', 'p1rage', 'p2rage', 'sheet', 'toast', 'pauseBtn']) {
  if (!out.includes(`id="${id}"`)) problems.push(`缺少元素 #${id}`);
}
const scripts = [...out.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
scripts.forEach((js, i) => {
  if (/<\/script/i.test(js)) problems.push(`第 ${i + 1} 段内联脚本含 </script 字面量`);
  try {
    // eslint-disable-next-line no-new-func
    new Function(js);
  } catch (e) {
    problems.push(`第 ${i + 1} 段内联脚本语法错误：${e.message}`);
  }
});

if (problems.length) {
  console.error('构建产物有问题：');
  for (const p of problems) console.error('  - ' + p);
  process.exit(1);
}

console.log('构建完成: ' + OUT + '（单文件，双击即可玩，不需要 Node）');
console.log('  内联代码: ' + combined.length + ' 字符');
console.log('  内联脚本段数: ' + scripts.length);
console.log('  合计: ' + out.length + ' 字节');
console.log('  页面骨架来自 page.mjs（交付包只含这一个 HTML）');
