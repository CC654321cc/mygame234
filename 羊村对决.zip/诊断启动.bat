@echo off
chcp 65001 >nul
title 羊村对决 - 诊断启动
cd /d "%~dp0"

echo ============================================
echo   羊村对决 - 诊断启动
echo ============================================
echo.
echo 这个脚本会用你的默认浏览器打开"浏览器检测.html"，
echo 它会检测你的浏览器能不能跑这个游戏。
echo.
echo 请看浏览器页面上的结果：
echo   - 全是绿色的"支持"  =^> 那游戏应该能跑，请再打开 index.html
echo   - 有红色的"不支持"   =^> 那就是游戏打不开的原因，把结果发我
echo.

set TARGET=%CD%\浏览器检测.html

rem 优先用 Chrome（如果装了，兼容性最好）
set CHROME1=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe
set CHROME2=%ProgramFiles%\Google\Chrome\Application\chrome.exe
set CHROME3=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
set EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe

if exist "%CHROME1%" (
  echo [使用 Chrome]
  start "" "%CHROME1%" "%TARGET%"
  goto done
)
if exist "%CHROME2%" (
  echo [使用 Chrome]
  start "" "%CHROME2%" "%TARGET%"
  goto done
)
if exist "%CHROME3%" (
  echo [使用 Chrome]
  start "" "%CHROME3%" "%TARGET%"
  goto done
)
if exist "%EDGE%" (
  echo [使用 Edge]
  start "" "%EDGE%" "%TARGET%"
  goto done
)

echo [使用系统默认浏览器]
start "" "%TARGET%"

:done
echo.
echo 已尝试打开。请看浏览器窗口里的检测结果。
echo 如果什么都没打开，请手动双击：浏览器检测.html
echo.
pause
