// 对打游戏 —— 战斗逻辑测试（不需要浏览器）
import {
  WORLD, CFG, MOVES, createMatch, createFighter, update, drainEvents, matchOver, matchSummary,
  applyFighterStats, computeDamage, computeKnock, tryMove, tryJump, tryDodge, canAct,
  activeMove, movePhase, moveBox, bodyBox, overlaps, resolveHit, endRound, nextRound,
  aiInput, checkRoundEnd,
  PAN, tryUsePan, panActive, panAvailable, panStatus
} from './game.mjs';
import { ROSTER, getChar, KEYS, KEYS_ALT, KEY_LABEL, HONGTAILANG, HUITAILANG } from './fighters.mjs';
import { POSES, pickPose, drawFighter, shade } from './fightersprite.mjs';

let pass = 0, fail = 0;
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  -> ' + extra : '')); }
}
const near = (a, b, tol = 1e-6) => Math.abs(a - b) <= tol;
const IDLE = { left: false, right: false, jump: false, run: false, block: false, dodge: false, light: false, heavy: false, kick: false, grab: false, special: false };
const IN = (p1 = {}, p2 = {}) => ({ p1: { ...IDLE, ...p1 }, p2: { ...IDLE, ...p2 } });
// 站台范围是 150..750，两侧是深坑，所以测试站位要落在站台上
const rng = (v = 0.5) => { let s = Math.floor(v * 1e9) || 12345; return () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff; };

/* 造一个已进入战斗状态的局，双方站在指定位置。
 * 注意：要把角色属性套进去，否则所有人的倍率都是 1，测不出角色差异。 */
function arena(x1 = 300, x2 = 400, opts = {}) {
  const s = createMatch(getChar(opts.c1 || 'xiyangyang'), getChar(opts.c2 || 'feiyangyang'));
  applyCharStats(s.p1, s.p1.def);
  applyCharStats(s.p2, s.p2.def);
  s.phase = 'fight';
  s.p1.x = x1; s.p2.x = x2;
  s.p1.y = s.p2.y = WORLD.groundY;
  s.p1.onGround = s.p2.onGround = true;
  s.p1.facing = x2 >= x1 ? 1 : -1;
  s.p2.facing = x1 >= x2 ? 1 : -1;
  return s;
}

function applyCharStats(f, def) {
  const st = def.stats;
  applyFighterStats(f, {
    hpMax: Math.round(CFG.maxHp * st.hp),
    speedMul: st.speed, damageMul: st.damage, defenseMul: st.defense,
    knockMul: st.knock, grabMul: st.grabPower, weightMul: st.weight
  });
}

/* 让攻击方出招并推进到“生效帧”（不消费命中判定）。
 * 这样调用方可以直接 resolveHit，也可以让 update 自己判定。 */
function stepTo(s, f, moveKey, extra = {}) {
  if (moveKey === 'special') f.rage = CFG.rageMax;   // 只有必杀需要满怒气
  if (!tryMove(f, moveKey)) throw new Error('招式没能起手: ' + moveKey + '（当前 action=' + f.action + '）');
  const dt = 1 / 60;
  let guard = 0;
  while (movePhase(f) !== 'active' && guard++ < 200) {
    // 推进时要把输入一起传进去，否则“按住防御”之类的状态不会生效
    update(s, IN(extra.p1 || {}, extra.p2 || {}), dt);
  }
  return MOVES[moveKey];
}

/* 正确用法：先判定，没命中才推进。
 * 这一点我踩过坑：update() 内部自己就会做命中判定，
 * 如果调用方在 update 之前先 resolveHit 一次，就会把这次命中“消费”掉。 */
function advanceUntil(s, p1in = {}, p2in = {}, frames = 60) {
  for (let i = 0; i < frames; i++) {
    update(s, IN(p1in, p2in), 1 / 60);
    const ev = drainEvents(s).find(e => e.type === 'hit' || e.type === 'block' || e.type === 'parry' || e.type === 'whiff');
    if (ev) return ev;
  }
  return null;
}

/* 让某一方出招，并用纯 update 推进直到出现战斗事件（命中/防御/招架/落空）。
 * 关键：这里不能用 resolveHit，否则会把 update 内部的那次判定提前消费掉。 */
function strikeByLoop(s, attacker, moveKey, inputs = {}, frames = 60) {
  if (moveKey === 'special') attacker.rage = CFG.rageMax;
  tryMove(attacker, moveKey);
  for (let i = 0; i < frames; i++) {
    update(s, IN(inputs.p1 || {}, inputs.p2 || {}), 1 / 60);
    const ev = drainEvents(s).find(e => e.type === 'hit' || e.type === 'block' || e.type === 'parry' || e.type === 'whiff');
    if (ev) return ev;
  }
  return null;
}

/* 让一场对打实际打出一次命中，返回事件与伤害。用真实游戏循环驱动。 */
function strikeOnce(opts = {}) {
  const s = opts.state || arena(opts.x1 ?? 300, opts.x2 ?? 350, opts);
  const atk = opts.attacker === 'p2' ? s.p2 : s.p1;
  const def = atk === s.p1 ? s.p2 : s.p1;
  if (opts.before) opts.before(s, atk, def);
  const hp0 = def.hp;
  const during = { p1: opts.p1 || {}, p2: opts.p2 || {} };
  stepTo(s, atk, opts.move || 'light', during);
  let ev = null;
  for (let i = 0; i < (opts.frames || 40) && !ev; i++) {
    update(s, IN(opts.p1 || {}, opts.p2 || {}), 1 / 60);
    const hit = drainEvents(s).find(e => e.type === 'hit' || e.type === 'block' || e.type === 'parry' || e.type === 'whiff');
    if (hit) ev = hit;
  }
  return { s, atk, def, ev, damage: hp0 - def.hp };
}

console.log('\n=== 羊村对决 战斗逻辑测试 ===\n');

/* ---------- 1. 角色数据 ---------- */
{
  check('共 9 个可选角色', ROSTER.length === 9, ROSTER.length);
  const ids = ROSTER.map(r => r.id);
  check('包含指定的 9 人', ['xiyangyang', 'lanyangyang', 'meiyangyang', 'feiyangyang', 'xiongda', 'xionger', 'nuanyangyang', 'hongtailang', 'huitailang'].every(i => ids.includes(i)), ids.join(','));
  check('每人都有战斗属性', ROSTER.every(r => r.stats && r.stats.hp > 0 && r.stats.speed > 0 && r.stats.damage > 0));
  check('每人都有绘制参数', ROSTER.every(r => r.colors && r.colors.bodyColor));
  check('角色之间存在差异（不是换皮）',
    new Set(ROSTER.map(r => JSON.stringify(r.stats))).size >= 7,
    new Set(ROSTER.map(r => JSON.stringify(r.stats))).size);
  // 定位最强的角色（加入暖羊羊/红太狼之后，极值角色变了）
  const maxBy = k => Math.max(...ROSTER.map(r => r.stats[k]));
  const minBy = k => Math.min(...ROSTER.map(r => r.stats[k]));
  check('暖羊羊血最厚（体型最大的坦克）', getChar('nuanyangyang').stats.hp === maxBy('hp'),
    `暖羊羊 ${getChar('nuanyangyang').stats.hp} / 最高 ${maxBy('hp')}`);
  check('红太狼速度最快（女王靠速度压迫）', getChar('hongtailang').stats.speed === maxBy('speed'),
    `红太狼 ${getChar('hongtailang').stats.speed} / 最快 ${maxBy('speed')}`);
  check('沸羊羊伤害最高', getChar('feiyangyang').stats.damage === maxBy('damage'));
  check('熊二抓投最强', getChar('xionger').stats.grabPower === maxBy('grabPower'));
  check('暖羊羊最抗打（受伤倍率最低）', getChar('nuanyangyang').stats.defense === minBy('defense'),
    `暖羊羊 ${getChar('nuanyangyang').stats.defense} / 最低 ${minBy('defense')}`);
  check('暖羊羊体重最大（最不容易被击退）', getChar('nuanyangyang').stats.weight === maxBy('weight'));
  check('红太狼是最脆的（用血量换速度与伤害）',
    getChar('hongtailang').stats.hp === minBy('hp'),
    `红太狼 ${getChar('hongtailang').stats.hp} / 最低 ${minBy('hp')}`);

  // 防自相矛盾：说明文字里写了"最X"的角色，数值必须真的配得上。
  // 这类不一致肉眼很难发现，但会让玩家觉得"这角色名不副实"。
  const CLAIM = {
    暖羊羊: c => c.stats.hp === maxBy('hp') && c.stats.defense === minBy('defense') && c.stats.weight === maxBy('weight'),
    红太狼: c => c.stats.speed === maxBy('speed') && c.stats.damage > 1.1 && c.stats.hp === minBy('hp'),
    沸羊羊: c => c.stats.damage === maxBy('damage'),
    熊二: c => c.stats.grabPower === maxBy('grabPower')
  };
  for (const name of Object.keys(CLAIM)) {
    const c = ROSTER.find(r => r.name === name);
    check(`${name} 的定位描述与数值一致`, !!c && CLAIM[name](c), c ? JSON.stringify(c.stats) : '找不到该角色');
  }
}

/* ---------- 2. 双人键位不冲突 ---------- */
{
  const k1 = Object.values(KEYS.p1), k2 = Object.values(KEYS.p2);
  const dup = k1.filter(k => k2.includes(k));
  check('两名玩家的按键完全不重叠', dup.length === 0, dup.join(','));
  // KEYS 里还有 label 这类说明字段，不是键位，要排除
  const isKey = v => typeof v === 'string' && /^(Key|Digit|Arrow|Numpad|Shift|Control|Alt|Space|Comma|Period|Slash|Semicolon|Quote|Bracket|Backquote)/.test(v);
  check('每个键位在提示表里都有可读名字',
    [...k1, ...k2, ...Object.values(KEYS_ALT.p2)].filter(isKey).every(k => KEY_LABEL[k]),
    [...k1, ...k2].filter(isKey).filter(k => !KEY_LABEL[k]).join(','));
  const k2alt = Object.values(KEYS_ALT.p2);
  check('备用键位与玩家 1 也不冲突', k1.filter(k => k2alt.includes(k)).length === 0);
  check('备用键位的攻击键都没被玩家 1 占用', k2alt.every(k => !k1.includes(k)));
  check('两名玩家都有移动/跳/攻击/防御/必杀', [KEYS.p1, KEYS.p2, KEYS_ALT.p2].every(k =>
    k.left && k.right && k.jump && k.light && k.heavy && k.kick && k.grab && k.block && k.dodge && k.special));
}

/* ---------- 3. 开局状态 ---------- */
{
  const s = createMatch(getChar('xiyangyang'), getChar('xionger'));
  check('开局是入场阶段', s.phase === 'intro', s.phase);
  check('开局第 1 局', s.round === 1);
  check('双方都是满血', s.p1.hp === s.p1.hpMax && s.p2.hp === s.p2.hpMax);
  check('双方怒气为 0', s.p1.rage === 0 && s.p2.rage === 0);
  check('双方都在地面上', s.p1.onGround && s.p2.onGround);
  check('入场结束后进入战斗', (() => {
    for (let i = 0; i < 90; i++) update(s, IN(), 1 / 60);
    return s.phase === 'fight';
  })(), s.phase);
}

/* ---------- 4. 移动与边界 ---------- */
{
  const s = arena();
  const x0 = s.p1.x;
  for (let i = 0; i < 20; i++) update(s, IN({ right: true }), 1 / 60);
  check('按右会向右移动', s.p1.x > x0, `${x0.toFixed(0)} -> ${s.p1.x.toFixed(0)}`);
  check('走的方向正确（不反向）', s.p1.x - x0 > 20, (s.p1.x - x0).toFixed(0));

  // 一直往右撞墙
  for (let i = 0; i < 400; i++) update(s, IN({ right: true }), 1 / 60);
  check('不会冲出右边界', s.p1.x <= WORLD.wallRight - CFG.bodyRadius + 1e-6, s.p1.x.toFixed(1));
  for (let i = 0; i < 600; i++) update(s, IN({ left: true }), 1 / 60);
  check('不会冲出左边界', s.p1.x >= WORLD.wallLeft + CFG.bodyRadius - 1e-6, s.p1.x.toFixed(1));

  // 跑比走快
  const a = arena(), b = arena();
  for (let i = 0; i < 30; i++) { update(a, IN({ right: true }), 1 / 60); update(b, IN({ right: true, run: true }), 1 / 60); }
  check('跑步比走路快', (b.p1.x - 300) > (a.p1.x - 300) * 1.15,
    `走 ${(a.p1.x - 300).toFixed(0)} / 跑 ${(b.p1.x - 300).toFixed(0)}`);
}

/* ---------- 5. 跳跃 ---------- */
{
  const s = arena();
  const y0 = s.p1.y;
  update(s, IN({ jump: true }), 1 / 60);
  check('按跳会离地', !s.p1.onGround, String(s.p1.onGround));
  check('跳起时获得向上速度', s.p1.vy < 0, s.p1.vy.toFixed(0));
  let peak = y0;
  for (let i = 0; i < 120 && !s.p1.onGround; i++) { update(s, IN(), 1 / 60); peak = Math.min(peak, s.p1.y); }
  check('确实跳起来了（有高度）', y0 - peak > 60, (y0 - peak).toFixed(0) + 'px');
  check('最终会落回地面', s.p1.onGround && near(s.p1.y, WORLD.groundY, 1e-6), s.p1.y.toFixed(1));
  // 空中再按跳：只应受重力，不能二次起跳
  const s3 = arena(300, 500);
  update(s3, IN({ jump: true }), 1 / 60);
  const vyAfterFirst = s3.p1.vy;
  update(s3, IN({ jump: true }), 1 / 60);
  check('空中不能再次跳（只受重力）', s3.p1.vy > vyAfterFirst,
    `${vyAfterFirst.toFixed(0)} -> ${s3.p1.vy.toFixed(0)}`);

  // 体重影响跳跃高度
  const light = arena(300, 360, { c1: 'meiyangyang' });
  light.p1.weightMul = 0.9;
  const heavy = arena(300, 360, { c1: 'lanyangyang' });
  heavy.p1.weightMul = 1.3;
  const jumpPeak = (s2) => {
    update(s2, IN({ jump: true }), 1 / 60);
    let p = s2.p1.y;
    for (let i = 0; i < 120 && !s2.p1.onGround; i++) { update(s2, IN(), 1 / 60); p = Math.min(p, s2.p1.y); }
    return WORLD.groundY - p;
  };
  check('轻的角色跳得更高', jumpPeak(light) > jumpPeak(heavy),
    `${jumpPeak(light).toFixed(0)} vs ${jumpPeak(heavy).toFixed(0)}`);
}

/* ---------- 6. 攻击判定框 ---------- */
{
  const s = arena(300, 360);
  const m = stepTo(s, s.p1, 'light');
  check('轻击进入生效阶段', movePhase(s.p1) === 'active', movePhase(s.p1));
  const hb = moveBox(s.p1);
  check('攻击框朝面朝方向伸出', hb.x > s.p1.x, `角色 x=${s.p1.x.toFixed(0)}，框 x=${hb.x.toFixed(0)}`);
  // 背对时应该镜像到另一侧
  s.p1.facing = -1;
  const hb2 = moveBox(s.p1);
  check('背对时判定框镜像到另一侧', hb2.x + hb2.w <= s.p1.x + 1e-6, `框右边 ${(hb2.x + hb2.w).toFixed(0)} vs 角色 ${s.p1.x.toFixed(0)}`);
  s.p1.facing = 1;

  const bb = bodyBox(s.p2);
  check('受击框是竖直的躯干', bb.h > bb.w, `${bb.w}×${bb.h}`);
  check('重叠判定正确', overlaps({ x: 0, y: 0, w: 10, h: 10 }, { x: 5, y: 5, w: 10, h: 10 }) === true);
  check('不重叠判定正确', overlaps({ x: 0, y: 0, w: 10, h: 10 }, { x: 20, y: 0, w: 10, h: 10 }) === false);
}

/* ---------- 7. 轻击命中 ---------- */
{
  const { s, damage, ev } = strikeOnce({ move: 'light', x1: 300, x2: 350 });
  check('轻击能打到近距离的对手', !!ev && ev.type === 'hit', ev ? ev.type : '没打到');
  check('命中造成伤害', damage > 0, damage.toFixed(1));
  check('伤害数值与招式表一致（无角色加成时）', Math.abs(damage - MOVES.light.damage) < 2.5,
    `掉血 ${damage.toFixed(1)} vs 招式 ${MOVES.light.damage}`);
  check('命中让对手进入硬直', s.p2.hitStun > 0, s.p2.hitStun.toFixed(2));
  check('命中把对手击退', Math.abs(s.p2.vx) > 10, s.p2.vx.toFixed(0));
  check('命中方连击数增加', s.p1.combo >= 1, s.p1.combo);
  check('命中方获得怒气', s.p1.rage > 0, s.p1.rage.toFixed(1));
  check('受击方获得更多怒气（挨打攒得快）', s.p2.rage > s.p1.rage,
    `受 ${s.p2.rage.toFixed(1)} / 攻 ${s.p1.rage.toFixed(1)}`);
  // 继续推进：同一次攻击不会重复结算
  const hp = s.p2.hp;
  for (let i = 0; i < 6; i++) update(s, IN(), 1 / 60);
  check('同一次攻击只结算一次', s.p2.hp === hp, `${hp.toFixed(2)} -> ${s.p2.hp.toFixed(2)}`);
}

/* ---------- 8. 距离太远打不到 ---------- */
{
  const far = strikeOnce({ move: 'light', x1: 200, x2: 700, frames: 50 });
  check('远距离挥空不会命中', far.ev === null, far.ev ? far.ev.type : '');
  check('挥空不造成伤害', far.damage === 0, far.damage.toFixed(2));

  // 腿踢比轻击长，中距离能够到
  const mid = strikeOnce({ move: 'kick', x1: 300, x2: 375, frames: 50 });
  check('腿踢的攻击距离比轻击远', !!mid.ev && mid.ev.type === 'hit', mid.ev ? mid.ev.type : '没打到');
}

/* ---------- 9. 重击更疼、更慢 ---------- */
{
  const heavy = strikeOnce({ move: 'heavy', x1: 300, x2: 350 });
  const light = strikeOnce({ move: 'light', x1: 300, x2: 350 });
  check('重击伤害高于轻击', heavy.damage > light.damage,
    `重 ${heavy.damage.toFixed(1)} / 轻 ${light.damage.toFixed(1)}`);
  check('重击的起手比轻击慢', MOVES.heavy.startup > MOVES.light.startup,
    `${MOVES.heavy.startup} vs ${MOVES.light.startup}`);
  check('重击的击退更强', MOVES.heavy.knock > MOVES.light.knock);
  check('重击让对手硬直更久', MOVES.heavy.hitStun > MOVES.light.hitStun);
}

/* ---------- 10. 防御与招架 ---------- */
{
  // 防御减伤
  const blk = strikeOnce({ move: 'heavy', x1: 300, x2: 350, p2: { block: true }, frames: 60 });
  check('防御时判定为 block', blk.ev && blk.ev.type === 'block', blk.ev ? blk.ev.type : 'null');
  check('防御大幅减伤', blk.damage > 0 && blk.damage < MOVES.heavy.damage * 0.5,
    `防御后掉 ${blk.damage.toFixed(1)}（原始 ${MOVES.heavy.damage}）`);
  check('防御不会完全免伤（防止无限龟）', blk.damage > 0, blk.damage.toFixed(2));

  // 招架：命中前一刻切到 parry 状态
  // 招架要在“命中的那一帧”检查硬直，之后再检查就会被时间消耗掉
  const s2 = arena(300, 350);
  s2.p2.action = 'parry'; s2.p2.parryT = 0.5;
  tryMove(s2.p1, 'heavy');
  let parryEv = null, stunAtHit = 0;
  for (let i = 0; i < 60 && !parryEv; i++) {
    update(s2, IN(), 1 / 60);
    const ev = drainEvents(s2).find(e => e.type === 'parry');
    if (ev) { parryEv = ev; stunAtHit = s2.p1.hitStun; }
  }
  check('招架能判定成功', !!parryEv, parryEv ? parryEv.type : 'null');
  check('招架使攻击方零伤害', s2.p2.hp === s2.p2.hpMax, s2.p2.hp.toFixed(1));
  check('招架让攻击方陷入硬直', stunAtHit > 0.3, stunAtHit.toFixed(2));
  check('招架方获得怒气', s2.p2.rage > 0, s2.p2.rage.toFixed(1));

  // 招架窗口过期后不再招架
  const late = strikeOnce({
    move: 'heavy', x1: 300, x2: 350, frames: 60,
    before: (s, atk, def) => { def.action = 'parry'; def.parryT = 0; def.blockHold = true; }
  });
  check('招架窗口过期后不再招架', late.ev && late.ev.type !== 'parry', late.ev ? late.ev.type : 'null');
}

/* ---------- 11. 抓投：无视防御 ---------- */
{
  // 抓投能破防御
  const g1 = strikeOnce({ move: 'grab', x1: 300, x2: 340, p2: { block: true }, frames: 60 });
  check('抓投无视防御（判定为 hit 而非 block）', g1.ev && g1.ev.type === 'hit', g1.ev ? g1.ev.type : 'null');
  check('抓投在对手防御时仍然造成高伤害', g1.damage > MOVES.light.damage * 1.5,
    `${g1.damage.toFixed(1)} vs 轻击 ${MOVES.light.damage}`);
  check('抓投伤害高于轻击', MOVES.grab.damage > MOVES.light.damage);
  check('抓投带击飞（被抛起）', MOVES.grab.hitStun > MOVES.light.hitStun);

  // 双方同时出手：先记录血量，再让两边各自出招
  const s2 = arena(300, 345);
  const hp1 = s2.p1.hp, hp2 = s2.p2.hp;
  tryMove(s2.p2, 'light');          // p2 抢先出轻击
  tryMove(s2.p1, 'grab');           // p1 同时想抓投
  let ev = null;
  for (let i = 0; i < 40 && !ev; i++) {
    update(s2, IN(), 1 / 60);
    ev = drainEvents(s2).find(e => e.type === 'hit') || null;
  }
  check('同时出手时先有人打中（抓投没能白拿）', !!ev, ev ? ev.type : '没有命中');
  check('抢先的一方确实打掉了对手的血',
    s2.p1.hp < hp1 || s2.p2.hp < hp2,
    `p1 ${hp1.toFixed(1)}->${s2.p1.hp.toFixed(1)} / p2 ${hp2.toFixed(1)}->${s2.p2.hp.toFixed(1)}`);
}

/* ---------- 12. 后跃 / 前冲（都带无敌帧） ---------- */
{
  const s = arena(300, 350);
  s.p1.rage = 0;
  tryDodge(s.p2, 0);
  check('后跃进入 dodge 状态', s.p2.action === 'dodge', s.p2.action);
  check('后跃带无敌帧', s.p2.invuln > 0, s.p2.invuln.toFixed(3));
  check('后跃会向后跃（远离对手）', s.p2.vx > 0, s.p2.vx.toFixed(0));

  // 前冲：朝对手突进
  const fw = arena(300, 600);
  tryDodge(fw.p1, 1);
  check('前冲进入 dash 状态', fw.p1.action === 'dash', fw.p1.action);
  check('前冲朝对手方向', fw.p1.vx > 0, fw.p1.vx.toFixed(0));
  check('前冲也带无敌帧', fw.p1.invuln > 0, fw.p1.invuln.toFixed(3));
  check('前冲速度比后跃快', CFG.dashSpeed > CFG.dodgeSpeed, `${CFG.dashSpeed} vs ${CFG.dodgeSpeed}`);
  const d0 = Math.abs(fw.p2.x - fw.p1.x);
  for (let i = 0; i < 30; i++) update(fw, IN(), 1 / 60);
  check('前冲确实拉近了距离', Math.abs(fw.p2.x - fw.p1.x) < d0 - 40,
    `${d0.toFixed(0)} -> ${Math.abs(fw.p2.x - fw.p1.x).toFixed(0)}`);

  // 同一个键靠方向区分：按住方向 = 前冲，不按 = 后跃
  const viaInput = arena(300, 600);
  update(viaInput, IN({ right: true, dodge: true }), 1 / 60);
  check('按住方向 + 闪避键 = 前冲', viaInput.p1.action === 'dash' && viaInput.p1.vx > 0,
    `${viaInput.p1.action} vx=${viaInput.p1.vx.toFixed(0)}`);
  const viaInput2 = arena(300, 600);
  update(viaInput2, IN({ dodge: true }), 1 / 60);
  check('不按方向 + 闪避键 = 后跃', viaInput2.p1.action === 'dodge' && viaInput2.p1.vx < 0,
    `${viaInput2.p1.action} vx=${viaInput2.p1.vx.toFixed(0)}`);

  // 无敌帧：把场景摆成“判定框重叠 + 有无敌帧”，再让游戏循环自己判定
  const s2 = arena(300, 336);
  tryDodge(s2.p2, 0);
  s2.p2.vx = 0;                       // 只保留无敌帧，不让位移干扰
  const hp0 = s2.p2.hp;
  check('无敌帧确实开启了', s2.p2.invuln > 0, s2.p2.invuln.toFixed(3));
  // 注意：不能用 stepTo + resolveHit，因为 update 内部已经会做判定并消费掉这次命中
  const wf = strikeByLoop(s2, s2.p1, 'light', {}, 30);
  check('无敌帧期间攻击判为 whiff', wf && wf.type === 'whiff', wf ? wf.type : 'null');
  check('无敌帧期间不掉血', s2.p2.hp === hp0, `${hp0.toFixed(1)} -> ${s2.p2.hp.toFixed(1)}`);

  // 闪避会把人往后推（所以它同时是“拉开距离”的手段）
  const s4 = arena(300, 340);
  const x0 = s4.p2.x;
  tryDodge(s4.p2, 0);
  for (let i = 0; i < 20; i++) update(s4, IN(), 1 / 60);
  check('后跃会把角色往后推', s4.p2.x > x0, `${x0.toFixed(0)} -> ${s4.p2.x.toFixed(0)}`);

  const s3 = arena(300, 350);
  s3.p1.rage = 0;
  tryJump(s3.p2);
  check('空中不能闪避/前冲', tryDodge(s3.p2, 0) === false && tryDodge(s3.p2, 1) === false, s3.p2.action);
}

/* ---------- 13. 空中飞踢 ---------- */
{
  const s = arena(300, 350);
  s.p1.rage = 0;
  check('地面上不能出飞踢', tryMove(s.p1, 'airKick') === false);
  tryJump(s.p1);
  check('跳起来之后可以出飞踢', tryMove(s.p1, 'airKick') === true, s.p1.action);
  check('飞踢只有空中能用', MOVES.airKick.air === true);
  // 空中不能出地面招式
  const s2 = arena(300, 350);
  tryJump(s2.p1);
  check('空中不能出轻击', tryMove(s2.p1, 'light') === false);
}

/* ---------- 14. 怒气与必杀 ---------- */
{
  const s = arena(300, 350);
  check('怒气没满时放不出必杀', tryMove(s.p1, 'special') === false);
  s.p1.rage = CFG.rageMax;
  check('怒气满时可以放必杀', tryMove(s.p1, 'special') === true, s.p1.action);
  check('放完必杀怒气清零', s.p1.rage === 0, s.p1.rage);
  check('必杀伤害高于抓投', MOVES.special.damage > MOVES.grab.damage);
  check('必杀无视防御', MOVES.special.ignoresBlock === true);

  // 挨打攒怒气、打人攒怒气
  const s2 = arena(300, 350);
  stepTo(s2, s2.p1, 'heavy');
  let r = null;
  for (let i = 0; i < 60 && !r; i++) r = resolveHit(s2.p1, s2.p2) || (update(s2, IN(), 1 / 60), null);
  check('攻击与受击双方都会攒怒气', s2.p1.rage > 0 && s2.p2.rage > 0,
    `攻 ${s2.p1.rage.toFixed(1)} / 受 ${s2.p2.rage.toFixed(1)}`);
  s2.p1.rage = 999;
  update(s2, IN(), 1 / 60);
  check('怒气不会超过上限', s2.p1.rage <= CFG.rageMax, s2.p1.rage.toFixed(1));
}

/* ---------- 15. 连击与命中停顿 ---------- */
{
  // 用纯 update 驱动，这样 hitStop 会被真正设置
  const s = arena(300, 350);
  const ev = strikeByLoop(s, s.p1, 'light');
  check('对打产生命中事件', !!ev && ev.type === 'hit', ev ? ev.type : 'null');
  check('命中时产生连击计数', s.p1.combo === 1, s.p1.combo);
  check('命中后触发了停顿', s.hitStop > 0, s.hitStop.toFixed(3));

  // 停顿期间全场冻结
  s.hitStop = CFG.hitStop;
  const x0 = s.p2.x, y0 = s.p2.y, hp0 = s.p2.hp;
  update(s, IN(), 1 / 60);
  check('停顿期间全场冻结（位置不变）', near(s.p2.x, x0, 1e-9) && near(s.p2.y, y0, 1e-9),
    `(${x0.toFixed(1)},${y0.toFixed(1)}) -> (${s.p2.x.toFixed(1)},${s.p2.y.toFixed(1)})`);
  check('停顿期间不会再次结算伤害', s.p2.hp === hp0, `${hp0.toFixed(1)} -> ${s.p2.hp.toFixed(1)}`);

  // 停手一会儿连击会断
  for (let i = 0; i < 120; i++) update(s, IN(), 1 / 60);
  check('停手后连击会清零', s.p1.combo === 0, s.p1.combo);
}

/* ---------- 16. 出招不可取消（但收招可取消） ---------- */
{
  const s = arena(300, 400);
  s.p1.rage = 0;
  tryMove(s.p1, 'heavy');
  check('重击起手期间不能再出招', canAct(s.p1) === false);
  check('起手期间强行出招会被拒绝', tryMove(s.p1, 'light') === false, s.p1.action);
  // 推进到收招阶段
  for (let i = 0; i < 60 && movePhase(s.p1) !== 'recovery'; i++) update(s, IN(), 1 / 60);
  check('进入收招阶段', movePhase(s.p1) === 'recovery', movePhase(s.p1));
  // 招式完全跑完之后应当能再出招
  for (let i = 0; i < 60 && s.p1.action === 'heavy'; i++) update(s, IN(), 1 / 60);
  check('招式结束后可以再出招（连段手感）', canAct(s.p1) === true && tryMove(s.p1, 'light') === true,
    `action=${s.p1.action}`);
}

/* ---------- 17. 落台判负 ---------- */
{
  // 站台两侧是深坑：把角色放到坑上方，它应该一直往下掉并判负
  const s = arena(300, 350);
  s.p2.x = WORLD.stageLeft - 60;                 // 站台之外
  s.p2.y = WORLD.groundY;
  s.p2.onGround = true;
  for (let i = 0; i < 120 && s.p1.wins === 0; i++) update(s, IN(), 1 / 60);
  check('走出站台会掉下去并判负', s.p1.wins === 1, `p1 wins=${s.p1.wins}`);
  const evs = drainEvents(s);
  check('产生落台事件', evs.some(e => e.type === 'ringout'), evs.map(e => e.type).join(','));
  check('落台时对手获胜', s.roundWinner === 'p1', String(s.roundWinner));
}

/* ---------- 18. 三局两胜 ---------- */
{
  const s = arena(300, 350);
  s.p2.hp = 0;
  checkRoundEnd(s);
  check('KO 结束本局', s.phase === 'roundEnd', s.phase);
  check('胜者记 1 分', s.p1.wins === 1, s.p1.wins);
  check('还没到两胜，比赛继续', !matchOver(s));
  for (let i = 0; i < 200; i++) update(s, IN(), 1 / 60);   // 等下一局开始
  check('进入第 2 局', s.round === 2, s.round);
  check('新一局双方回满血', s.p1.hp === s.p1.hpMax && s.p2.hp === s.p2.hpMax,
    `${s.p1.hp}/${s.p1.hpMax}, ${s.p2.hp}/${s.p2.hpMax}`);
  check('新一局保留了胜场', s.p1.wins === 1, s.p1.wins);
  check('新一局重置怒气', s.p1.rage === 0 && s.p2.rage === 0);

  // 再赢一局 → 比赛结束
  s.p2.hp = 0;
  checkRoundEnd(s);
  check('两胜即结束整场', matchOver(s), s.phase);
  check('记录了最终胜者', s.winner === 'p1', String(s.winner));
  const sum = matchSummary(s);
  check('结算信息正确', sum.winner === 'p1' && sum.p1.wins === 2, JSON.stringify(sum.p1));
}

/* ---------- 19. 时间到按血量判胜 ---------- */
{
  const s = arena(300, 600);
  s.timer = 0.01;
  s.p1.hp = 80; s.p2.hp = 40;
  for (let i = 0; i < 5; i++) update(s, IN(), 1 / 60);
  check('时间到血多者胜', s.roundWinner === 'p1', String(s.roundWinner));
  check('产生了时间到的结算', drainEvents(s).some(e => e.reason === 'time'));

  const s2 = arena(300, 600);
  s2.timer = 0.01;
  s2.p1.hp = s2.p2.hp;
  for (let i = 0; i < 5; i++) update(s2, IN(), 1 / 60);
  check('血量相同判平局（不加分）', s2.p1.wins === 0 && s2.p2.wins === 0, `${s2.p1.wins}:${s2.p2.wins}`);
}

/* ---------- 20. 角色属性真的影响战斗 ---------- */
{
  const strong = strikeOnce({ c1: 'feiyangyang', move: 'heavy', x1: 300, x2: 350 });
  const weak = strikeOnce({ c1: 'xiyangyang', move: 'heavy', x1: 300, x2: 350 });
  check('高伤害角色打得更疼', strong.damage > weak.damage,
    `${strong.damage.toFixed(1)} vs ${weak.damage.toFixed(1)}`);

  const fast = arena(300, 350, { c1: 'xiyangyang' });
  const slow = arena(300, 350, { c1: 'lanyangyang' });
  for (let i = 0; i < 30; i++) { update(fast, IN({ right: true }), 1 / 60); update(slow, IN({ right: true }), 1 / 60); }
  check('高速度角色移动更快', (fast.p1.x - 300) > (slow.p1.x - 300),
    `${(fast.p1.x - 300).toFixed(0)} vs ${(slow.p1.x - 300).toFixed(0)}`);

  const tank = arena(300, 350, { c1: 'lanyangyang' });
  const thin = arena(300, 350, { c1: 'meiyangyang' });
  check('高血量角色血量上限更高', tank.p1.hpMax > thin.p1.hpMax, `${tank.p1.hpMax} vs ${thin.p1.hpMax}`);

  const light = strikeOnce({ c2: 'meiyangyang', move: 'heavy', x1: 300, x2: 350 });
  const heavy = strikeOnce({ c2: 'lanyangyang', move: 'heavy', x1: 300, x2: 350 });
  check('轻的对手被击退得更远', Math.abs(light.def.vx) > Math.abs(heavy.def.vx),
    `${Math.abs(light.def.vx).toFixed(0)} vs ${Math.abs(heavy.def.vx).toFixed(0)}`);
}

/* ---------- 21. 抓投加成只对抓投生效 ---------- */
{
  // 用同一个角色，只改 grabMul，才能把“抓投加成”单独隔离出来
  const def = getChar('xiyangyang');
  const withGrab = createFighter(def, 'p1', 0);
  applyFighterStats(withGrab, { hpMax: 100, grabMul: 1.5 });
  const noGrab = createFighter(def, 'p1', 0);
  applyFighterStats(noGrab, { hpMax: 100, grabMul: 1.0 });
  const target = createFighter(getChar('xiongda'), 'p2', 0);
  applyFighterStats(target, { hpMax: 100 });

  const grabA = computeDamage(MOVES.grab, withGrab, target);
  const grabB = computeDamage(MOVES.grab, noGrab, target);
  check('抓投加成提升抓投伤害', grabA > grabB, `${grabA} vs ${grabB}`);

  const lightA = computeDamage(MOVES.light, withGrab, target);
  const lightB = computeDamage(MOVES.light, noGrab, target);
  check('抓投加成完全不影响轻击', near(lightA, lightB, 1e-9), `${lightA} vs ${lightB}`);

  const heavyA = computeDamage(MOVES.heavy, withGrab, target);
  const heavyB = computeDamage(MOVES.heavy, noGrab, target);
  check('抓投加成也不影响重击', near(heavyA, heavyB, 1e-9), `${heavyA} vs ${heavyB}`);

  // 体重影响击退
  const lightTarget = createFighter(getChar('meiyangyang'), 'p2', 0);
  applyFighterStats(lightTarget, { hpMax: 100, weightMul: 0.9 });
  const heavyTarget = createFighter(getChar('lanyangyang'), 'p2', 0);
  applyFighterStats(heavyTarget, { hpMax: 100, weightMul: 1.3 });
  const kLight = computeKnock(MOVES.heavy, noGrab, lightTarget);
  const kHeavy = computeKnock(MOVES.heavy, noGrab, heavyTarget);
  check('体重越大被击退越近', kLight > kHeavy, `${kLight.toFixed(0)} vs ${kHeavy.toFixed(0)}`);
}

/* ---------- 22. AI 能打 ---------- */
{
  // AI 是概率决策（内部用 Math.random），且行为随距离变化，所以要分场景采样。
  // 教训：之前把 p2 固定在 600、p1 在 300（距离 300 = 远），
  // AI 只会"靠近"，于是攻击/防御永远采不到——旧断言恰好因为左右两个方向也算 2 种而通过。
  function sampleAI(gap, samples, level = 1) {
    const s2 = arena(300, 300 + gap);
    s2.p1.rage = 0; s2.p2.rage = 0;
    const cat = { move: 0, attack: 0, defend: 0, special: 0 };
    for (let i = 0; i < samples; i++) {
      const inp = aiInput(s2, s2.p2, level);
      if (inp.left || inp.right || inp.jump) cat.move++;
      if (inp.light || inp.heavy || inp.kick || inp.grab) cat.attack++;
      if (inp.special) cat.special++;
      if (inp.block || inp.dodge) cat.defend++;
      update(s2, IN({}, {}), 1 / 60);
      s2.p2.x = 300 + gap; s2.p2.y = WORLD.groundY; s2.p2.onGround = true; s2.p2.hitStun = 0;
      s2.p1.x = 300; s2.p2.facing = -1; s2.p1.facing = 1;
    }
    return cat;
  }

  const far = sampleAI(300, 1200);
  check('AI 在远距离会移动接近', far.move > 0, `移动 ${far.move}/1200`);

  const near = sampleAI(60, 2000);
  check('AI 在近距离会攻击', near.attack > 0, `攻击 ${near.attack}/2000`);
  check('AI 在近距离会防御或闪避', near.defend > 0, `防御/闪避 ${near.defend}/2000`);
  check('AI 会主动接近或攻击（远近都会动）', far.move + near.attack + near.defend > 0,
    `远移动 ${far.move} / 近攻击 ${near.attack} / 近防御 ${near.defend}`);

  // 怒气满时 AI 会考虑放必杀
  const rage = (() => {
    const s3 = arena(300, 350);
    s3.p2.rage = CFG.rageMax;
    let n = 0;
    for (let i = 0; i < 1500; i++) {
      const inp = aiInput(s3, s3.p2, 1);
      if (inp.special) n++;
      s3.p2.rage = CFG.rageMax;
      s3.p2.x = 350; s3.p1.x = 300; s3.p2.onGround = true; s3.p2.hitStun = 0;
      s3.p2.facing = -1; s3.p1.facing = 1;
    }
    return n;
  })();
  check('怒气满时 AI 会放必杀', rage > 0, `${rage}/1500`);

  check('AI 的输出结构完整', ['left', 'right', 'jump', 'light', 'heavy', 'kick', 'grab', 'block', 'dodge', 'special'].every(k => k in aiInput(arena(300, 350), arena(300, 350).p2, 1)));
  check('AI 在非战斗阶段不动手', (() => {
    const s2 = arena(300, 350);
    s2.phase = 'intro';
    const inp = aiInput(s2, s2.p2, 1);
    return !inp.light && !inp.heavy && !inp.right && !inp.left;
  })());
}

/* ---------- 23. 长时间运行稳定性 ---------- */
{
  const s = createMatch(getChar('xiyangyang'), getChar('xionger'));
  applyFighterStats(s.p1, { hpMax: 122, speedMul: 1.12, damageMul: 0.95, defenseMul: 1, knockMul: 0.95, grabMul: 1, weightMul: 1 });
  applyFighterStats(s.p2, { hpMax: 110, speedMul: 1, damageMul: 1, defenseMul: 0.96, knockMul: 1.35, grabMul: 1.45, weightMul: 1.15 });
  let bad = null;
  const dt = 1 / 60;
  for (let i = 0; i < 60 * 200 && !bad; i++) {          // 200 秒
    const inp = {
      p1: { left: (i % 90) < 30, right: (i % 90) >= 60, jump: i % 47 === 0, light: i % 13 === 0, heavy: i % 71 === 0, kick: i % 29 === 0, grab: i % 97 === 0, block: (i % 120) < 20, dodge: i % 83 === 0, special: i % 150 === 0, run: i % 5 === 0 },
      p2: aiInput(s, s.p2, 1)
    };
    update(s, inp, dt);
    // 别让比赛真的结束，测的是稳定性
    if (matchOver(s)) { s.p1.wins = 0; s.p2.wins = 0; s.winner = null; s.phase = 'fight'; s.timer = 60; }
    for (const f of [s.p1, s.p2]) {
      if (!Number.isFinite(f.x) || !Number.isFinite(f.y) || !Number.isFinite(f.hp) || !Number.isFinite(f.rage)) {
        bad = `数值异常 ${f.side} @${i}`; break;
      }
      if (f.rage < 0 || f.rage > CFG.rageMax) { bad = `怒气越界 ${f.rage.toFixed(1)} @${i}`; break; }
      if (f.hp < 0 || f.hp > f.hpMax) { bad = `血量越界 ${f.hp.toFixed(1)}/${f.hpMax} @${i}`; break; }
      if (f.y > WORLD.groundY + 400) { bad = `掉太深 ${f.y} @${i}`; break; }
    }
    if (s.particles.length > 600) bad = '粒子失控 ' + s.particles.length;
    if (s.floats.length > 200) bad = '飘字失控 ' + s.floats.length;
  }
  check('200 秒模拟无异常', bad === null, bad || '');
  check('结束后状态合法', s.p1.hp >= 0 && s.p1.hp <= s.p1.hpMax && s.p2.hp >= 0 && s.p2.hp <= s.p2.hpMax);
  check('特效数量受控', s.particles.length <= 600 && s.floats.length <= 200,
    `粒子 ${s.particles.length} / 飘字 ${s.floats.length}`);
}

/* ---------- 24. 一局能靠打斗自然分出胜负 ---------- */
{
  const s = arena(300, 350);
  let guard = 0;
  while (!matchOver(s) && guard++ < 60 * 120) {
    const inp = {
      p1: { left: false, right: s.p1.x > s.p2.x - 30 ? false : true, jump: false, light: guard % 10 === 0, heavy: false, kick: false, grab: false, block: false, dodge: false, special: false, run: false },
      p2: aiInput(s, s.p2, 1)
    };
    update(s, inp, 1 / 60);
  }
  check('对局能自然打完（不会卡死）', matchOver(s), `phase=${s.phase} round=${s.round}`);
  check('分出了胜者', s.winner === 'p1' || s.winner === 'p2', String(s.winner));
  check('胜场达到 2', Math.max(s.p1.wins, s.p2.wins) >= CFG.roundsToWin, `${s.p1.wins}:${s.p2.wins}`);
}

/* ---------- 25. 每个动作都有对应姿态（防止加了新动作却忘了画） ---------- */
{
  const ACTIONS = ['idle', 'walk', 'jump', 'light', 'heavy', 'kick', 'airKick', 'grab', 'special',
    'block', 'parry', 'dodge', 'dash', 'hit', 'down', 'win'];
  const f = createFighter(getChar('xiyangyang'), 'p1', 0);
  const missing = [];
  for (const act of ACTIONS) {
    f.action = act;
    f.phase = 'active';
    f.onGround = act !== 'jump' && act !== 'airKick' && act !== 'dodge' && act !== 'dash';
    for (const ph of ['startup', 'active', 'recovery']) {
      f.phase = ph;
      const pose = pickPose(f, 1);
      if (!POSES[pose]) missing.push(`${act}/${ph} -> ${pose}`);
    }
  }
  check('所有动作都能映射到一个存在的姿态', missing.length === 0, missing.join(', '));
  check('姿态表里的姿态都能被画出来', Object.keys(POSES).every(p => POSES[p] && typeof POSES[p] === 'object'),
    Object.keys(POSES).join(','));
  check('新增了前冲姿态', !!POSES.dash, Object.keys(POSES).join(','));
  check('前冲姿态是前倾的（lean 为正 = 朝前）', POSES.dash.lean > 0, String(POSES.dash.lean));
  check('后跃姿态是后仰的（lean 为负）', POSES.dodge.lean < 0, String(POSES.dodge.lean));

  // 绘制不依赖 DOM：用一个假的 ctx 记录调用，确认真的画了东西
  const calls = [];
  const fakeCtx = new Proxy({}, {
    get(t, k) {
      if (k === 'canvas') return { width: 100, height: 100 };
      if (k === 'measureText') return () => ({ width: 10 });
      if (k === 'createLinearGradient' || k === 'createRadialGradient') return () => ({ addColorStop() {} });
      return (...args) => { calls.push(k); };
    },
    set() { return true; }
  });
  for (const def of ROSTER) {
    calls.length = 0;
    drawFighter(fakeCtx, def, 0, 0, 'idle', { scale: 40, facing: 1, time: 0 });
    if (calls.length < 10) { check(`${def.name} 能画出东西`, false, '绘制调用仅 ' + calls.length + ' 次'); break; }
  }
  check('6 个角色都能被绘制（含羊与熊两套外形）', (() => {
    for (const def of ROSTER) {
      calls.length = 0;
      drawFighter(fakeCtx, def, 0, 0, 'idle', { scale: 40, facing: 1, time: 0 });
      if (calls.length < 10) return false;
    }
    return true;
  })());
  check('镜像朝向会翻转绘制', (() => {
    const rec = [];
    const c2 = new Proxy({}, {
      get(t, k) {
        if (k === 'canvas') return {};
        if (k === 'measureText') return () => ({ width: 10 });
        return (...a) => { if (k === 'scale') rec.push(a[0]); };
      },
      set() { return true; }
    });
    drawFighter(c2, ROSTER[0], 0, 0, 'idle', { scale: 40, facing: -1, time: 0 });
    return rec.some(v => v < 0);
  })());
  check('颜色变暗工具可用', /^#[0-9a-f]{6}$/i.test(shade('#ff8800', -0.2)), shade('#ff8800', -0.2));
}

/* ---------- 26. 平底锅（红太狼的专属技能） ---------- */
{
  const mk = (c1, c2) => {
    const s = arena(300, 360, { c1, c2 });
    return s;
  };

  // 灰太狼必须存在，否则这个技能永远用不出来
  check('灰太狼也是可选角色（否则技能无从触发）', ROSTER.some(r => r.id === PAN.targetId), PAN.targetId);
  check('红太狼在角色表里', ROSTER.some(r => r.id === PAN.ownerId));

  console.log('  --- 条件：只有红太狼打灰太狼才可用 ---');
  const okPair = mk('hongtailang', 'huitailang');
  check('红太狼 vs 灰太狼：技能可用', panAvailable(okPair.p1, okPair.p2) === true);
  check('初始状态是“就绪”', panStatus(okPair.p1, okPair.p2).usable === true,
    JSON.stringify(panStatus(okPair.p1, okPair.p2)));

  const wrongTarget = mk('hongtailang', 'xiyangyang');
  check('红太狼 vs 喜羊羊：技能不可用', panAvailable(wrongTarget.p1, wrongTarget.p2) === false);
  check('对手不是灰太狼时触发失败', tryUsePan(wrongTarget.p1, wrongTarget.p2) === false);
  check('对手不是灰太狼时提示原因', panStatus(wrongTarget.p1, wrongTarget.p2).text.includes('灰太狼'),
    panStatus(wrongTarget.p1, wrongTarget.p2).text);

  const wrongOwner = mk('huitailang', 'hongtailang');
  check('灰太狼自己不能放这个技能', panAvailable(wrongOwner.p1, wrongOwner.p2) === false);
  check('反过来（灰太狼 vs 红太狼）红太狼仍然可用', panAvailable(wrongOwner.p2, wrongOwner.p1) === true);
  const normalPair = mk('xiyangyang', 'huitailang');
  check('别的角色打灰太狼也不能用（这是红太狼专属）',
    panAvailable(normalPair.p1, normalPair.p2) === false);

  console.log('  --- 增伤：生效期间所有攻击都变强 ---');
  const dmgState = mk('hongtailang', 'huitailang');
  const heavyBefore = computeDamage(MOVES.heavy, dmgState.p1, dmgState.p2);
  const lightBefore = computeDamage(MOVES.light, dmgState.p1, dmgState.p2);
  tryUsePan(dmgState.p1, dmgState.p2);
  const heavyAfter = computeDamage(MOVES.heavy, dmgState.p1, dmgState.p2);
  const lightAfter = computeDamage(MOVES.light, dmgState.p1, dmgState.p2);
  check('生效期间重击伤害变高', heavyAfter > heavyBefore, `${heavyBefore} -> ${heavyAfter}`);
  check('生效期间轻击伤害也变高', lightAfter > lightBefore, `${lightBefore} -> ${lightAfter}`);
  check('增伤倍率符合配置', near(heavyAfter / heavyBefore, 1 + PAN.damageBonus, 0.02),
    `${(heavyAfter / heavyBefore).toFixed(3)} vs ${(1 + PAN.damageBonus).toFixed(3)}`);
  check('生效期间 panActive 为真', panActive(dmgState.p1) === true);

  console.log('  --- 冷却：不能一直用 ---');
  const cdState = mk('hongtailang', 'huitailang');
  check('第一次触发成功', tryUsePan(cdState.p1, cdState.p2) === true);
  check('生效期间再按无效', tryUsePan(cdState.p1, cdState.p2) === false);
  // 跑完生效期
  for (let i = 0; i < Math.ceil(PAN.duration * 60) + 3; i++) update(cdState, IN(), 1 / 60);
  check('生效期结束后技能关闭', panActive(cdState.p1) === false, cdState.p1.panReady.toFixed(2));
  check('生效结束后进入冷却', cdState.p1.panCd > 0, cdState.p1.panCd.toFixed(2));
  check('冷却中再按无效', tryUsePan(cdState.p1, cdState.p2) === false);
  check('冷却中状态显示剩余时间', panStatus(cdState.p1, cdState.p2).cd > 0,
    JSON.stringify(panStatus(cdState.p1, cdState.p2)));
  // 跑完冷却
  for (let i = 0; i < Math.ceil((PAN.cooldown + 1) * 60); i++) update(cdState, IN(), 1 / 60);
  check('冷却结束后回到“就绪”', panStatus(cdState.p1, cdState.p2).usable === true,
    JSON.stringify(panStatus(cdState.p1, cdState.p2)));
  check('冷却结束后可以再次触发', tryUsePan(cdState.p1, cdState.p2) === true);
  check('冷却时间不少于配置值', PAN.cooldown >= 5, String(PAN.cooldown));
  check('生效时长是有限的', PAN.duration > 0 && PAN.duration < 30, String(PAN.duration));

  console.log('  --- 通过输入触发（不是只能靠内部函数） ---');
  const inState = mk('hongtailang', 'huitailang');
  update(inState, IN({ pan: true }), 1 / 60);
  check('按技能键即可生效', panActive(inState.p1) === true);
  const inWrong = mk('hongtailang', 'xiyangyang');
  update(inWrong, IN({ pan: true }), 1 / 60);
  check('对手不对时按键无效', panActive(inWrong.p1) === false);

  console.log('  --- 生效期间命中：额外怒气与更长硬直 ---');
  const rageState = mk('hongtailang', 'huitailang');
  rageState.p1.rage = 0;
  // 先记录无锅时的一次命中怒气
  const noPan = mk('hongtailang', 'huitailang');
  noPan.p1.rage = 0;
  stepTo(noPan, noPan.p1, 'light');
  advanceUntil(noPan, {}, {}, 40);
  const rageNoPan = noPan.p1.rage;
  const stunNoPan = noPan.p2.hitStun;
  tryUsePan(rageState.p1, rageState.p2);
  rageState.p1.rage = 0;
  stepTo(rageState, rageState.p1, 'light');
  advanceUntil(rageState, {}, {}, 40);
  check('生效期间命中攒怒气更多', rageState.p1.rage > rageNoPan,
    `有锅 ${rageState.p1.rage.toFixed(1)} vs 无锅 ${rageNoPan.toFixed(1)}`);
  check('生效期间命中给对手更长硬直',
    (rageState.p2.hitStun + PAN.hitStunBonus) > stunNoPan,
    `有锅 ${rageState.p2.hitStun.toFixed(2)} vs 无锅 ${stunNoPan.toFixed(2)}`);

  console.log('  --- 新一局要重置技能状态 ---');
  const resetState = mk('hongtailang', 'huitailang');
  tryUsePan(resetState.p1, resetState.p2);
  check('触发后确实有冷却', resetState.p1.panCd > 0, resetState.p1.panCd.toFixed(1));
  // 注意：比分要从 0:0 起打。如果让红太狼直接拿到第 2 胜，整场比赛就结束了，
  // 根本不会进入下一局（那样就测不到 nextRound 的重置行为）。
  resetState.p1.wins = 0;
  resetState.p2.wins = 0;
  resetState.p2.hp = 0;
  checkRoundEnd(resetState);
  check('这一局结束（整场还没结束）', matchOver(resetState) === false, resetState.phase);
  for (let i = 0; i < 200; i++) update(resetState, IN(), 1 / 60);
  // nextRound 会创建全新的 fighter 对象，所以必须重新从 state 取引用
  const newP1 = resetState.p1;
  check('确实进入了第 2 局', resetState.round === 2, String(resetState.round));
  check('新一局红太狼的平底锅回到就绪', newP1.panCd === 0 && newP1.panReady === 0,
    `cd=${newP1.panCd} ready=${newP1.panReady}`);
  check('新一局仍然可用（对局条件没变）', panStatus(newP1, resetState.p2).usable === true,
    JSON.stringify(panStatus(newP1, resetState.p2)));
  check('新一局保留了胜场', newP1.wins === 1, String(newP1.wins));
  check('新一局回复满血', newP1.hp === newP1.hpMax, `${newP1.hp}/${newP1.hpMax}`);
  check('新一局双方引用重新接好', newP1.other === resetState.p2 && resetState.p2.other === newP1);

  console.log('  --- 角色数据层面 ---');
  check('灰太狼有独立的战斗属性', HUITAILANG.stats.hp > 1 && HUITAILANG.stats.damage > 1);
  check('灰太狼是狼外形（不是换色羊）', HUITAILANG.colors.kind === 'wolf', HUITAILANG.colors.kind);
  check('红太狼也还是狼外形', HONGTAILANG.colors.kind === 'wolf');
  check('技能配置有名字，界面能显示', typeof PAN.name === 'string' && PAN.name.length > 0, PAN.name);
}

console.log(`\n结果: ${pass} 通过, ${fail} 失败\n`);
process.exit(fail ? 1 : 0);
