/* 开发用：检查角色关键部位的像素，用来判断绘制是否正确。
 * 用法: node pixelcheck.mjs [角色id] [缩放]
 */
import { createSoftwareCanvas } from './softcanvas.mjs';
import { getChar } from './fighters.mjs';
import { drawFighter } from './fightersprite.mjs';

const id = process.argv[2] || 'xiyangyang';
const scale = Number(process.argv[3] || 140);
const W = 240, H = 320;
const feetY = 296, cx = 120;

const ctx = createSoftwareCanvas(W, H);
ctx.fillStyle = '#101820';
ctx.fillRect(0, 0, W, H);
drawFighter(ctx, getChar(id), cx, feetY, 'idle', { facing: 1, scale, time: 0 });

const b = ctx._buf;
const rd = (x, y) => {
  const i = (y * W + x) * 4;
  return `(${(b[i] * 255).toFixed(0)},${(b[i + 1] * 255).toFixed(0)},${(b[i + 2] * 255).toFixed(0)})`;
};

const R = 0.44;
const headY = 1.06;
const faceY = headY - R * 0.06;
const eyeR2 = R * 0.32, eyeDX = R * 0.42, eyeY = faceY + R * 0.03;
const dev = (lx, ly) => [Math.round(cx + lx * scale), Math.round(feetY - ly * scale)];

const pts = [
  ['头中心', 0.02, headY],
  ['左眼中心', 0.02 - eyeDX, eyeY],
  ['右眼中心', 0.02 + eyeDX, eyeY],
  ['额头(羊毛)', 0.02, headY + R * 0.62],
  ['下巴', 0.02, headY - R * 0.72],
  ['鼻子', 0.02, faceY - R * 0.34 + R * 0.1],
  ['左腮红', -0.7 * R + 0.02, eyeY - R * 0.06]
];
console.log(`角色 ${id}  scale=${scale}`);
for (const [n, lx, ly] of pts) {
  const [x, y] = dev(lx, ly);
  console.log(`  ${n.padEnd(12)} 设备(${x},${y})  像素=${rd(x, y)}`);
}
