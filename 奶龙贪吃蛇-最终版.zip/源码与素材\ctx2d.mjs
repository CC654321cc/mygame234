// 把游戏的 Canvas 2D 调用适配到 _raster.mjs 的几何绘制上。
// 游戏只用两种路径：圆角矩形（moveTo + 4×arcTo + closePath）和整圆（arc）。
// 这里对这两种做精确几何绘制，其它路径退化为多边形。
import { makeCanvas, W, H, parseColor } from './raster.mjs';

export { W, H };

export function makeCtx2D() {
  const c = makeCanvas();
  // 变换（只支持 setTransform/translate/scale，游戏够用）
  let xf = { sx: 1, sy: 1, tx: 0, ty: 0 };
  const xfStack = [];
  const stStack = [];
  const st = { fill: [0, 0, 0, 1], stroke: [0, 0, 0, 1], lw: 1, alpha: 1, shadow: null, blur: 0 };

  // 当前路径。一个 path 里可以有多条互不相连的子路径（moveTo 会断开），
  // 比如网格线、世界边墙这种"一次 stroke 画好几段线"的写法。
  let path = [];              // 当前子路径的点集
  let subpaths = [];          // 已经结束的子路径
  let pathKind = null;        // 'roundRect' | 'circle' | 'poly'
  let rr = null, circ = null;
  let arcPts = 0;             // 本路径里 arcTo 的调用次数

  const dev = (x, y) => ({ x: x * xf.sx + xf.tx, y: y * xf.sy + xf.ty });

  // 与 _raster 内部的覆盖率算法保持一致
  const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
  function rrCov(x, y, w, h, r, mode, lw) {
    return (px, py) => {
      const qx = Math.abs(px + .5 - (x + w / 2)) - (w / 2 - r);
      const qy = Math.abs(py + .5 - (y + h / 2)) - (h / 2 - r);
      const d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
      return mode === 'fill' ? clamp01(.5 - d) : clamp01(.5 - (Math.abs(d) - lw / 2));
    };
  }
  function circleCov(cx, cy, r, mode, lw) {
    return (px, py) => {
      const d = Math.hypot(px + .5 - cx, py + .5 - cy) - r;
      return mode === 'fill' ? clamp01(.5 - d) : clamp01(.5 - (Math.abs(d) - lw / 2));
    };
  }
  function polySdf(pts) {
    return (px, py) => {
      let best = 1e9, inside = false;
      for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
        const a = pts[j], b = pts[i];
        const vx = b.x - a.x, vy = b.y - a.y;
        const L2 = vx * vx + vy * vy || 1e-9;
        let t = ((px - a.x) * vx + (py - a.y) * vy) / L2;
        t = t < 0 ? 0 : t > 1 ? 1 : t;
        const dx = px - (a.x + t * vx), dy = py - (a.y + t * vy);
        if (dx * dx + dy * dy < best) best = dx * dx + dy * dy;
        if ((b.y > py) !== (a.y > py) && px < (a.x - b.x) * (py - b.y) / (b.y - a.y) + b.x) inside = !inside;
      }
      const d = Math.sqrt(best);
      return inside ? -d : d;
    };
  }
  function polyCov(pts, mode, lw) {
    const sdf = polySdf(pts);
    return (px, py) => {
      const d = sdf(px, py);
      return mode === 'fill' ? clamp01(.5 - d) : clamp01(.5 - (Math.abs(d) - lw / 2));
    };
  }

  function bbox(pts, extra) {
    let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
    for (const p of pts) { x0 = Math.min(x0, p.x); y0 = Math.min(y0, p.y); x1 = Math.max(x1, p.x); y1 = Math.max(y1, p.y); }
    return {
      x0: Math.max(0, Math.floor(x0 - extra - 1)), y0: Math.max(0, Math.floor(y0 - extra - 1)),
      x1: Math.min(W - 1, Math.ceil(x1 + extra + 1)), y1: Math.min(H - 1, Math.ceil(y1 + extra + 1))
    };
  }
  function bboxCircle(cx, cy, r, extra) {
    return {
      x0: Math.max(0, Math.floor(cx - r - extra - 1)), y0: Math.max(0, Math.floor(cy - r - extra - 1)),
      x1: Math.min(W - 1, Math.ceil(cx + r + extra + 1)), y1: Math.min(H - 1, Math.ceil(cy + r + extra + 1))
    };
  }

  // 从 moveTo + 4×arcTo 的顶点里还原圆角矩形
  function rrFromArcs() {
    if (arcPts !== 4 || path.length !== 5 || !rr) return null;
    const corners = path.slice(1);                       // 四个角顶点
    const xs = corners.map(p => p.x), ys = corners.map(p => p.y);
    const x1 = Math.min(...xs), x2 = Math.max(...xs);
    const y1 = Math.min(...ys), y2 = Math.max(...ys);
    if (!(x2 > x1) || !(y2 > y1)) return null;
    // 第一个点是圆角的起点，它到所在角顶点的距离就是半径
    const p0 = path[0];
    const cx = Math.abs(p0.x - x1) < Math.abs(p0.x - x2) ? x1 : x2;
    const cy = Math.abs(p0.y - y1) < Math.abs(p0.y - y2) ? y1 : y2;
    const r = Math.hypot(p0.x - cx, p0.y - cy);
    if (!(r > 0)) return null;
    return { x: x1, y: y1, w: x2 - x1, h: y2 - y1, r };
  }

  function drawPath(mode) {
    const color = mode === 'fill' ? st.fill : st.stroke;

    // 圆角矩形（roundRect 显式调用，或 moveTo + 4×arcTo）
    const box = (pathKind === 'roundRect' && rr && rr.w !== undefined) ? rr : rrFromArcs();
    if (box && box.w !== undefined) {
      const a = dev(box.x, box.y), b = dev(box.x + box.w, box.y + box.h);
      const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
      const w = Math.abs(b.x - a.x), h = Math.abs(b.y - a.y);
      const r = Math.min(box.r * Math.abs(xf.sx), Math.min(w, h) / 2);
      c._drawShape(bbox([{ x, y }, { x: x + w, y: y + h }], st.lw), rrCov(x, y, w, h, r, mode, st.lw), color);
      return;
    }
    // 整圆
    if (pathKind === 'circle' && circ) {
      const d = dev(circ.cx, circ.cy), r = circ.r * Math.abs(xf.sx);
      c._drawShape(bboxCircle(d.x, d.y, r, st.lw), circleCov(d.x, d.y, r, mode, st.lw), color);
      return;
    }
    // 任意多边形：多条子路径逐条绘制（各自收紧包围盒，也避免被连成一片）
    const subs = subpaths.slice();
    if (path.length >= 2) subs.push(path);
    for (const sub of subs) {
      const pts = sub.map(p => dev(p.x, p.y));
      c._drawShape(bbox(pts, st.lw), polyCov(pts, mode, st.lw), color);
    }
  }

  const api = {
    canvas: { width: W, height: H },
    imageSmoothingQuality: 'high',
    get fillStyle() { return st.fill; },
    set fillStyle(v) { st.fill = typeof v === 'string' ? parseColor(v) : v; },
    get strokeStyle() { return st.stroke; },
    set strokeStyle(v) { st.stroke = typeof v === 'string' ? parseColor(v) : v; },
    get lineWidth() { return st.lw; },
    set lineWidth(v) { st.lw = v; },
    get globalAlpha() { return st.alpha; },
    set globalAlpha(v) { st.alpha = v; },
    get shadowColor() { return st.shadow; },
    set shadowColor(v) { st.shadow = v ? parseColor(v) : null; },
    get shadowBlur() { return st.blur; },
    set shadowBlur(v) { st.blur = v; },
    set font(v) {}, set textAlign(v) {}, set textBaseline(v) {},
    createLinearGradient: (...a) => c.createLinearGradient(...a),
    createRadialGradient: (...a) => c.createRadialGradient(...a),

    setTransform(a, b, cc, d, e, f) { xf = { sx: a, sy: d, tx: e, ty: f }; },
    save() {
      xfStack.push({ ...xf });
      stStack.push({ ...st });
    },
    restore() {
      if (xfStack.length) xf = xfStack.pop();
      if (stStack.length) Object.assign(st, stStack.pop());
    },
    translate(tx, ty) { xf = { ...xf, tx: xf.tx + xf.sx * tx, ty: xf.ty + xf.sy * ty }; },
    scale(sx, sy) { xf = { ...xf, sx: xf.sx * sx, sy: xf.sy * sy }; },

    beginPath() { path = []; subpaths = []; pathKind = null; rr = null; circ = null; arcPts = 0; },
    closePath() {},
    // moveTo 开始一条新子路径，把上一条收好——否则多条线会被当成一个多边形连起来
    moveTo(x, y) { if (path.length) subpaths.push(path); path = [{ x, y }]; },
    lineTo(x, y) { path.push({ x, y }); },
    arcTo(x1, y1, x2, y2, r) {
      // 游戏画圆角矩形用的是 moveTo(角点) + 4×arcTo(角点,...)：
      // arcTo 的前两个参数正是该角顶点，四个角足以还原矩形和圆角半径。
      path.push({ x: x1, y: y1 });
      arcPts++;
      if (!rr) rr = { r };
    },
    arc(cx, cy, r, a0, a1) {
      if (Math.abs(a1 - a0) >= Math.PI * 1.99) {
        pathKind = 'circle';
        circ = { cx, cy, r };
      } else {
        pathKind = 'poly';
        const n = 48;
        for (let i = 0; i <= n; i++) {
          const a = a0 + (a1 - a0) * (i / n);
          path.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r });
        }
      }
    },
    roundRect(x, y, w, h, r) { pathKind = 'roundRect'; rr = { x, y, w, h, r }; path = [{ x, y }]; subpaths = []; },
    rect(x, y, w, h) { pathKind = 'poly'; subpaths = []; path = [{ x, y }, { x: x + w, y }, { x: x + w, y: y + h }, { x, y: y + h }]; },

    fill() { drawPath('fill'); },
    stroke() { drawPath('stroke'); },

    fillRect(x, y, w, h) { c.fillRect(x, y, w, h); },
    strokeRect(x, y, w, h) { c.strokeRect(x, y, w, h); },
    drawImage(img, dx, dy, dw, dh) { c.drawImage(img, dx, dy, dw, dh); },
    clearRect() {},
    measureText: () => ({ width: 0 }), fillText() {}, strokeText() {},

    // 供测试读取
    _buf: c._buf,
    get _state() { return st; }
  };

  // 把变换与状态同步到几何光栅化器
  let shadowSide = null;
  Object.defineProperty(api, '_sync', {
    value() {
      const real = c;
      real.setTransform(xf.sx, 0, 0, xf.sy, xf.tx, xf.ty);
      real.globalAlpha = st.alpha;
      real.lineWidth = st.lw;
      real.shadowBlur = st.blur;
      real.shadowColor = st.shadow ? 'rgba(0,0,0,1)' : null;
      real._shadowRGB = st.shadow;
      real.fillStyle = st.fill;
      real.strokeStyle = st.stroke;
    }
  });
  // 每次绘制前同步（注意用局部变量捕获方法名，避免闭包共享循环变量）
  for (const method of ['fill', 'stroke', 'fillRect', 'strokeRect', 'drawImage']) {
    const orig = api[method].bind(api);
    api[method] = (...a) => { api._sync(); return orig(...a); };
  }
  return api;
}
