// 无头逻辑测试：桩化 DOM/Canvas，真实执行 index.html 里的游戏脚本
import fs from 'node:fs';
import vm from 'node:vm';

const html = fs.readFileSync(new URL('./index.html', import.meta.url), 'utf8');
let js = html.match(/<script>([\s\S]*?)<\/script>/)[1];
// 去掉 IIFE 内的严格模式（严格模式下 let 不挂到 context 上），并注入内部状态访问钩子
js = js.replace("'use strict';", '');
js = js.replace(/\}\)\(\);\s*$/, `
  globalThis.__g = {
    get snake() { return player.body; },   set snake(v) { player.body = v; },
    get dir() { return player.dir; },      set dir(v) { player.dir = v; },
    get queue() { return player.queue; },  set queue(v) { player.queue = v; },
    get growth() { return player.growth; },set growth(v) { player.growth = v; },
    get player() { return player; },
    get bots() { return bots; },           set bots(v) { bots = v; },
    get foods() { return foods; },         set foods(v) { foods = v; },
    get score() { return score; },         set score(v) { score = v; },
    get kills() { return kills; },         set kills(v) { kills = v; },
    get state() { return state; },         set state(v) { state = v; },
    get speedKey() { return speedKey; },
    get tickMs() { return tickMs; },
    get acc() { return acc; },             set acc(v) { acc = v; },
    get respawnT() { return respawnT; },   set respawnT(v) { respawnT = v; },
    get cam() { return cam; },
    get alpha() { return alpha; },         set alpha(v) { alpha = v; },
    WCOLS, WROWS, VIS_COLS, CELL, SIZE, WORLD_W, WORLD_H, CAM_MAX_X, CAM_MAX_Y,
    clampCamX, clampCamY, camFocus, snapCam, segXY, draw,
    BOT_STYLES, BOT_RESPAWN_MS, RELIC_TTL, RELIC_SCORE, FOOD_TARGET, DIRS,
    addBot, spawnBot, spawnFoods, tick, loop, reset
  };
})();`);

// ---------- DOM 桩 ----------
const gradient = () => ({ addColorStop() {} });
const makeCtx = () => new Proxy({}, {
  get(t, k) {
    if (k in t) return t[k];
    if (k === 'createLinearGradient' || k === 'createRadialGradient') return gradient;
    return () => {};
  },
  set(t, k, v) { t[k] = v; return true; }
});

function mkEl(id) {
  const set = new Set();
  return {
    id, dataset: {}, style: {}, textContent: '', innerHTML: '',
    width: 480, height: 480, listeners: {},
    classList: { add: c => set.add(c), remove: c => set.delete(c), contains: c => set.has(c), _set: set },
    getContext: makeCtx,
    addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); },
    fire(type, ev = {}) { (this.listeners[type] || []).forEach(f => f({ preventDefault() {}, ...ev })); }
  };
}

const ids = ['cv', 'score', 'best', 'len', 'kills', 'bots', 'ov', 'ovTitle', 'ovText', 'ovLegend', 'ovFinal', 'ovBtn', 'pauseBtn'];
const byId = Object.fromEntries(ids.map(i => [i, mkEl(i)]));
const padButtons = ['up', 'down', 'left', 'right'].map(d => { const b = mkEl('pad-' + d); b.dataset.dir = d; return b; });

const docListeners = {};
const store = {};
const document = {
  getElementById: id => byId[id] || mkEl(id),
  querySelectorAll: sel => (sel.includes('data-dir') ? padButtons : []),
  addEventListener(type, fn) { (docListeners[type] ||= []).push(fn); },
  hidden: false
};
const winListeners = {};
const window = { devicePixelRatio: 1, addEventListener(type, fn) { (winListeners[type] ||= []).push(fn); } };
let rafQueue = [];
const requestAnimationFrame = fn => { rafQueue.push(fn); return rafQueue.length; };

let clock = 0;                                  // 可控假时钟，保证与帧时间戳同源
const sandbox = {
  window, document, requestAnimationFrame,
  performance: { now: () => clock },
  localStorage: {
    getItem: k => (k in store ? store[k] : null),
    setItem: (k, v) => { store[k] = String(v); }
  },
  console, Math, Date, Number, String, Array, Object, JSON, isNaN, Infinity,
  // 奶龙皮肤用到的 Image：测试里只关心它是否被正确赋值和触发 onload
  Image: class {
    constructor() { this.width = 0; this.height = 0; this.onload = null; this.src = ''; }
  }
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

// ---------- 运行 ----------
vm.runInContext(js, sandbox, { filename: 'game.js' });

const press = key => (winListeners.keydown || []).forEach(f => f({ key, code: key === ' ' ? 'Space' : 'Key', preventDefault() {} }));
const g = vm.runInContext('__g', sandbox);

let pass = 0, fail = 0;
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  -> ' + extra : '')); }
}

// 摆一个确定的局面：清空对手与果实，放置玩家和指定的对手
// 注意：引擎只读 body[0] + dir 来决定这一步走哪，身体走向纯粹为了好看，测试里可以自由摆
function setup(playerCells, playerDir, botSpecs = []) {
  g.bots = [];
  g.foods = [];
  g.snake = playerCells.map(p => ({ x: p[0], y: p[1] }));
  g.dir = { ...g.DIRS[playerDir] };
  g.queue = []; g.growth = 0;
  g.state = 1;
  g.kills = 0; g.respawnT = 0;
  return botSpecs.map(b => g.addBot(b.cells.map(p => ({ x: p[0], y: p[1] })), b.dir, b.name));
}

console.log('\n=== 贪吃蛇逻辑测试 ===\n');

console.log('· 基础玩法');
// 1. 初始状态
check('初始长度为 3', g.snake.length === 3, g.snake.length);
check('初始得分为 0', g.score === 0);
check('初始状态为 READY', g.state === 0, g.state);
check('初始有 3 只对手', g.bots.length === 3, g.bots.length);
check('三只对手名字不重复', new Set(g.bots.map(b => b.name)).size === 3);
check('对手不与玩家重叠', !g.bots.some(b => b.body.some(c => g.snake.some(s => s.x === c.x && s.y === c.y))));
check('初始果实数量正确', g.foods.length === g.FOOD_TARGET, g.foods.length);
check('果实不生成在蛇身上', !g.snake.some(s => g.foods.some(f => f.x === s.x && f.y === s.y)));

// 2. 触发开始
press(' ');
check('空格后进入 PLAYING', g.state === 1, g.state);

// 3. 吃食物 -> 长度增长（本次 +1，下一帧再 +1，共 +2）
setup([[9, 10], [8, 10], [7, 10]], 'right');
g.foods = [{ x: 10, y: 10, kind: 'normal', born: clock }];
const lenBefore = g.snake.length;
g.tick();
check('吃到果实当帧长 1 节', g.snake.length === lenBefore + 1, `${lenBefore} -> ${g.snake.length}`);
check('吃到果实后仍有待生长节数', g.growth === 1, g.growth);
g.dir = { x: 0, y: 1 }; g.queue = [];       // 拐弯，避免撞墙
g.foods = [];
g.tick();
check('下一帧再长 1 节（共 +2）', g.snake.length === lenBefore + 2, `${lenBefore} -> ${g.snake.length}`);
check('吃到果实得分增加', g.score > 0, g.score);
check('新果实不与蛇重叠', !g.foods.some(f => g.snake.concat(...g.bots.map(b => b.body)).some(s => s.x === f.x && s.y === f.y)));
check('蛇身无重叠格子', new Set(g.snake.map(s => s.x + ',' + s.y)).size === g.snake.length);

// 4. 撞墙判定
setup([[47, 5], [46, 5], [45, 5]], 'right');
g.tick();
check('撞右墙判定结束', g.state === 3, g.state);
check('撞墙提示正确', /墙壁/.test(byId.ovText.innerHTML), byId.ovText.innerHTML);

// 5. 撞自己判定（头向下撞上自己的第 2 节）
setup([[8, 8], [8, 9], [7, 9], [6, 9], [6, 8], [7, 8]], 'down');
g.tick();
check('自咬判定结束', g.state === 3, g.state);
check('自咬提示正确', /咬到/.test(byId.ovText.innerHTML), byId.ovText.innerHTML);

// 6. 允许进入即将腾空的尾格（不应误判）
setup([[3, 3], [3, 2], [2, 2], [2, 3]], 'down');
g.tick();
check('可安全追入尾部腾出的格子', g.state === 1, 'state=' + g.state + ' ' + byId.ovText.innerHTML);

// 7. 禁止 180 度掉头
setup([[9, 9], [8, 9], [7, 9]], 'right');
press('ArrowLeft');
check('不能直接反向掉头', g.queue.length === 0, JSON.stringify(g.queue));
press('ArrowUp');
check('可以转向垂直方向', g.queue.length === 1);
g.queue = [];

// 8. 暂停 / 继续
press(' ');
check('空格触发暂停', g.state === 2, g.state);
press(' ');
check('再按空格继续', g.state === 1, g.state);

// 9. 最高分持久化
g.score = 250;
setup([[47, 5], [46, 5], [45, 5]], 'right');
g.score = 250;
g.tick();
check('最高分写入 localStorage', Number(store['neon-snake-best']) >= 250, store['neon-snake-best']);
check('最高分显示已更新', byId.best.textContent === Number(store['neon-snake-best']), byId.best.textContent);

// 10. R 键重开
press('r');
check('R 键重新开始', g.state === 1 && g.score === 0 && g.snake.length === 3,
  `state=${g.state} score=${g.score} len=${g.snake.length}`);
check('重开后对手回到 3 只', g.bots.length === 3, g.bots.length);
check('重开后击杀归零', g.kills === 0, g.kills);

// 11. 速度切换（tick 越大 = 每一步间隔越长 = 越慢）
press('3');
check('数字键 3 切换迅捷', g.speedKey === 3 && g.tickMs === 125, g.tickMs);
press('1');
check('数字键 1 切换悠闲', g.speedKey === 1 && g.tickMs === 230, g.tickMs);
press('2');
check('数字键 2 切换标准', g.speedKey === 2 && g.tickMs === 175, g.tickMs);
check('默认落回标准档', g.speedKey === 2, g.speedKey);

// 11b. 贪吃蛇"太快了"的回归保护：每一步之间必须真的等够一个 tick
clock = 10000;
press('r');                       // 重开：此时 last 取假时钟 10000
g.loop(clock);                    // 对齐时间基准，本帧不该走
const head0 = { ...g.snake[0] };
clock += 10; g.loop(clock);        // 只过了 10ms，不该动
check('不足一个 tick 时蛇不动', g.snake[0].x === head0.x && g.snake[0].y === head0.y,
  `${head0.x},${head0.y} -> ${g.snake[0].x},${g.snake[0].y}`);
clock += 180; g.loop(clock);       // 累计 190ms > 一个标准 tick(175ms)，只该走一步
const head1 = { ...g.snake[0] };
check('一个 tick 只走一格', head1.x === head0.x + g.dir.x && head1.y === head0.y + g.dir.y,
  `${head0.x},${head0.y} -> ${head1.x},${head1.y} dir=${g.dir.x},${g.dir.y}`);
clock += 100; g.loop(clock);       // 再过 100ms（累计 115ms），仍未到 175ms，不该动
check('两次 tick 之间蛇保持静止', g.snake[0].x === head1.x && g.snake[0].y === head1.y,
  `${head1.x},${head1.y} -> ${g.snake[0].x},${g.snake[0].y}`);
clock += 80; g.loop(clock);        // 累计 195ms，跨过第二个 tick，应该再走一步
check('累计够一个 tick 后再走一格', g.snake[0].x === head1.x + g.dir.x && g.snake[0].y === head1.y + g.dir.y,
  `${head1.x},${head1.y} -> ${g.snake[0].x},${g.snake[0].y}`);
check('逻辑步进不会堆积补帧', g.acc < g.tickMs, 'acc=' + g.acc);
check('标准档单步间隔 >= 175ms', g.tickMs >= 175, g.tickMs);
g.acc = 0;

// 12. 满屏通关
setup([[10, 10], [9, 10], [8, 10]], 'right');
g.foods = [];
g.snake = [];
for (let y = 0; y < g.WROWS; y++) for (let x = 0; x < g.WCOLS; x++) g.snake.push({ x, y });
g.spawnFoods();
check('棋盘填满时判定通关', g.state === 3 && /通关/.test(byId.ovTitle.textContent), byId.ovTitle.textContent);

// 13. 主循环可跑帧
press('r');
check('重开后主循环有帧可执行', rafQueue.length > 0, String(rafQueue.length));
try {
  g.loop(clock);
  check('渲染帧执行无异常', true);
} catch (e) {
  check('渲染帧执行无异常', false, e.message);
}

console.log('\n· 人机对手规则');

// 14. 对手的头撞到我的身体 -> 对手暴毙、原地掉果实、我加一个击杀
// 玩家身体把对手四周围死，对手只剩"撞进玩家脑袋"这一条路（它自己也是玩家身体的一部分）
const killBot1 = setup([
  [9, 10], [8, 10], [8, 9], [8, 8], [8, 7], [8, 6], [9, 6], [10, 6], [10, 7],
  [10, 8], [10, 9], [11, 9], [11, 10], [12, 10]
], 'down', [
  { name: '青', dir: 'down', cells: [[9, 9], [9, 8], [9, 7]] }
])[0];
g.tick();
check('对手撞玩家身体后阵亡', g.bots.length === 0, g.bots.length);
check('玩家没死', g.state === 1, g.state);
check('击杀数 +1', g.kills === 1, g.kills);
check('阵亡对手掉出遗骸果实', g.foods.filter(f => f.kind === 'relic').length === killBot1.body.length,
  g.foods.filter(f => f.kind === 'relic').length);
check('遗骸果实落在对手身上', [[9, 9], [9, 8], [9, 7]].every(c =>
  g.foods.some(f => f.kind === 'relic' && f.x === c[0] && f.y === c[1])));
check('击杀后安排补位', g.respawnT === g.BOT_RESPAWN_MS, g.respawnT);

// 15. 我的头撞到对手的身体 -> 我失败
setup([[5, 5], [5, 6], [5, 7]], 'right', [
  { name: '青', dir: 'down', cells: [[6, 5], [6, 4], [6, 3]] }
]);
g.tick();
check('撞上对手身体判定失败', g.state === 3, g.state);
check('失败提示点名撞上了谁', /青/.test(byId.ovText.innerHTML), byId.ovText.innerHTML);
check('玩家失误不算击杀', g.kills === 0, g.kills);

// 15b. 对手的尾巴这帧就算要腾空，对我也是墙（防止两蛇叠格）
setup([[6, 9], [7, 9], [7, 10]], 'up', [
  { name: '青', dir: 'up', cells: [[6, 6], [6, 7], [6, 8]] }
]);
g.tick();
check('对手的尾格对我仍然是墙', g.state === 3, g.state);
check('撞尾格提示点名对手', /青/.test(byId.ovText.innerHTML), byId.ovText.innerHTML);

// 16. 头对头：两边同时抢一格，同归于尽
setup([
  [3, 1], [3, 0], [2, 0], [1, 0], [0, 0], [0, 1], [0, 2], [0, 3]
], 'left', [
  { name: '紫', dir: 'right', cells: [[1, 1], [1, 2], [1, 3]] }
]);
g.tick();
check('头对头双方都死', g.state === 3 && g.bots.length === 0, `state=${g.state} bots=${g.bots.length}`);
check('头对头提示正确', /同归于尽/.test(byId.ovText.innerHTML), byId.ovText.innerHTML);

// 17. 对手自己撞墙 -> 也掉果实，但不算我的击杀
setup([
  [0, 8], [0, 9], [1, 9], [2, 9], [3, 9], [3, 10], [3, 11], [2, 11], [1, 11], [0, 11], [0, 12]
], 'right', [
  { name: '玫红', dir: 'left', cells: [[0, 10], [1, 10], [2, 10]] }
]);
g.tick();
check('对手撞墙同样阵亡', g.bots.length === 0, g.bots.length);
check('撞墙掉果实', g.foods.filter(f => f.kind === 'relic').length === 3, g.foods.length);
check('对手自杀不算我的击杀', g.kills === 0, g.kills);
check('我安然无恙', g.state === 1, g.state);

// 18. 对手会自己抢果实吃
setup([
  [5, 3], [5, 4], [6, 4], [7, 4], [7, 5], [7, 6], [6, 6], [5, 6], [4, 6], [4, 7]
], 'up', [
  { name: '青', dir: 'right', cells: [[5, 5], [4, 5], [3, 5]] }
]);
g.foods = [{ x: 6, y: 5, kind: 'normal', born: clock }];
const botLenBefore = g.bots[0].body.length;
g.tick();
check('对手吃掉了抢到的果实', !g.foods.some(f => f.x === 6 && f.y === 5));
check('对手吃到果实会变长', g.bots[0].body.length === botLenBefore + 1, `${botLenBefore} -> ${g.bots[0].body.length}`);

// 19. 我吃遗骸果实，得分比普通果实高
setup([[5, 5], [5, 6], [5, 7]], 'right');
press('2');
g.score = 0;
g.foods = [{ x: 6, y: 5, kind: 'relic', born: clock, ttl: g.RELIC_TTL }];
g.tick();
check('吃遗骸果实得分翻倍', g.score === g.RELIC_SCORE * 2, g.score);
check('遗骸果实被吃掉后消失', !g.foods.some(f => f.kind === 'relic'), g.foods.length);

// 20. 遗骸果实会过期
clock += 1000;
setup([[5, 5], [5, 6], [5, 7]], 'right');
g.foods = [{ x: 15, y: 15, kind: 'relic', born: clock - g.RELIC_TTL - 1, ttl: g.RELIC_TTL }];
g.spawnFoods(clock);
check('过期遗骸果实被清掉', !g.foods.some(f => f.kind === 'relic'), JSON.stringify(g.foods));

// 21. 对手不会自己撞死（连跑 120 步 ×3 轮，陪练对手全程存活）
// 玩家每步挪到离对手最远的角落待着，避免"巨型对手被玩家堵在墙角"这种非 AI 问题导致的死亡
const CORNERS = [[1, 1, 'right'], [46, 1, 'down'], [1, 46, 'up'], [46, 46, 'left']];
let aliveRounds = 0;
for (let trial = 0; trial < 3; trial++) {
  setup([[18, 18], [18, 19], [17, 19]], 'up', [
    { name: '青', dir: 'left', cells: [[2, 2], [3, 2], [4, 2]] }
  ]);
  g.bots[0].style = Object.assign({}, g.bots[0].style, { mistake: 0 });
  for (let i = 0; i < 120 && g.bots.length; i++) {
    const bh = g.bots[0].body[0];
    let pick = CORNERS[0], far = -1;
    for (const c of CORNERS) {
      const d = Math.abs(c[0] - bh.x) + Math.abs(c[1] - bh.y);
      if (d > far) { far = d; pick = c; }
    }
    const d = g.DIRS[pick[2]];
    g.snake = [0, 1, 2].map(k => ({ x: pick[0] - d.x * k, y: pick[1] - d.y * k }));
    g.dir = { ...d }; g.queue = []; g.growth = 0;
    g.tick();
  }
  if (g.bots.length === 1) aliveRounds++;
}
check('对手连跑 120 步 ×3 轮都不会自己撞死', aliveRounds === 3, aliveRounds + '/3');
check('对手全程在棋盘内', !g.bots[0] || g.bots[0].body.every(c => c.x >= 0 && c.y >= 0 && c.x < g.WCOLS && c.y < g.WROWS));

// 22. 阵亡的对手会补位回来
setup([[10, 10], [9, 10], [8, 10]], 'right');
g.bots = [];
g.kills = 0;
g.respawnT = 0;
for (let i = 0; i < 80 && g.bots.length === 0; i++) {
  clock += 100;
  g.snake = [{ x: 10, y: 10 }, { x: 9, y: 10 }, { x: 8, y: 10 }];
  g.dir = g.DIRS.right; g.queue = []; g.growth = 0;
  g.loop(clock);
}
check('阵亡的对手会补位', g.bots.length === 1, 'bots=' + g.bots.length);

console.log('\n· 视角跟随（摄像机）');

// 23. 地图比一屏大，镜头对准奶龙
check('地图比视野大得多', g.WCOLS > g.VIS_COLS && g.WROWS > g.VIS_COLS, `${g.WCOLS}x${g.WROWS} vs 视野 ${g.VIS_COLS}`);
setup([[10, 10], [9, 10], [8, 10]], 'right');
g.snapCam();
check('镜头对准奶龙', Math.abs(g.cam.x - 12) < 1e-6 && Math.abs(g.cam.y - 12) < 1e-6, JSON.stringify(g.cam));
press('r');
const focus0 = g.camFocus();
check('重开后镜头立刻架在奶龙身上（不从角落滑过来）',
  Math.abs(g.cam.x - g.clampCamX(focus0.x - g.SIZE / 2)) < 1e-6 &&
  Math.abs(g.cam.y - g.clampCamY(focus0.y - g.SIZE / 2)) < 1e-6, JSON.stringify(g.cam));

// 24. 奶龙往前走，镜头跟着滚
setup([[10, 10], [9, 10], [8, 10]], 'right');
g.snapCam();
g.respawnT = 1e9;                        // 别让对手上来挡路，这节只测镜头
const camBefore = g.cam.x;
for (let i = 0; i < 20; i++) { clock += 200; g.loop(clock); }
const headX = g.snake[0].x;
check('奶龙确实前进了', headX > 20, 'x=' + headX);
check('镜头跟着奶龙滚过去', g.cam.x > camBefore + 200, `${camBefore} -> ${g.cam.x}`);
check('镜头和奶龙保持同一个相对位置',
  Math.abs(g.cam.x - ((headX + .5) * g.CELL - g.SIZE / 2)) < 40, 'cam=' + g.cam.x);

// 25. 镜头贴到世界边缘就停住，不会推出地图外
setup([[2, 2], [1, 2], [0, 2]], 'up');
g.snapCam();
check('贴左上角时镜头被夹在世界内', g.cam.x === 0 && g.cam.y === 0, JSON.stringify(g.cam));
setup([[45, 45], [44, 45], [43, 45]], 'right');
g.snapCam();
check('贴右下角时镜头也不越界',
  Math.abs(g.cam.x - g.CAM_MAX_X) < 1e-6 && Math.abs(g.cam.y - g.CAM_MAX_Y) < 1e-6, JSON.stringify(g.cam));

// 26. 帧间插值：画面是滑着走过去，不是一格格跳
const mid = g.segXY({ body: [{ x: 11, y: 10 }, { x: 10, y: 10 }], prevBody: [{ x: 10, y: 10 }, { x: 9, y: 10 }] }, 0, .5);
check('渲染插值让蛇停在两格中间', mid.x === 10.5 && mid.y === 10, JSON.stringify(mid));
const done = g.segXY({ body: [{ x: 11, y: 10 }], prevBody: [{ x: 10, y: 10 }] }, 0, 1);
check('插值走满时就是逻辑位置', done.x === 11, JSON.stringify(done));
const grown = g.segXY({
  body: [{ x: 12, y: 10 }, { x: 11, y: 10 }, { x: 10, y: 10 }],
  prevBody: [{ x: 11, y: 10 }, { x: 10, y: 10 }]
}, 2, .5);
check('新长出来的尾巴留在原地不闪', grown.x === 10 && grown.y === 10, JSON.stringify(grown));

// 27. 果实撒在奶龙附近的一圈里，逼着你到处跑（而不是缩在角落等）
setup([[20, 20], [19, 20], [18, 20]], 'right');
g.foods = [];
g.spawnFoods(clock);
const dist = g.foods.map(f => Math.abs(f.x - 20) + Math.abs(f.y - 20));
check('普通果实撒在奶龙附近', dist.length > 0 && dist.every(v => v >= 2 && v <= 20), JSON.stringify(dist));

// 28. 摄像机状态能在真实渲染帧里跑通
try {
  clock += 200; g.loop(clock);
  check('带摄像机的渲染帧执行无异常', true);
} catch (e) {
  check('带摄像机的渲染帧执行无异常', false, e.message);
}

console.log(`\n结果: ${pass} 通过, ${fail} 失败\n`);
process.exit(fail ? 1 : 0);
