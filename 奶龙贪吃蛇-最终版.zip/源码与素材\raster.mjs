// 极简软件光栅化器（开发验证用），只实现游戏真正用到的那几个 Canvas 2D 调用。
// 设计目标是"简单到可以一眼看穿"，而不是完整模拟浏览器。

const W = 480, H = 480;

// ---------- 颜色 ----------
function hsl2rgb(h, s, l) {
  h = (((h % 360) + 360) % 360) / 360;
  const q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = t => {
    t = (t + 1) % 1;
    return t < 1 / 6 ? p + (q - p) * 6 * t : t < .5 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p;
  };
  return [f(h + 1 / 3) * 255, f(h) * 255, f(h - 1 / 3) * 255];
}
function parseColor(v) {
  const s = String(v).trim();
  let m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1]; }
  m = /^#([0-9a-f]{3})$/i.exec(s);
  if (m) { const c = m[1]; return [parseInt(c[0] + c[0], 16), parseInt(c[1] + c[1], 16), parseInt(c[2] + c[2], 16), 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) { const p = m[1].split(',').map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; }
  m = /^hsla?\(([^)]+)\)$/i.exec(s);
  if (m) {
    // 注意：hsl 的饱和度/亮度通常带百分号（100%, 63%），要用 parseFloat
    const p = m[1].split(',').map(v => parseFloat(v));
    const rgb = hsl2rgb(p[0], p[1] / 100, p[2] / 100);
    return [rgb[0], rgb[1], rgb[2], p.length > 3 ? p[3] : 1];
  }
  throw new Error('无法解析颜色: ' + s);
}
function makeGradient(kind, p) {
  const stops = [];
  return {
    kind, p, stops,
    addColorStop(o, c) { stops.push([o, parseColor(c)]); },
    sample(x, y) {
      let t;
      if (kind === 'linear') {
        const [x0, y0, x1, y1] = p;
        const dx = x1 - x0, dy = y1 - y0, len2 = dx * dx + dy * dy || 1;
        t = ((x - x0) * dx + (y - y0) * dy) / len2;
      } else {
        const [x0, y0, r0, x1, y1, r1] = p;
        t = (Math.hypot(x - x1, y - y1) - r0) / ((r1 - r0) || 1);
      }
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      if (!stops.length) return [0, 0, 0, 0];
      if (t <= stops[0][0]) return stops[0][1];
      for (let i = 1; i < stops.length; i++) {
        if (t <= stops[i][0]) {
          const [o0, c0] = stops[i - 1], [o1, c1] = stops[i];
          const k = (t - o0) / ((o1 - o0) || 1);
          return [c0[0] + (c1[0] - c0[0]) * k, c0[1] + (c1[1] - c0[1]) * k, c0[2] + (c1[2] - c0[2]) * k, c0[3] + (c1[3] - c0[3]) * k];
        }
      }
      return stops[stops.length - 1][1];
    }
  };
}

export function makeCanvas() {
  const buf = new Float32Array(W * H * 4);     // 非预乘, 0..1
  let xf = { sx: 1, sy: 1, tx: 0, ty: 0 };
  let state = { fill: [0, 0, 0, 1], stroke: [0, 0, 0, 1], lw: 1, alpha: 1, shadow: null, blur: 0 };
  const stateStack = [], xfStack = [];

  const toDev = (x, y) => ({ x: x * xf.sx + xf.tx, y: y * xf.sy + xf.ty });

  // 覆盖函数：返回某像素 (px,py) 的形状覆盖率 0..1
  const circleCov = (cx, cy, r, mode) => (px, py) => {
    const d = Math.hypot(px + .5 - cx, py + .5 - cy) - r;
    return mode === 'fill' ? clamp01(.5 - d) : clamp01(.5 - (Math.abs(d) - state.lw / 2));
  };
  const rectCov = (x, y, w, h, r, mode) => (px, py) => {
    const qx = Math.abs(px + .5 - (x + w / 2)) - (w / 2 - r);
    const qy = Math.abs(py + .5 - (y + h / 2)) - (h / 2 - r);
    const d = Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
    return mode === 'fill' ? clamp01(.5 - d) : clamp01(.5 - (Math.abs(d) - state.lw / 2));
  };

  // 在包围盒内求覆盖率，输出到 mask
  function rasterize(mask, bbox, cov) {
    for (let y = bbox.y0; y <= bbox.y1; y++) {
      for (let x = bbox.x0; x <= bbox.x1; x++) {
        const v = cov(x, y);
        if (v > 0) mask[y * W + x] = Math.max(mask[y * W + x], v);
      }
    }
  }
  const bboxAll = { x0: 0, y0: 0, x1: W - 1, y1: H - 1 };
  function bboxOfCircle(cx, cy, r, extra = 0) {
    return {
      x0: Math.max(0, Math.floor(cx - r - extra - 1)), y0: Math.max(0, Math.floor(cy - r - extra - 1)),
      x1: Math.min(W - 1, Math.ceil(cx + r + extra + 1)), y1: Math.min(H - 1, Math.ceil(cy + r + extra + 1))
    };
  }
  function bboxOfRect(x, y, w, h, extra = 0) {
    return {
      x0: Math.max(0, Math.floor(x - extra - 1)), y0: Math.max(0, Math.floor(y - extra - 1)),
      x1: Math.min(W - 1, Math.ceil(x + w + extra + 1)), y1: Math.min(H - 1, Math.ceil(y + h + extra + 1))
    };
  }

  // 绘制一个形状：求覆盖率 → 画阴影 → 画本体
  function drawShape(bbox, cov, color) {
    if (!bbox || bbox.x1 < bbox.x0 || bbox.y1 < bbox.y0) return;
    const mask = new Float32Array(W * H);
    for (let y = bbox.y0; y <= bbox.y1; y++) {
      for (let x = bbox.x0; x <= bbox.x1; x++) {
        const v = cov(x, y);
        if (v > 0) mask[y * W + x] = v;
      }
    }
    paintShadow(mask, bbox);
    paintMask(mask, bbox, color);
  }

  // 用掩膜把颜色画到画布上
  function paintMask(mask, bbox, color) {
    for (let y = bbox.y0; y <= bbox.y1; y++) {
      for (let x = bbox.x0; x <= bbox.x1; x++) {
        const m = mask[y * W + x];
        if (m <= 0) continue;
        const c = (color && typeof color.sample === 'function') ? color.sample(x + .5, y + .5) : color;
        if (!c) continue;
        blend(x, y, c, m * c[3] * state.alpha);
      }
    }
  }
  function blend(x, y, c, a) {
    if (a <= 0) return;
    if (a > 1) a = 1;
    const i = (y * W + x) * 4;
    const da = buf[i + 3];
    const na = a + da * (1 - a);
    if (na <= 0) { buf[i] = buf[i + 1] = buf[i + 2] = buf[i + 3] = 0; return; }
    buf[i] = (c[0] / 255 * a + buf[i] * da * (1 - a)) / na;
    buf[i + 1] = (c[1] / 255 * a + buf[i + 1] * da * (1 - a)) / na;
    buf[i + 2] = (c[2] / 255 * a + buf[i + 2] * da * (1 - a)) / na;
    buf[i + 3] = na;
  }

  // 阴影：对掩膜做两次可分离盒式模糊后单独画一层
  function paintShadow(mask, bbox) {
    if (!state.shadow || state.blur <= 0) return;
    const sc = state.shadow;
    if (sc[3] <= 0) return;
    const pad = Math.ceil(state.blur * 1.6) + 2;
    const r = {
      x0: Math.max(0, bbox.x0 - pad), y0: Math.max(0, bbox.y0 - pad),
      x1: Math.min(W - 1, bbox.x1 + pad), y1: Math.min(H - 1, bbox.y1 + pad)
    };
    const rad = Math.max(1, Math.round(state.blur * .7));
    let src = mask;
    let tmp = new Float32Array(W * H);
    for (let pass = 0; pass < 2; pass++) {
      // 横向
      const horiz = new Float32Array(W * H);
      for (let y = r.y0; y <= r.y1; y++) {
        let sum = 0;
        for (let i = -rad; i <= rad; i++) sum += src[y * W + clampInt(r.x0 + i, r.x0, r.x1)];
        for (let x = r.x0; x <= r.x1; x++) {
          horiz[y * W + x] = sum / (2 * rad + 1);
          sum += src[y * W + clampInt(x + rad + 1, r.x0, r.x1)] - src[y * W + clampInt(x - rad, r.x0, r.x1)];
        }
      }
      // 纵向
      for (let x = r.x0; x <= r.x1; x++) {
        let sum = 0;
        for (let i = -rad; i <= rad; i++) sum += horiz[clampInt(r.y0 + i, r.y0, r.y1) * W + x];
        for (let y = r.y0; y <= r.y1; y++) {
          tmp[y * W + x] = sum / (2 * rad + 1);
          sum += horiz[clampInt(y + rad + 1, r.y0, r.y1) * W + x] - horiz[clampInt(y - rad, r.y0, r.y1) * W + x];
        }
      }
      src = tmp; tmp = new Float32Array(W * H);
    }
    paintMask(src, r, sc);
  }

  const api = {
    _buf: buf,
    canvas: { width: W, height: H },
    imageSmoothingQuality: 'high',
    get fillStyle() { return state.fill; },
    set fillStyle(v) { state.fill = typeof v === 'string' ? parseColor(v) : v; },
    get strokeStyle() { return state.stroke; },
    set strokeStyle(v) { state.stroke = typeof v === 'string' ? parseColor(v) : v; },
    get lineWidth() { return state.lw; },
    set lineWidth(v) { state.lw = v; },
    get globalAlpha() { return state.alpha; },
    set globalAlpha(v) { state.alpha = v; },
    get shadowColor() { return state.shadow ? 'set' : null; },
    set shadowColor(v) { state.shadow = v ? parseColor(v) : null; },
    get shadowBlur() { return state.blur; },
    set shadowBlur(v) { state.blur = v; },
    set font(v) {}, set textAlign(v) {}, set textBaseline(v) {},
    createLinearGradient: (a, b, c, d) => makeGradient('linear', [a, b, c, d]),
    createRadialGradient: (a, b, c, d, e, f) => makeGradient('radial', [a, b, c, d, e, f]),

    setTransform(a, b, c, d, e, f) { xf = { sx: a, sy: d, tx: e, ty: f }; },
    save() { stateStack.push({ ...state }); xfStack.push({ ...xf }); },
    restore() { if (stateStack.length) state = stateStack.pop(); if (xfStack.length) xf = xfStack.pop(); },
    translate(tx, ty) { xf = { ...xf, tx: xf.tx + xf.sx * tx, ty: xf.ty + xf.sy * ty }; },
    scale(sx, sy) { xf = { ...xf, sx: xf.sx * sx, sy: xf.sy * sy }; },

    beginPath() {}, closePath() {}, moveTo() {}, lineTo() {}, arcTo() {},
    rect() {}, roundRect() {},
    arc() {},                                   // 路径式绘制本游戏用不到
    measureText: () => ({ width: 0 }), fillText() {}, strokeText() {}, clearRect() {},

    _drawShape: drawShape,

    // 直接用几何形状绘制
    fillRect(x, y, w, h) {
      const a = toDev(x, y), b = toDev(x + w, y + h);
      const rx = Math.min(a.x, b.x), ry = Math.min(a.y, b.y);
      const rw = Math.abs(b.x - a.x), rh = Math.abs(b.y - a.y);
      drawShape(bboxOfRect(rx, ry, rw, rh), rectCov(rx, ry, rw, rh, 0, 'fill'), state.fill);
    },
    strokeRect(x, y, w, h) {
      const a = toDev(x, y), b = toDev(x + w, y + h);
      const rx = Math.min(a.x, b.x), ry = Math.min(a.y, b.y);
      const rw = Math.abs(b.x - a.x), rh = Math.abs(b.y - a.y);
      drawShape(bboxOfRect(rx, ry, rw, rh, state.lw), rectCov(rx, ry, rw, rh, 0, 'stroke'), state.stroke);
    },
    drawImage(img, dx, dy, dw, dh) {
      if (!img || !img._pixels) return;
      if (dw === undefined) { dw = img._pixels.w; dh = img._pixels.h; }
      const { w, h, data } = img._pixels;
      const flipX = xf.sx < 0;
      const ox = dx * xf.sx + xf.tx, oy = dy * xf.sy + xf.ty;
      const sw = dw * Math.abs(xf.sx), sh = dh * Math.abs(xf.sy);
      // 翻转时画布上的实际左边界
      const left = flipX ? ox - sw : ox;
      const bb = bboxOfRect(left, oy, sw, sh);
      for (let py = bb.y0; py <= bb.y1; py++) {
        for (let px = bb.x0; px <= bb.x1; px++) {
          let u = (px + .5 - left) / sw, v = (py + .5 - oy) / sh;
          if (u < 0 || v < 0 || u >= 1 || v >= 1) continue;
          if (flipX) u = 1 - u;
          const fx = u * w - .5, fy = v * h - .5;
          const x0 = clampInt(Math.floor(fx), 0, w - 1), y0 = clampInt(Math.floor(fy), 0, h - 1);
          const x1 = clampInt(x0 + 1, 0, w - 1), y1 = clampInt(y0 + 1, 0, h - 1);
          const tx = clamp01(fx - x0), ty = clamp01(fy - y0);
          const smp = (ch, yy, xx) => data[(yy * w + xx) * 4 + ch];
          const mix = (ch) => (smp(ch, y0, x0) * (1 - tx) + smp(ch, y0, x1) * tx) * (1 - ty)
            + (smp(ch, y1, x0) * (1 - tx) + smp(ch, y1, x1) * tx) * ty;
          const a = mix(3) / 255;
          if (a <= .003) continue;
          blend(px, py, [mix(0), mix(1), mix(2)], a * state.alpha);
        }
      }
    }
  };
  return api;
}

function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
function clampInt(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

export { W, H, parseColor };
