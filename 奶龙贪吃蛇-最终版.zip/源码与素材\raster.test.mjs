// 光栅化器自检：确认每个几何图元都真的画到了正确位置
import { makeCtx2D, W, H } from './ctx2d.mjs';

let pass = 0, fail = 0;
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  PASS  ' + name); }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  -> ' + extra : '')); }
}
const mk = () => makeCtx2D();
const at = (c, x, y) => { const b = c._buf, i = (y * W + x) * 4; return [b[i] * 255, b[i + 1] * 255, b[i + 2] * 255, b[i + 3]]; };
const near = (v, t, tol = 6) => Math.abs(v - t) <= tol;

console.log('\n=== 光栅化器自检 ===\n');

// 1. fillRect
{
  const c = mk();
  c.fillStyle = '#ff0000';
  c.fillRect(100, 100, 50, 50);
  const [r, g, b, a] = at(c, 120, 120);
  check('fillRect 内部为纯红', near(r, 255) && near(g, 0) && near(b, 0) && a > .99, `rgba(${r|0},${g|0},${b|0},${a.toFixed(2)})`);
  const [, , , a2] = at(c, 90, 90);
  check('fillRect 外部保持透明', a2 < .01, 'a=' + a2.toFixed(3));
}

// 2. 变换：setTransform(2) 后逻辑坐标应放大两倍
{
  const c = mk();
  c.setTransform(2, 0, 0, 2, 0, 0);
  c.fillStyle = '#00ff00';
  c.fillRect(50, 50, 25, 25);
  const [r, g, b] = at(c, 120, 120);
  check('setTransform(2x) 缩放生效', near(g, 255) && near(r, 0), `rgb(${r|0},${g|0},${b|0})`);
  const [, , , a] = at(c, 220, 220);
  check('缩放后范围外透明', a < .01, 'a=' + a.toFixed(3));
}

// 3. roundRect + fill（游戏画蛇身用的就是这条路径）
{
  const c = mk();
  c.beginPath();
  c.moveTo(100 + 8, 100);
  c.arcTo(150, 100, 150, 150, 8);
  c.arcTo(150, 150, 100, 150, 8);
  c.arcTo(100, 150, 100, 100, 8);
  c.arcTo(100, 100, 150, 100, 8);
  c.closePath();
  c.fillStyle = '#ffffff';
  c.fill();
  const [r, , , a] = at(c, 125, 125);
  check('roundRect 中心被白色填满', near(r, 255) && a > .99, `rgba(${r|0},a=${a.toFixed(2)})`);
  const [, , , aCorner] = at(c, 101, 101);
  check('roundRect 圆角处是空的', aCorner < .5, 'a=' + aCorner.toFixed(3));
  const [, , , aInside] = at(c, 110, 103);
  check('roundRect 边中位置有填充', aInside > .8, 'a=' + aInside.toFixed(3));
}

// 4. arc + fill（圆形）
{
  const c = mk();
  c.beginPath();
  c.arc(200, 200, 20, 0, Math.PI * 2);
  c.fillStyle = '#0000ff';
  c.fill();
  const [r, g, b] = at(c, 200, 200);
  check('fill 整圆中心为蓝', near(b, 255) && near(r, 0), `rgb(${r|0},${g|0},${b|0})`);
  const [, , , a] = at(c, 200 + 30, 200);
  check('圆外透明', a < .01, 'a=' + a.toFixed(3));
}

// 5. 圆形描边
{
  const c = mk();
  c.beginPath();
  c.arc(200, 200, 30, 0, Math.PI * 2);
  c.lineWidth = 4;
  c.strokeStyle = '#ffffff';
  c.stroke();
  const [, , , on] = at(c, 200 + 30, 200);
  const [, , , inside] = at(c, 200, 200);
  check('stroke 圆环在半径处有像素', on > .5, 'a=' + on.toFixed(3));
  check('stroke 圆环内部是空的', inside < .05, 'a=' + inside.toFixed(3));
}

// 6. 渐变填充
{
  const c = mk();
  const g = c.createLinearGradient(0, 0, W, 0);
  g.addColorStop(0, '#000000');
  g.addColorStop(1, '#ffffff');
  c.fillStyle = g;
  c.fillRect(0, 0, W, 10);
  const [rL] = at(c, 5, 5), [rM] = at(c, W / 2, 5), [rR] = at(c, W - 5, 5);
  check('线性渐变左端偏暗', rL < 40, 'r=' + (rL | 0));
  check('线性渐变中部居中', rM > 90 && rM < 170, 'r=' + (rM | 0));
  check('线性渐变右端偏亮', rR > 200, 'r=' + (rR | 0));
}

// 7. 阴影
{
  const c = mk();
  c.shadowColor = 'rgba(255,0,0,1)';
  c.shadowBlur = 12;
  c.fillStyle = '#000000';
  c.beginPath();
  c.arc(200, 200, 20, 0, Math.PI * 2);
  c.fill();
  const [, , , justOutside] = at(c, 200 + 28, 200);
  check('阴影在形状外侧产生半透明像素', justOutside > .02 && justOutside < .95, 'a=' + justOutside.toFixed(3));
}

// 8. globalAlpha
{
  const c = mk();
  c.globalAlpha = .5;
  c.fillStyle = '#ffffff';
  c.fillRect(100, 100, 40, 40);
  const [, , , a] = at(c, 120, 120);
  check('globalAlpha 生效', Math.abs(a - .5) < .02, 'a=' + a.toFixed(3));
}

// 9. save / restore
{
  const c = mk();
  c.fillStyle = '#ff0000';
  c.save();
  c.fillStyle = '#00ff00';
  c.fillRect(0, 0, 10, 10);
  c.restore();
  c.fillRect(20, 0, 10, 10);
  const [g1] = at(c, 5, 5), [r2] = at(c, 25, 5);
  check('save/restore 恢复 fillStyle', near(g1, 0) && near(r2, 255), `g=${g1|0} r=${r2|0}`);
}

// 10. 变换状态也随 save/restore 恢复
{
  const c = mk();
  c.save();
  c.translate(100, 100);
  c.fillStyle = '#ffffff';
  c.fillRect(0, 0, 10, 10);
  c.restore();
  const [, , , a] = at(c, 5, 5);
  const [, , , b] = at(c, 105, 105);
  check('translate 生效', b > .9, 'a=' + b.toFixed(3));
  check('restore 后变换复原', a < .01, 'a=' + a.toFixed(3));
}

console.log(`\n结果: ${pass} 通过, ${fail} 失败\n`);
process.exit(fail ? 1 : 0);
