// 把 index-src.html（图片外链）+ nailong.png → index.html（图片内联，单文件可双击玩）
// 用法：node build.mjs
import fs from 'node:fs';

const srcUrl = new URL('./index-src.html', import.meta.url);
const pngUrl = new URL('./nailong.png', import.meta.url);
const outUrl = new URL('./index.html', import.meta.url);

const src = fs.readFileSync(srcUrl, 'utf8');
const b64 = fs.readFileSync(pngUrl).toString('base64');

const NEEDLE = "const NAILONG_SRC = 'nailong.png';";
if (!src.includes(NEEDLE)) {
  console.error('× 在 index-src.html 里找不到 NAILONG_SRC 那一行，构建中止。');
  process.exit(1);
}

const out = src.replace(NEEDLE, "const NAILONG_SRC = 'data:image/png;base64," + b64 + "';");

// 自检：除图片那一处引用外，两份必须逐字节等价
const strip = s => s.replace(/const NAILONG_SRC = '[^']*';/, 'const NAILONG_SRC = <IMG>;');
if (strip(out) !== strip(src)) {
  console.error('× 自检失败：两份源码除图片引用外还有差异。');
  process.exit(1);
}

fs.writeFileSync(outUrl, out);
console.log('✓ index.html 已生成  ' + out.length + ' 字节（图片 ' + b64.length + ' 字节 base64 内联）');
