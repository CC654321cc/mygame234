// 软件光栅化 + 真实执行 index.html 里的绘制代码，输出 PNG 用于肉眼验证
// 仅用于开发验证，不参与交付。
import fs from 'node:fs';
import vm from 'node:vm';
import zlib from 'node:zlib';
import { makeCtx2D, W, H } from './ctx2d.mjs';

// ---------- PNG 解码（只处理 8bit RGBA / RGB） ----------
function pngDecode(buf) {
  let off = 8, w = 0, h = 0, ct = 0, bd = 0, idat = [];
  while (off < buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('ascii', off + 4, off + 8);
    const data = buf.subarray(off + 8, off + 8 + len);
    if (type === 'IHDR') {
      w = data.readUInt32BE(0); h = data.readUInt32BE(4); bd = data[8]; ct = data[9];
    } else if (type === 'IDAT') idat.push(data);
    else if (type === 'IEND') break;
    off += 12 + len;
  }
  if (bd !== 8) throw new Error('只支持 8bit PNG，实际 ' + bd);
  const ch = ct === 6 ? 4 : ct === 2 ? 3 : ct === 0 ? 1 : (() => { throw new Error('色彩类型 ' + ct); })();
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = w * ch;
  const out = Buffer.alloc(w * h * 4);
  let prev = Buffer.alloc(stride);
  for (let y = 0; y < h; y++) {
    const ft = raw[y * (stride + 1)];
    const line = Buffer.from(raw.subarray(y * (stride + 1) + 1, y * (stride + 1) + 1 + stride));
    for (let i = 0; i < stride; i++) {
      const a = i >= ch ? line[i - ch] : 0, b = prev[i], c = i >= ch ? prev[i - ch] : 0;
      let v = line[i];
      if (ft === 1) v += a; else if (ft === 2) v += b; else if (ft === 3) v += (a + b) >> 1;
      else if (ft === 4) {
        const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c);
      }
      line[i] = v & 0xff;
    }
    for (let x = 0; x < w; x++) {
      const s = x * ch, d = (y * w + x) * 4;
      if (ch === 4) { out[d] = line[s]; out[d + 1] = line[s + 1]; out[d + 2] = line[s + 2]; out[d + 3] = line[s + 3]; }
      else if (ch === 3) { out[d] = line[s]; out[d + 1] = line[s + 1]; out[d + 2] = line[s + 2]; out[d + 3] = 255; }
      else { out[d] = out[d + 1] = out[d + 2] = line[s]; out[d + 3] = 255; }
    }
    prev = line;
  }
  return { w, h, data: out };
}

// ---------- PNG 编码 ----------
const crcTable = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c; }
  return t;
})();
function crc32(buf) { let c = -1; for (let i = 0; i < buf.length; i++) c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8); return (c ^ -1) >>> 0; }
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type, 'ascii'), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}
function pngEncode(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))
  ]);
}

// ---------- 颜色与渐变 ----------
function parseColor(s) {
  s = String(s).trim();
  let m = /^#([0-9a-f]{6})$/i.exec(s);
  if (m) { const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1]; }
  m = /^#([0-9a-f]{3})$/i.exec(s);
  if (m) { const h = m[1]; return [parseInt(h[0] + h[0], 16), parseInt(h[1] + h[1], 16), parseInt(h[2] + h[2], 16), 1]; }
  m = /^rgba?\(([^)]+)\)$/i.exec(s);
  if (m) { const p = m[1].split(',').map(v => parseFloat(v)); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; }
  m = /^hsla?\(([^)]+)\)$/i.exec(s);
  if (m) {
    const p = m[1].split(',').map(v => parseFloat(v));
    const [r, g, b] = hsl2rgb(p[0], p[1] / 100, p[2] / 100);
    return [r, g, b, p.length > 3 ? p[3] : 1];
  }
  throw new Error('无法解析颜色: ' + s);
}
function hsl2rgb(h, s, l) {
  h = ((h % 360) + 360) % 360 / 360;
  const q = l < .5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = t => { t = (t + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return [Math.round(f(h + 1 / 3) * 255), Math.round(f(h) * 255), Math.round(f(h - 1 / 3) * 255)];
}
function makeGrad(kind, pts) {
  const stops = [];
  const g = {
    kind, pts, stops,
    addColorStop(o, c) { stops.push([o, parseColor(c)]); }
  };
  g.at = (x, y) => {
    let t;
    if (kind === 'linear') {
      const [x0, y0, x1, y1] = pts;
      const dx = x1 - x0, dy = y1 - y0, L = dx * dx + dy * dy || 1;
      t = ((x - x0) * dx + (y - y0) * dy) / L;
    } else {
      const [x0, y0, r0, x1, y1, r1] = pts;
      const d = Math.hypot(x - x1, y - y1);
      t = (d - r0) / ((r1 - r0) || 1);
    }
    t = Math.max(0, Math.min(1, t));
    const st = stops;
    if (!st.length) return [0, 0, 0, 0];
    if (t <= st[0][0]) return st[0][1];
    for (let i = 1; i < st.length; i++) {
      if (t <= st[i][0]) {
        const [o0, c0] = st[i - 1], [o1, c1] = st[i];
        const k = (t - o0) / ((o1 - o0) || 1);
        return [c0[0] + (c1[0] - c0[0]) * k, c0[1] + (c1[1] - c0[1]) * k, c0[2] + (c1[2] - c0[2]) * k, c0[3] + (c1[3] - c0[3]) * k];
      }
    }
    return st[st.length - 1][1];
  };
  return g;
}

// ---------- 加载游戏 ----------
const html = fs.readFileSync(new URL('./index.html', import.meta.url), 'utf8');
let js = html.match(/<script>([\s\S]*?)<\/script>/)[1];
js = js.replace("'use strict';", '');
js = js.replace(/\}\)\(\);\s*$/, `
  globalThis.__g = {
    get snake() { return player.body; }, set snake(v) { player.body = v; },
    get dir() { return player.dir; },    set dir(v) { player.dir = v; },
    get queue() { return player.queue; },set queue(v) { player.queue = v; },
    get foods() { return foods; },       set foods(v) { foods = v; },
    get bots() { return bots; },         set bots(v) { bots = v; },
    get state() { return state; },       set state(v) { state = v; },
    get score() { return score; },       set score(v) { score = v; },
    get kills() { return kills; },
    get cam() { return cam; },
    get alpha() { return alpha; },       set alpha(v) { alpha = v; },
    WCOLS, WROWS, CELL, SIZE, snapCam, draw,
    DIRS, addBot, tick, loop, spawnFoods
  };
})();`);

globalThis.__trace = [];
const canvas = makeCtx2D();
let rafQueue = [];
let clock = 0;
const noop = () => {};
function mkEl(id) {
  const set = new Set();
  return {
    id, dataset: {}, style: {}, textContent: '', innerHTML: '', width: 480, height: 480, listeners: {},
    classList: { add: c => set.add(c), remove: c => set.delete(c), contains: c => set.has(c) },
    getContext: () => canvas, addEventListener: noop
  };
}
const byId = {};
const document = { getElementById: id => (byId[id] ||= mkEl(id)), querySelectorAll: () => [], addEventListener: noop, hidden: false };
const winL = {};
const window = { devicePixelRatio: 1, addEventListener: (t, f) => ((winL[t] ||= []).push(f)) };
const store = {};
const sandbox = {
  window, document,
  requestAnimationFrame: f => rafQueue.push(f),
  performance: { now: () => clock },
  localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = v; } },
  Image: class {
    constructor() { this.width = 0; this.height = 0; this.onload = null; }
    set src(v) {
      const m = /^data:image\/png;base64,(.+)$/.exec(v);
      if (!m) return;
      this._pixels = pngDecode(Buffer.from(m[1], 'base64'));
      this.width = this._pixels.w; this.height = this._pixels.h;
      if (this.onload) this.onload();     // 同步触发，避免脚本先于解码完成执行
    }
  },
  console, Math, Date, Number, String, Array, Object, JSON, isNaN, Infinity
};
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(js, sandbox, { filename: 'game.js' });

const g = vm.runInContext('__g', sandbox);

// ---------- 驱动到指定局面 ----------
const scriptArg = process.argv.find(a => a.startsWith('--script='));
const script = scriptArg
  ? JSON.parse(fs.readFileSync(scriptArg.split('=')[1], 'utf8'))
  : [];
(winL.keydown || []).forEach(f => f({ key: ' ', code: 'Space', preventDefault: noop }));   // 开始

let now = 1000;
g.loop(now);
for (const cmd of script) {
  if (cmd.t) { now += cmd.t; g.loop(now); }
  else if (cmd.key) (winL.keydown || []).forEach(f => f({ key: cmd.key, code: 'Key', preventDefault: noop }));
  else if (cmd.eat) {
    // 把果实丢到蛇头正前方，制造"吃到了"的画面
    const h = g.snake[0], d = g.dir;
    g.foods = [{ x: h.x + d.x, y: h.y + d.y, kind: 'normal', born: now }];
    now += 180; g.loop(now);
  } else if (cmd.bots) {
    // 摆一批对手：[{name:'青', dir:'right', cells:[[x,y],...]}]
    g.bots = [];
    for (const b of cmd.bots) g.addBot(b.cells.map(p => ({ x: p[0], y: p[1] })), b.dir, b.name, now);
  } else if (cmd.relics) {
    // 摆几颗遗骸果实：[[x,y],...]
    for (const p of cmd.relics) g.foods.push({ x: p[0], y: p[1], kind: 'relic', born: now - 300, ttl: 22000 });
  } else if (cmd.normal) {
    for (const p of cmd.normal) g.foods.push({ x: p[0], y: p[1], kind: 'normal', born: now });
  } else if (cmd.place) {
    g.snake = cmd.place.map(p => ({ x: p[0], y: p[1] }));
    if (cmd.dir) g.dir = { x: cmd.dir[0], y: cmd.dir[1] };
    g.queue = [];
  }
}
now += 16; g.loop(now);
// 出图用的收尾：先定格到整格位置，镜头再稳稳对准奶龙（顺序反了会对准插值中的位置）
g.alpha = 1;
g.snapCam();
g.draw(now);

// ---------- 输出 ----------
if (process.env.TRACE) {
  console.log('--- fill 调用序列 ---');
  for (const line of globalThis.__trace || []) console.log('  ' + line);
}
const out = Buffer.alloc(W * H * 4);
const b = canvas._buf;
for (let y = 0; y < H; y++) {
  for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4, o = i;
    const a = b[i + 3];
    // 合成到页面深色底
    const bg = [7, 11, 22];
    out[o] = Math.round(Math.max(0, Math.min(1, b[i])) * 255 * a + bg[0] * (1 - a));
    out[o + 1] = Math.round(Math.max(0, Math.min(1, b[i + 1])) * 255 * a + bg[1] * (1 - a));
    out[o + 2] = Math.round(Math.max(0, Math.min(1, b[i + 2])) * 255 * a + bg[2] * (1 - a));
    out[o + 3] = 255;
  }
}
const file = process.argv[3] || 'snake/_render.png';fs.writeFileSync(file, pngEncode(W, H, out));
console.log('rendered -> ' + file + '   state=' + g.state + ' score=' + g.score + ' len=' + g.snake.length +
  '  head=' + JSON.stringify(g.snake[0]) + ' cam=' + JSON.stringify(g.cam));
